# Bug Hunt — Stabilitas Akhtar Agent (1.0.0-alpha.1)

Tanggal: 27 Sep 2026. Semua fix punya regression test di `tests/bughunt-regressions.test.js`.

## Kritis (bisa bikin hang / crash / data hilang / celah keamanan)

1. **Timeout tool palsu** — `executor.js/withTimeout`. Kalau tool tidak menghormati `ctx.signal`, timeout cuma mengirim abort lalu tetap menunggu selamanya; tool yang telat selesai malah dicatat `success`. Sekarang di-race dengan abort signal.
2. **Percakapan rusak permanen setelah Stop / trim context** — assistant `tool_calls` tanpa `tool_result` (atau sebaliknya karena `manageContext`/`budgetMessages` memotong di tengah pasangan) bikin semua provider balas HTTP 400 di setiap pesan berikutnya. Ditambah `repairToolPairs()` sebelum setiap panggilan model.
3. **RCE lewat `shell.openExternal`** — `windows.js` meneruskan URL apa pun (termasuk `file://…exe`, `smb://`) ke OS. Sekarang hanya `http/https/mailto`, dan main window cuma boleh berada di `index.html` sendiri (preload penuh tidak boleh pindah ke file lain).
4. **Symlink "gantung" lolos keluar workspace** — `pathguard.js` pakai `existsSync` (false untuk symlink yang target-nya belum ada) jadi `link -> /luar/file` dianggap aman; write berikutnya mengikuti link keluar. Sekarang pakai `lstat` + cek target link.
5. **Dua instance = database saling timpa** — sql.js menulis ulang seluruh file DB; dua jendela app saling menghapus data. Ditambah `requestSingleInstanceLock`.
6. **Crash loop kalau DB korup** — `new SQL.Database(buf)` tidak memvalidasi; error baru muncul di `exec(SCHEMA)` di luar try → app quit setiap start. Sekarang diprobe dan di-fallback (backup `.corrupt-*` tetap dibuat).
7. **macOS: klik dock setelah window ditutup = crash** — `activate` memanggil `bootstrap()` lagi → DB dibuka ulang & `ipcMain.handle` didaftarkan dua kali (throw). Sekarang hanya window yang dibuat ulang; IPC/download/permission selalu pakai window terkini.
8. **Run hang selamanya di dialog izin** — kalau window ditutup/tidak ada, promise permission tidak pernah resolve. Sekarang otomatis `deny`; keputusan yang tidak valid dari renderer juga dianggap `deny`; listener abort dibersihkan.
9. **Take Over bisa hang** — `safePoint` tidak bangun saat run timeout. Sekarang menerima `ctrl.signal`.
10. **Crash main process di Windows** — `spawn('taskkill')` tanpa handler `'error'`.

## Sedang / latent

11. **Lifetime grant bisa melewati BLOCKED/CRITICAL** (`permissions/manager.js`) — urutan cek salah; belum ter-exploit karena belum ada tool lifetime yang preview-nya menaikkan level, tapi sekarang ditutup.
12. **Status `timeout` tercatat `stopped`** kalau error dari provider tidak membawa `.reason` — sekarang fallback ke alasan di signal.
13. **`pathguard` salah blokir** file bernama `..sesuatu` di dalam workspace.
14. **Renderer `escapeHtml`** tidak meng-escape kutip (dipakai di atribut `title="…"`) dan crash kalau dapat `null`/angka.
15. **Timeline sort NaN** (id event integer vs id tool UUID).

## Kebersihan
- Test `wallpaper-tools` usang (kategori memang sudah pindah ke `system.control`) — disesuaikan.
- Test `takeover` disesuaikan dengan signature `safePoint` baru.
- Dihapus folder sampah hasil `mkdir -p src/{a,b}` yang dijalankan tanpa brace-expansion + `src/auth-supabase.tmp` kosong.

## Belum bisa diverifikasi di sandbox
- `tests/data-managers.test.js` butuh `npm install` (sql.js). Jalankan `npm install && npm test`.
- Semua yang butuh Electron runtime (window lifecycle, openExternal, single-instance) dicek lewat review + `node --check`, bukan dijalankan.

---

# Ronde 2 — browser tabs, computer control, MCP, scheduler, renderer

Regression test: `tests/bughunt-round2.test.js`, `tests/bughunt-db.test.js`.

## Kritis

16. **Tab "komputer" (punya akses file `window.akhtarFS`) bisa dibawa ke situs mana pun.** Klaim di komentar "refuses redirect" ternyata tidak benar: (a) `browser.navigate` dengan `tab_id` tab itu, (b) popup `window.open` dari halaman, (c) `computer.open({url})` pada pembukaan pertama — ketiganya memberi situs asing akses baca/tulis/hapus folder `akhtar-os-fs`. Sekarang: tab privileged tidak bisa di-navigate, `will-navigate/will-redirect` dikunci ke file/origin asal, popup dibuka di tab biasa, dan URL dari model tidak pernah dapat preload.
17. **`browser.new_tab`/`browser.navigate` menerima `file://`, `javascript:`, dll.** Agent yang kena prompt-injection bisa membuka file lokal di tab lalu membacanya. Sekarang hanya http/https/about:blank.
18. **MCP: EPIPE membuat main process crash** (terbukti direproduksi). Server yang menutup stdin + satu `tools/call` = `uncaughtException`. Sekarang stdin punya error handler, proses rusak dibunuh, request ditolak dengan rapi.
19. **MCP: `exit` dari proses lama menggagalkan request proses baru** setelah restart; proses lama bisa jadi yatim. Sekarang event diabaikan kalau prosesnya sudah diganti, dan proses lama selalu dimatikan sebelum spawn baru.
20. **MCP tidak jalan di Windows untuk server `npx`/`uvx`** (`.cmd` tidak bisa di-spawn tanpa shell → EINVAL). Memakai pembungkus `cmd.exe` aman yang sama dengan terminal.
21. **IPC tidak memeriksa pengirim.** Sekarang handler UI hanya menerima dari window utama, dan `osfs:*` hanya dari tab privileged.

## Sedang

22. **`browser.open` bisa dipakai menyerang localhost / LAN / cloud metadata**, dan membaca body tanpa batas (halaman raksasa = memori habis). Sekarang: host lokal butuh izin terpisah `network.local` (dev server tetap bisa), redirect dari situs publik ke LAN ditolak, body dibatasi 3 MB.
23. **Scheduler bisa menjalankan ulang task yang sama setelah crash** (slot baru dimajukan setelah run selesai). Sekarang slot diklaim dulu (at-most-once), run yang terputus ditandai `interrupted` saat start.
24. **Scheduler & user bisa jalan bersamaan di percakapan yang sama**, dan run terjadwal tidak bisa di-Stop / tidak dihentikan saat app quit. Sekarang berbagi lock `activeRuns`, tombol Stop berfungsi, `stop()` meng-abort.
25. **Scheduler memakai referensi window lama** → `send` ke window yang sudah ditutup melempar error di tengah agent loop.
26. **Status scheduler selalu `success`** walau task berakhir timeout/stopped.
27. **Browser tabs setelah window ditutup**: `destroyAll` gagal di `removeChildView` sebelum `webContents.close()` → proses renderer tab tetap hidup; event tab melempar ke window yang sudah hancur. `waitForLoad` membocorkan listener.
28. **Dialog izin basi**: saat run di-Stop, main sudah menolak tapi dialog tetap terbuka dan menahan dialog berikutnya. Sekarang ada event `permission:cancel`.
29. **Renderer**: stream bubble nyangkut setelah Stop (jawaban berikutnya menempel ke bubble lama); render ulang penuh tiap token (UI patah-patah di jawaban panjang) → maksimal sekali per frame; teks yang diketik hilang kalau membuat percakapan gagal; Enter bisa double-send; pindah percakapan saat stream menulis ke node yang sudah dilepas.
30. **Audit kontrak tool jalan sebelum plugin didaftarkan** → tool plugin tidak pernah diaudit.

## Catatan verifikasi
- Test DB (`data-managers`, `bughunt-db`) dijalankan dengan shim `sql.js` di atas `node:sqlite` karena sandbox tanpa internet; shim tidak ikut dikirim. Di mesinmu cukup `npm install && npm test`.
- Hasil: 181 test, 180 lulus, 0 gagal, 1 skip (symlink test di Windows). Soak 2000 siklus: 0 failure.
- Bug DB korup ronde 1 sekarang juga terbukti: kode lama → `STARTUP CRASH: file is not a database`, kode baru → pulih + backup.
- Perilaku yang butuh Electron sungguhan (WebContentsView, navigasi tab, pengecekan sender IPC) belum bisa dijalankan di sini — hanya direview + unit test fungsi murninya.

---

# Ronde 3 — git, github, code, checkpoints, ghost workspace, billing, alur agent

Regression test: `tests/bughunt-round3.test.js`, `tests/bughunt-agent-e2e.test.js` (harness baru yang menjalankan `Agent.run` asli dengan model palsu: `tests/helpers/agent-harness.js`), tambahan di `tests/bughunt-db.test.js`.

## Kritis

31. **RCE dari repo tak dipercaya lewat `git.status`** (terbukti). `.git/config` berisi `core.fsmonitor = <perintah>` → git menjalankan perintah itu setiap `status`, dan `git.status` adalah tool READ yang auto-allowed tanpa dialog. Jalur yang sama lewat `terminal.run "git status"` (diklasifikasi SAFE). Sekarang semua pemanggilan git (tool & terminal) mematikan `core.fsmonitor`, `diff.external`, `protocol.ext`; diff/log/show/blame read-only memakai `--no-textconv --no-ext-diff`; opsi `-c`/`--ext-diff`/`--textconv`/`--upload-pack` di terminal tidak lagi dianggap read-only; hook dimatikan kecuali untuk `git.commit`.
32. **Satu tool timeout = seluruh task mati** (terbukti via harness). `AbortError` dari timeout per-tool dianggap sebagai Stop/timeout run. Sekarang hanya abort run yang menghentikan run; timeout tool jadi kegagalan tool biasa yang bisa di-recover model.
33. **User yang belum login Akhtar Account tidak bisa memakai agent sama sekali** (terbukti). `spendEffort` melempar "Sign in to use credits" setelah setiap panggilan model → semua run gagal, termasuk yang memakai API key sendiri. Lebih parah: kalau charge gagal *setelah* tool sukses, tool dilaporkan gagal → model mengulang → efek samping ganda (file ditulis 2x, komentar GitHub 2x). Sekarang: tidak login / layanan kredit down → run jalan terus & dicatat `credits_skipped`; kredit habis → run berhenti rapi; tool yang sukses tetap sukses; request kredit punya timeout 15 detik.
34. **`git.branch` option/path injection.** `name: "-f"` → `git checkout -f` (buang semua perubahan), `name: "src/app.js"` → `git checkout src/app.js` (revert file diam-diam). Sekarang nama divalidasi seperti ref git dan memakai `git switch` yang tidak pernah me-restore file.
35. **Ghost Workspace "Apply" menimpa editan user** yang dibuat di project asli setelah ghost dibuat, tanpa peringatan. Sekarang konflik dideteksi dan butuh konfirmasi kedua di UI; apply kedua tidak mengulang perubahan yang sama.

## Sedang

36. **GitHub owner/repo tidak divalidasi** → `owner: "../../user"` membuat request ke endpoint API lain dengan token user.
37. **Undo `folder.copy` selalu gagal** (`unlinkSync` pada folder).
38. **Undo hanya mengembalikan iterasi terakhir** — context tool dibuat ulang tiap iterasi sehingga satu task punya banyak checkpoint.
39. **Checkpoint file raksasa** disimpan base64 di DB in-memory yang di-export ulang tiap 400 ms → memori meledak. Sekarang >20 MB ditandai `unrestorable` (dan TIDAK dihapus saat undo — `before: null` artinya "file baru" dan akan dihapus). Checkpoint dipangkas ke 50 terakhir per workspace. Restore dua kali ditolak.
40. **`code.obfuscate`**: output menimpa file tanpa checkpoint; `App.js` vs `app.js` di Windows/macOS = menimpa source; bisa menulis ke `.git`; input tanpa batas ukuran membekukan main process (obfuscation sinkron, tidak bisa di-timeout).

## Keterbatasan yang tersisa (bukan diperbaiki, dicatat)
- Undo tidak mendeteksi kalau user mengedit file lagi setelah task selesai — restore akan menimpa editan itu. Perlu menyimpan hash "sesudah" per file (perubahan skema).
- Sesi Ghost Workspace hanya di memori: setelah restart, ghost tidak bisa di-apply (file-nya masih di folder temp).
- Aturan "user belum login = gratis" adalah asumsi saya untuk model pakai API key sendiri. Kalau bisnismu mau semua run wajib login/berbayar, ubah `chargeSafely` di `src/billing/credits.js` — tapi tetap jangan biarkan charge yang gagal mengubah tool sukses jadi gagal.

---

# Ronde 4 — LLM providers, SSE, secrets, settings, security guard, knowledge, memory, edge function

Regression test: `tests/bughunt-round4.test.js` (provider diuji dengan respons SSE palsu), tambahan e2e di `tests/bughunt-agent-e2e.test.js`. Akhtar OS (`os/`) sengaja tidak disentuh.

## Kritis

41. **Satu HTTP 429 / "overloaded" / koneksi putus = task gagal** (terbukti). `ProviderError.retryable` sudah dihitung tapi tidak pernah dipakai. Sekarang panggilan model di-retry maksimal 2x dengan backoff (menghormati `Retry-After`, maks 30 detik). Aman karena belum ada efek samping sebelum stream selesai; teks parsial di UI dibersihkan lewat event `stream_reset`.
42. **Jawaban terpotong dianggap jawaban final.** Kalau koneksi putus di tengah stream, Anthropic/OpenAI/Gemini mengembalikan teks setengah (atau tool call dengan JSON rusak) sebagai jawaban akhir. Sekarang tiap provider mewajibkan penanda selesai (`message_stop` / `[DONE]` atau `finish_reason` / `finishReason`); kalau tidak ada → error yang bisa di-retry.
43. **Stream macet menggantung run sampai timeout run** (default 20 menit, bisa sampai 4 jam). Sekarang watchdog idle 150 detik di parser SSE, dan koneksinya benar-benar ditutup (`reader.cancel()`).
44. **Gemini thinking model: percakapan dengan tool rusak di giliran kedua.** `thoughtSignature` dari provider dibuang saat assistant message disimpan → Gemini menolak dengan 400 "missing thought_signature". Sekarang `meta` ikut disimpan.
45. **Credential terkirim ke LLM cloud lewat Project Knowledge tanpa izin** (terbukti). `secrets.yaml`, `credentials.json`, dll. butuh izin SENSITIVE kalau dibaca via `file.read`, tapi indexer otomatis memasukkannya ke system prompt. Sekarang file itu dilewati dan API key yang ada di file biasa di-mask.
46. **Edge function `openai-luna` tidak memverifikasi user** dan meneruskan body mentah ke OpenAI memakai kunci server. Siapa pun yang punya publishable key (ada di dalam app) bisa memakai proxy itu, dan field seperti `n: 128` melipatgandakan biaya. Sekarang: wajib user login yang valid, dan hanya field yang dipakai app yang diteruskan. **Belum diuji** (tidak ada Deno di sandbox) — deploy dan tes dulu. **Masih terbuka:** kredit hanya dipotong di sisi client, jadi client yang dimodifikasi tetap bisa pakai gratis. Pemotongan kredit harus dipindah ke edge function (TODO sudah ditandai di kodenya).

## Sedang

47. **OpenAI-compatible (Ollama, beberapa proxy): beberapa tool call yang semuanya ber-`index: 0` digabung jadi satu** (`file__readfile__write` dengan argumen `{..}{..}`). Sekarang dipisah berdasarkan `id`.
48. **Anthropic `overloaded_error` di tengah stream** dilempar sebagai error biasa (tidak bisa di-retry).
49. **Gemini**: event usage dikirim di setiap chunk (membanjiri timeline); respons diblokir SAFETY muncul sebagai jawaban kosong tanpa penjelasan.
50. **Secret store korup (mis. listrik mati saat menulis) → semua API key terhapus diam-diam** pada penyimpanan berikutnya. Sekarang file dibackup `.corrupt-*`. Juga: `has()` bilang "ada" padahal key tidak bisa didekripsi (profil OS pindah); nama `__proto__` diterima; rename gagal karena file dikunci antivirus di Windows melempar error.
51. **Security guard memblokir dokumentasi secara permanen**: README berisi `sudo apt install …` atau artikel yang menyebut `mkfs` tidak bisa ditulis sama sekali (blok "tidak bisa di-override"). File dokumentasi (.md/.txt/.rst/…) sekarang dikecualikan; script tetap diperiksa.
52. **Knowledge indexer membekukan UI**: tiap kali ada file berubah, sampai ~1,2 GB dibaca & ditokenisasi ulang secara sinkron di main process. Sekarang inkremental (file tak berubah dipakai ulang) dan dibatasi 24 MB total.

## Ringan
53. **Settings**: nilai section yang rusak di DB (versi lama / DB diedit) membuat `settings.get()` selalu throw → app tidak bisa start. (Patch buruk dari UI sudah gagal sebelum tersimpan, jadi ini hanya lewat data yang sudah rusak — lebih ringan dari dugaan awal saya.)
54. **Memory** dengan scope `project` tanpa workspace tersimpan tapi tidak pernah tampil lagi; scope tidak divalidasi.

## Catatan
- Test "multi-byte split" dan "split arguments OpenAI" adalah penjaga regresi, bukan bug di kode lama — dua-duanya memang sudah benar.
- Watchdog SSE versi pertama saya sendiri ternyata ikut hang (menunggu `iterator.return()` pada read yang macet); ketahuan oleh test dan sudah diganti ke `reader.cancel()`.
- Security guard tetap defense-in-depth, bukan batas keamanan: file .md bisa di-rename jadi .sh (tapi butuh izin tulis), dan `node -e` dll. tetap lewat jalur izin biasa.

---

# Ronde 5 — renderer, tools kecil, fuzz, chaos soak + desain ulang UI

## Bug (semuanya terbukti dengan test sebelum/sesudah)

55. **Pindah percakapan saat agen bekerja = app tidak bisa mengirim pesan lagi sampai di-restart.** Event `task_end` untuk percakapan yang sedang tidak dibuka dibuang, jadi `state.running` tetap `true` selamanya.
56. **Tampilan kosong ("mau dikerjakan apa?") hilang permanen** setelah membuka satu percakapan — elemennya ada di dalam daftar pesan yang dikosongkan dengan `innerHTML = ''`.
57. **Mode agen tidak ikut percakapan.** Membuka percakapan "Otomatis" lalu pindah ke percakapan lain tetap memakai mode sebelumnya — pesan bisa berjalan dengan izin yang lebih longgar dari yang kamu set.
58. **Ganti folder project tetap mengirim pesan ke percakapan project lama.**
59. **Hentikan navigasi peta tidak mematikan GPS** — lokasi terus dilacak dan dikirim.
60. **Dokumen/presentasi/gambar/grafik saling menimpa** kalau judulnya sama atau memakai huruf non-Latin (semua jadi `untitled.*`), tanpa checkpoint. Sekarang nama file dibuat unik; huruf beraksen dinormalisasi (`Résumé` → `resume`).
61. **Tombol pembayaran nonaktif tanpa alasan** (belum masuk akun) — sekarang dijelaskan.
62. Kecil: tombol "Search" peta tidak mencari apa pun; "Coba di salinan aman" tanpa project diam saja; status tool, pesan billing, dan pengaturan campur Inggris–Indonesia.

## Yang diuji tapi tidak menemukan bug
- **Fuzz 165 tool** dengan input tepi: 19 laporan, semuanya ternyata karena mock saya belum lengkap (method memang ada di kode asli). Tidak ada bug nyata.
- **Chaos soak** (`npm run test:chaos`): 150 run agen asli dengan tool sukses/gagal/macet, 429, dan Stop di waktu acak. Semua berakhir di status final, riwayat selalu valid untuk provider, tidak ada tool call yang tertinggal "running", tidak ada unhandled rejection, tidak ada kebocoran listener. 600 run juga semuanya selesai (test-nya saja yang kena batas waktu karena jeda retry 429 memang 1,5 detik).

## Desain ulang UI
- Satu tugas per layar: kasih perintah → lihat kerja agen → setujui aksi. Semua yang lain dipindah ke tab atau pengaturan.
- Tombol "Chat" ganda dihapus: tampilan jadi **Obrolan / Browser / Peta**; mode agen jadi **Tanya / Dibantu / Otomatis** tepat di bawah kolom ketik, dengan satu kalimat yang menjelaskan mode yang aktif.
- Panel kanan dari 8 blok jadi 3 tab: **Progres** (langkah + aktivitas), **Jejak** (timeline, diagnosis), **Hasil** (file, titik undo, unduhan, jadwal). Bisa disembunyikan.
- Pengaturan dari satu halaman panjang jadi 5 bagian: Model AI, Akun & kredit, Agen, Integrasi, Lanjutan. Esc/klik di luar menutup.
- Warna: kertas dingin, tinta biru tua, satu warna aksi (cobalt). Emas "bintang" (Akhtar = bintang) hanya muncul saat agen bekerja. Mode gelap otomatis mengikuti Windows. Kontras teks memenuhi WCAG AA.
- Font sistem (Segoe UI Variable di Windows) — app desktop, offline, dan CSP memblokir font eksternal.
- Semua teks satu bahasa (Indonesia), kata kerja jelas: "Izinkan sekali", "Izinkan di project ini", "Tolak", "Batalkan".
- Semua 104 ID elemen yang dipakai `app.js` dipertahankan.
- `npm run test:ui` (butuh `pip install playwright`) menjalankan renderer asli di Chromium dan memeriksa perilaku di atas.

## Batas kejujuran
"Benar-benar stabil" tidak bisa saya jamin dari sandbox: Electron, Windows, WebContentsView, dan edge function Supabase belum pernah dijalankan di sini. Yang bisa saya jamin: semua jalur yang bisa dijalankan tanpa Electron sudah dites, termasuk loop agen asli di bawah gangguan acak.
