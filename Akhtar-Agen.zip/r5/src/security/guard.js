'use strict';
/**
 * Hard security guard.
 *
 * This is intentionally narrower than the normal permission/classification layer:
 * - guard.js = non-overridable blocks for obviously high-impact behavior
 * - permission manager = user-consent boundary for legitimate but sensitive actions
 *
 * It is a defense-in-depth filter, not a malware detector. Keep rules explainable,
 * deterministic, and covered by tests. Do not put ordinary project operations here.
 */

const path = require('path');

const norm = (v) => String(v ?? '').toLowerCase().replace(/\\/g, '/');
const base = (v) => path.basename(String(v ?? '')).toLowerCase().replace(/\.(exe|cmd|bat|com|ps1)$/i, '');
const uniq = (xs) => [...new Set(xs)];

// Programs whose normal purpose is system destruction, privilege escalation,
// boot/security modification, account administration, or persistence.
const HARD_BLOCK_PROGRAMS = new Map([
  ['diskpart', 'disk/partition administration'],
  ['fdisk', 'disk/partition administration'],
  ['parted', 'disk/partition administration'],
  ['mkfs', 'filesystem formatting'],
  ['wipefs', 'filesystem signature destruction'],
  ['dd', 'raw disk writing'],
  ['bcdedit', 'boot configuration modification'],
  ['vssadmin', 'shadow-copy administration'],
  ['sudo', 'privilege escalation'],
  ['su', 'privilege escalation'],
  ['doas', 'privilege escalation'],
  ['runas', 'privilege escalation'],
  ['pkexec', 'privilege escalation'],
  ['useradd', 'account administration'],
  ['userdel', 'account administration'],
  ['usermod', 'account administration'],
  ['passwd', 'credential/account modification'],
  ['schtasks', 'system persistence/scheduled-task administration'],
  ['crontab', 'system persistence/scheduled-task administration'],
  ['systemctl', 'system service administration'],
  ['launchctl', 'system service administration'],
  ['regsvr32', 'system component registration'],
  ['rundll32', 'arbitrary system DLL execution'],
  ['mshta', 'script/HTML application execution'],
  ['wscript', 'Windows script execution'],
  ['cscript', 'Windows script execution'],
]);

const ROOT_TARGET = /^(?:\/|\/\*|~|~\/|[a-z]:\/?|[a-z]:\/\*|%userprofile%|\$home)$/i;
const SYSTEM_TARGET = /^(?:\/(?:bin|boot|etc|lib|lib64|sbin|usr|var|sys|proc|root)(?:\/|$)|[a-z]:\/(?:windows|program files|programdata)(?:\/|$))/i;

function scanCommand(argv) {
  if (!Array.isArray(argv) || argv.length === 0) return [];
  const hazards = [];
  const prog = base(argv[0]);
  const args = argv.slice(1);
  const low = args.map(norm);

  if (HARD_BLOCK_PROGRAMS.has(prog)) {
    hazards.push(`blocked program: ${prog} (${HARD_BLOCK_PROGRAMS.get(prog)})`);
  }

  // Registry writes are a hard boundary; reads can remain permission-controlled.
  if (prog === 'reg' && low.some((a) => ['add', 'delete', 'import', 'restore', 'load', 'unload'].includes(a))) {
    hazards.push('registry modification');
  }

  // Network/firewall configuration can cut connectivity or weaken host protections.
  if (['netsh', 'iptables', 'nft', 'ufw'].includes(prog)) hazards.push('firewall/network security modification');

  // Security-service tampering is never delegated to the agent.
  if (prog === 'sc' && low.some((a) => ['stop', 'delete', 'config', 'create', 'failure'].includes(a))) {
    hazards.push('system service modification');
  }

  // Destructive deletes aimed at a root/home/system location.
  if (['rm', 'del', 'erase', 'rmdir', 'rd'].includes(prog)) {
    const destructive = low.some((a) => /^-[a-z]*[rf][a-z]*$/i.test(a) || ['/s', '/q', '--recursive', '--force'].includes(a));
    const targets = low.filter((a) => !a.startsWith('-') && !/^\/[sq]$/i.test(a));
    if (destructive && targets.some((a) => ROOT_TARGET.test(a) || SYSTEM_TARGET.test(a))) {
      hazards.push('destructive delete of root/home/system location');
    }
  }

  // Explicit attempts to disable common host security controls.
  const joined = low.join(' ');
  if (prog === 'powershell' || prog === 'pwsh') {
    if (/set-mppreference/.test(joined) && /disablerealtimemonitoring/.test(joined)) hazards.push('attempt to disable antivirus protection');
    if (/add-mppreference/.test(joined) && /exclusion(path|process|extension)/.test(joined)) hazards.push('attempt to add antivirus exclusion');
  }

  // Shadow-copy deletion is high-impact even if vssadmin aliases/wrappers change.
  if (/delete\s+shadows|shadowcopy.*delete/.test(joined)) hazards.push('shadow-copy deletion');

  return uniq(hazards);
}

// Code-content rules are deliberately high-confidence. These inspect text the
// agent is about to WRITE, not merely text it is reading.
const CODE_RULES = [
  {
    label: 'attempt to disable Windows antivirus protection',
    test: (s) => /set-mppreference[\s\S]{0,240}-disablerealtimemonitoring[\s\S]{0,80}\$?true/i.test(s),
  },
  {
    label: 'attempt to add Windows antivirus exclusion',
    test: (s) => /add-mppreference[\s\S]{0,240}-exclusion(?:path|process|extension)/i.test(s),
  },
  {
    label: 'shadow-copy deletion',
    test: (s) => /vssadmin(?:\.exe)?\s+delete\s+shadows|wmic[\s\S]{0,120}shadowcopy[\s\S]{0,80}delete/i.test(s),
  },
  {
    label: 'boot configuration tampering',
    test: (s) => /\bbcdedit(?:\.exe)?\b[\s\S]{0,180}\/(?:set|delete|deletevalue|import)/i.test(s),
  },
  {
    label: 'raw disk/filesystem destruction',
    test: (s) => /\b(?:mkfs(?:\.[a-z0-9]+)?|wipefs)\b|\bdd\b[\s\S]{0,160}\bof\s*=\s*\/dev\//i.test(s),
  },
  {
    label: 'destructive root/system deletion',
    test: (s) => /\brm\s+(?:-[a-z]*[rf][a-z]*\s+)+(?:\/|~)(?:\s|$)|\b(?:rmdir|rd)\s+\/s\s+\/q\s+(?:[a-z]:\\|%userprofile%)/i.test(s),
  },
  {
    label: 'Windows registry persistence/modification',
    test: (s) => /\breg(?:\.exe)?\s+(?:add|delete|import)\s+["']?(?:hk(?:lm|cu)|hkey_)/i.test(s),
  },
  {
    label: 'privilege-escalation command embedded in generated code',
    test: (s) => /(?:^|[;&|\n\r]\s*)\b(?:sudo|pkexec|runas)(?:\.exe)?\s+/im.test(s),
  },
];

// Prose/documentation is never executed. Install guides ("sudo apt install …") and articles
// mentioning mkfs used to be hard-blocked with no way to override.
const DOC_FILE = /\.(?:md|markdown|mdx|txt|rst|adoc|asciidoc)$/i;

function scanCode(text, { path: filePath } = {}) {
  const src = String(text ?? '');
  if (!src.trim()) return [];
  if (filePath && DOC_FILE.test(String(filePath))) return [];
  const hazards = [];
  for (const rule of CODE_RULES) {
    try { if (rule.test(src)) hazards.push(rule.label); } catch { /* fail closed is handled by caller policy */ }
  }
  return uniq(hazards);
}

module.exports = { scanCode, scanCommand };
