'use strict';
const SUPABASE_URL = 'https://ldjlvbrzsuykepujsqhy.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_LTytmbstTje2Num6kjIROg_Jwr0qSfe';

class SupabaseAuth {
  constructor({ secrets }) { this.secrets = secrets; }
  async _request(path, { method='GET', body, token }={}) {
    const headers = { apikey: SUPABASE_PUBLISHABLE_KEY, 'Content-Type':'application/json' };
    if (token) headers.Authorization = `Bearer ${token}`;
    const r = await fetch(`${SUPABASE_URL}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
    const data = await r.json().catch(()=>({}));
    if (!r.ok) throw new Error(data.msg || data.message || data.error_description || data.error || `Supabase request failed (${r.status})`);
    return data;
  }
  _saveSession(s) {
    if (s?.access_token) this.secrets.set('auth:supabase:accessToken', s.access_token);
    if (s?.refresh_token) this.secrets.set('auth:supabase:refreshToken', s.refresh_token);
  }
  async signUp({ email, password, displayName='' }) {
    const data = await this._request('/auth/v1/signup', { method:'POST', body:{ email, password, data:{ display_name:displayName } } });
    if (data.access_token) this._saveSession(data);
    return { user:data.user ? { id:data.user.id, email:data.user.email } : null, signedIn:!!data.access_token, confirmationRequired:!data.access_token };
  }
  async signIn({ email, password }) {
    const data = await this._request('/auth/v1/token?grant_type=password', { method:'POST', body:{ email, password } });
    this._saveSession(data);
    return { user:{ id:data.user.id, email:data.user.email }, signedIn:true };
  }
  async accessToken() {
    let token=this.secrets.get('auth:supabase:accessToken');
    if (token) {
      try { await this._request('/auth/v1/user',{token}); return token; } catch {}
    }
    const refresh=this.secrets.get('auth:supabase:refreshToken');
    if (!refresh) return null;
    try {
      const data=await this._request('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:{refresh_token:refresh}});
      this._saveSession(data); return data.access_token;
    } catch { return null; }
  }
  async session() {
    const token=await this.accessToken(); if(!token) return { signedIn:false, user:null };
    const u=await this._request('/auth/v1/user',{token}); return { signedIn:true, user:{id:u.id,email:u.email} };
  }
  async signOut() {
    const token=await this.accessToken();
    if(token) await this._request('/auth/v1/logout',{method:'POST',token}).catch(()=>{});
    this.secrets.set('auth:supabase:accessToken',''); this.secrets.set('auth:supabase:refreshToken','');
    return { signedOut:true };
  }
}
module.exports={SupabaseAuth,SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY};
