'use strict';
/**
 * Plugin SDK (§ requested feature). A plugin is a folder:
 *
 *   plugins/spotify/
 *   ├── plugin.json   { "name": "spotify", "version": "1.0.0", "description": "...", "main": "index.js" }
 *   └── index.js      module.exports = [ { name, group, description, inputSchema, permission, category, execute } , ... ]
 *                      (same shape as a built-in src/tools/<group>/index.js file — permission is a LEVEL
 *                      string like "NETWORK"/"WRITE"/etc, or a function (args, ctx) => LEVEL)
 *
 * Akhtar Agent scans the `plugins/` folder at startup, requires each
 * `main` file, and registers whatever tools it exports. A plugin's
 * execute(args, ctx) receives the exact same `ctx` a built-in tool does
 * (filesystem, secrets, artifacts, ...), so it can do anything a
 * built-in tool can.
 *
 * SECURITY: this is NOT a sandbox. A plugin's code runs with full
 * main-process Node privileges, same as Akhtar Agent's own source —
 * only install plugins you trust, exactly like any npm package.
 */
const fs = require('fs');
const path = require('path');
const { logger } = require('../utils/logger');

function discoverPlugins(dirs) {
  const found = [];
  for (const dir of (Array.isArray(dirs) ? dirs : [dirs])) {
    if (!dir || !fs.existsSync(dir)) continue;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const pluginDir = path.join(dir, entry.name);
      const manifestPath = path.join(pluginDir, 'plugin.json');
      if (!fs.existsSync(manifestPath)) continue;
      try {
        const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
        if (!manifest.name || typeof manifest.name !== 'string') throw new Error('plugin.json needs a "name" string.');
        const mainFile = path.join(pluginDir, manifest.main || 'index.js');
        if (!fs.existsSync(mainFile)) throw new Error(`main file "${manifest.main || 'index.js'}" not found.`);
        found.push({ id: entry.name, dir: pluginDir, manifest, mainFile });
      } catch (e) {
        logger.app('error', `Skipped plugin folder "${entry.name}": ${e.message}`);
      }
    }
  }
  return found;
}

/**
 * @returns {{ tools: object[], loaded: {id,name,version,description,toolCount}[], errors: {id,error}[] }}
 */
function loadPluginTools(dirs) {
  const tools = [];
  const loaded = [];
  const errors = [];
  for (const p of discoverPlugins(dirs)) {
    try {
      const resolved = require.resolve(p.mainFile);
      delete require.cache[resolved]; // pick up edits without a full app restart
      const exported = require(resolved);
      const list = Array.isArray(exported) ? exported : (typeof exported === 'function' ? exported() : null);
      if (!Array.isArray(list)) throw new Error('its main file must export an array of tools, or a function returning one.');
      for (const tool of list) tool.plugin = p.manifest.name;
      tools.push(...list);
      loaded.push({ id: p.id, name: p.manifest.name, version: p.manifest.version || null, description: p.manifest.description || null, toolCount: list.length });
      logger.app('info', `Loaded plugin "${p.manifest.name}" (${list.length} tool(s))`);
    } catch (e) {
      logger.app('error', `Failed to load plugin "${p.id}": ${e.message}`);
      errors.push({ id: p.id, error: e.message });
    }
  }
  return { tools, loaded, errors };
}

module.exports = { discoverPlugins, loadPluginTools };
