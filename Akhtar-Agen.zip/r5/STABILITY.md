# Akhtar Agent Stability Hardening

Implemented stability layers:

1. Tool contract audit at startup for every registered tool (shape/schema/execute/timeout validity).
2. Startup health check for database, registry, artifacts directory and platform dependencies (Git, PowerShell on Windows, osascript on macOS).
3. Cooperative real cancellation: executor creates a per-attempt AbortSignal; timeout aborts the underlying tool. Terminal already kills its child process tree on abort/timeout.
4. Persisted tool-call states: running -> verifying -> success, with failed/timeout/cancelled/blocked/interrupted terminal states.
5. Retry policy: at most two retries, exponential backoff, transient errors only. Permission/schema/security/unsupported errors are never retried.
6. Verification gate: tool-specific verify hooks are supported; verified:false fails; terminal non-zero/timeout/cancelled cannot be reported as success. Existing filesystem writes retain hash read-back verification.
7. Startup crash recovery: stale running/verifying/queued tasks and tool calls are marked interrupted with recovery events. Existing task/todo/checkpoint data remains persisted for safe user/agent continuation instead of silently claiming completion.
8. Soak harness: `npm run soak` (default 1000 deterministic cycles, override with SOAK_ITERATIONS) plus `npm run test:stability`.

Design rule: a timeout only guarantees underlying cancellation for tools that honor ctx.signal. Native/terminal implementations should pass that signal to cancellable subprocess/network APIs; terminal.run already kills the process tree.
