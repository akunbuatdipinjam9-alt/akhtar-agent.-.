'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { discoverPlugins, loadPluginTools } = require('../src/plugins/loader');

function writePlugin(baseDir, name, manifest, indexJs) {
  const dir = path.join(baseDir, name);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'plugin.json'), JSON.stringify(manifest));
  if (indexJs !== null) fs.writeFileSync(path.join(dir, manifest.main || 'index.js'), indexJs);
}

test('plugin loader: discovers a well-formed plugin folder', () => {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-plugins-'));
  writePlugin(base, 'dice', { name: 'dice', version: '1.0.0', main: 'index.js' },
    "module.exports = [{ name: 'dice.roll', group: 'dice', description: 'roll', inputSchema: {type:'object',properties:{}}, permission: 'NONE', execute: async () => ({ n: 4 }) }];");
  const found = discoverPlugins([base]);
  assert.equal(found.length, 1);
  assert.equal(found[0].manifest.name, 'dice');
});

test('plugin loader: skips a folder with no plugin.json, and one with no name', () => {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-plugins-'));
  fs.mkdirSync(path.join(base, 'not-a-plugin'));
  fs.writeFileSync(path.join(base, 'not-a-plugin', 'index.js'), 'module.exports = [];');
  writePlugin(base, 'noname', { version: '1.0.0' }, 'module.exports = [];');
  const found = discoverPlugins([base]);
  assert.equal(found.length, 0);
});

test('plugin loader: loadPluginTools registers a working plugin\'s tools and tags them with the plugin name', async () => {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-plugins-'));
  writePlugin(base, 'dice', { name: 'dice', main: 'index.js' },
    "module.exports = [{ name: 'dice.roll', group: 'dice', description: 'roll', inputSchema: {type:'object',properties:{}}, permission: 'NONE', execute: async () => ({ n: 4 }) }];");
  const { tools, loaded, errors } = loadPluginTools([base]);
  assert.equal(tools.length, 1);
  assert.equal(tools[0].name, 'dice.roll');
  assert.equal(tools[0].plugin, 'dice');
  assert.equal(await tools[0].execute({}, {}).then((r) => r.n), 4);
  assert.equal(loaded.length, 1);
  assert.equal(errors.length, 0);
});

test('plugin loader: a broken plugin is skipped (reported as an error) without affecting a working one', async () => {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-plugins-'));
  writePlugin(base, 'broken', { name: 'broken', main: 'index.js' }, "throw new Error('boom at load time');");
  writePlugin(base, 'notarray', { name: 'notarray', main: 'index.js' }, "module.exports = { not: 'an array' };");
  writePlugin(base, 'good', { name: 'good', main: 'index.js' },
    "module.exports = [{ name: 'good.ping', group: 'good', description: 'ping', inputSchema: {type:'object',properties:{}}, permission: 'NONE', execute: async () => ({ pong: true }) }];");

  const { tools, loaded, errors } = loadPluginTools([base]);
  assert.equal(tools.length, 1);
  assert.equal(tools[0].name, 'good.ping');
  assert.equal(loaded.length, 1);
  assert.equal(errors.length, 2);
  assert.ok(errors.some((e) => e.id === 'broken'));
  assert.ok(errors.some((e) => e.id === 'notarray'));
});

test('plugin loader: missing main file is reported, not thrown', () => {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-plugins-'));
  fs.mkdirSync(path.join(base, 'ghost'));
  fs.writeFileSync(path.join(base, 'ghost', 'plugin.json'), JSON.stringify({ name: 'ghost', main: 'missing.js' }));
  const found = discoverPlugins([base]);
  assert.equal(found.length, 0, 'should be skipped at discovery time');
});

test('plugin loader: the real bundled plugins/ folder loads cleanly', () => {
  const bundledDir = path.join(__dirname, '..', 'plugins');
  const { tools, errors } = loadPluginTools([bundledDir]);
  assert.equal(errors.length, 0, `bundled plugins should load without error: ${JSON.stringify(errors)}`);
  assert.ok(tools.some((t) => t.name === 'spotify.search'), 'the example spotify plugin should be discovered');
});

// ---------- example plugin: spotify ----------
const spotifyTools = require('../plugins/spotify/index.js');
const spotifyByName = Object.fromEntries(spotifyTools.map((t) => [t.name, t]));

function fakeSecrets(map) { return { get: (k) => map[k] }; }

test('spotify plugin: clear setup error when Client ID/Secret are missing, no network call made', async (t) => {
  const fetchMock = t.mock.fn(async () => ({ ok: true, json: async () => ({}) }));
  t.mock.method(global, 'fetch', fetchMock);
  const ctx = { secrets: fakeSecrets({}), signal: undefined };
  await assert.rejects(() => spotifyByName['spotify.search'].execute({ query: 'x' }, ctx), /Client ID\/Secret belum diset/);
  assert.equal(fetchMock.mock.callCount(), 0);
});

test('spotify plugin: fetches a token via Client Credentials, then searches, then reuses the cached token', async (t) => {
  const calls = [];
  t.mock.method(global, 'fetch', async (url, opts) => {
    calls.push(url);
    if (url === 'https://accounts.spotify.com/api/token') {
      assert.equal(opts.method, 'POST');
      assert.match(opts.headers.Authorization, /^Basic /);
      return { ok: true, json: async () => ({ access_token: 'tok_123', expires_in: 3600 }) };
    }
    if (url.startsWith('https://api.spotify.com/v1/search')) {
      assert.equal(opts.headers.Authorization, 'Bearer tok_123');
      return { ok: true, json: async () => ({ tracks: { items: [{ id: 't1', name: 'Song A', artists: [{ name: 'Artist A' }], external_urls: { spotify: 'https://open.spotify.com/track/t1' } }] } }) };
    }
    throw new Error('unexpected URL ' + url);
  });
  const ctx = { secrets: fakeSecrets({ 'plugin:spotify:clientId': 'id', 'plugin:spotify:clientSecret': 'secret' }), signal: undefined };

  const r1 = await spotifyByName['spotify.search'].execute({ query: 'test song' }, ctx);
  assert.equal(r1.results[0].name, 'Song A');
  assert.equal(r1.results[0].artists, 'Artist A');
  assert.equal(calls.filter((u) => u.includes('token')).length, 1);

  // Second call within the token's lifetime should NOT re-fetch a token.
  await spotifyByName['spotify.search'].execute({ query: 'another song' }, ctx);
  assert.equal(calls.filter((u) => u.includes('token')).length, 1, 'token should be cached, not re-fetched');
});
