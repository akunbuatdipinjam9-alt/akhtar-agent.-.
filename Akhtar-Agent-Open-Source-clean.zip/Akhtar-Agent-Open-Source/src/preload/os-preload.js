'use strict';
/**
 * Preload for the dedicated "computer control" tab ONLY — never attached
 * to a regular browser.new_tab tab (those load arbitrary user-supplied
 * URLs and must never get file-system access). See computer/index.js:
 * this preload is only passed to the one named tab that loads the
 * bundled Akhtar OS (or the user's configured Settings → Computer
 * Control URL), and that tab refuses to be redirected elsewhere once open.
 *
 * Exposes `window.akhtarFS`, matching the API os/akhtar-os.html already
 * calls (see src/main/os-fs.js for the exact method list). Every call is
 * forwarded to the main process, which is what actually touches disk —
 * this file only bridges the call, it holds no Node fs access itself.
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('akhtarFS', {
  getRoot: () => ipcRenderer.invoke('osfs:getRoot'),
  list: (path) => ipcRenderer.invoke('osfs:list', path),
  readFile: (path) => ipcRenderer.invoke('osfs:readFile', path),
  writeFile: (path, content) => ipcRenderer.invoke('osfs:writeFile', path, content),
  writeBinary: (path, base64) => ipcRenderer.invoke('osfs:writeBinary', path, base64),
  mkdir: (path) => ipcRenderer.invoke('osfs:mkdir', path),
  delete: (path) => ipcRenderer.invoke('osfs:delete', path),
  exists: (path) => ipcRenderer.invoke('osfs:exists', path),
  migrate: (fileSystemTree) => ipcRenderer.invoke('osfs:migrate', fileSystemTree),
  openRootFolder: () => ipcRenderer.invoke('osfs:openRootFolder'),
});
