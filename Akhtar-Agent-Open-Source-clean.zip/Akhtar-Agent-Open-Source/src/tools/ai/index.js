'use strict';
/** Dual-AI delegation: the primary agent may ask one configured second model for a bounded subtask/review. */
const { LEVEL } = require('../../permissions/levels');
const { createProvider } = require('../../providers/llm');
const { structuredSecondarySystem } = require('../../agent/dual-ai-strategy');

function pickProvider(ctx, requested) {
  const settings = ctx.settings;
  const activeId = settings.activeModel?.providerId;
  const collab = settings.collaboration || {};
  if (collab.mode === 'off') throw new Error('AI collaboration is disabled in Settings.');
  const candidates = settings.providers.filter((p) => p.id !== activeId && (p.type === 'pollinations' || ctx.secrets.has(`llm:${p.id}`)));
  const preferredId = requested || collab.secondaryProviderId || '';
  const cfg = preferredId ? settings.providers.find((p) => p.id === preferredId) : candidates[0];
  if (!cfg) throw new Error(requested ? `Unknown AI provider "${requested}".` : 'No second AI provider is configured. Add another API key in Settings → Models.');
  if (cfg.id === activeId) throw new Error('Delegate must use a different provider from the primary agent.');
  const key = ctx.secrets.get(`llm:${cfg.id}`) || '';
  const provider = createProvider(cfg, key);
  provider.ensureKey();
  return { cfg, provider };
}

module.exports = [{
  name: 'ai.delegate', group: 'ai',
  description: 'Ask a SECOND configured AI model to solve a bounded hard subtask or independently review reasoning/code. Use only when another perspective materially helps; do not delegate trivial work.',
  inputSchema: {
    type: 'object', additionalProperties: false,
    properties: {
      prompt: { type: 'string', description: 'Self-contained subtask for the second AI.' },
      context: { type: 'string', description: 'Only the minimum context the second AI needs. Never include secrets.' },
      role: { type: 'string', enum: ['specialist', 'reviewer', 'critic'], default: 'specialist' },
      provider_id: { type: 'string', description: 'Optional provider id. Must differ from the primary provider.' },
      model: { type: 'string', description: 'Optional model override; otherwise uses provider configured model or first known model.' },
    }, required: ['prompt'],
  },
  permission: LEVEL.NETWORK, category: 'network.ai_delegate',
  preview: async (args) => ({ title: `Ask second AI${args.provider_id ? ` (${args.provider_id})` : ''}`, summary: args.prompt.slice(0, 180), warning: 'The supplied prompt/context is sent to another AI provider.' }),
  timeoutMs: 180000,
  execute: async (args, ctx) => {
    const { cfg, provider } = pickProvider(ctx, args.provider_id);
    const collab = ctx.settings.collaboration || {};
    const model = args.model || (cfg.id === collab.secondaryProviderId ? collab.secondaryModel : '') || cfg.models?.[0];
    if (!model) throw new Error(`No model configured for ${cfg.label}. Choose a model in Settings or pass model.`);
    const system = structuredSecondarySystem(args.role || 'specialist');
    const content = args.context ? `${args.prompt}\n\nContext from primary agent:\n${String(args.context).slice(0, 30000)}` : args.prompt;
    const result = await provider.generate({ model, system, messages: [{ role: 'user', content }], tools: [], signal: ctx.signal, maxTokens: Math.min(ctx.settings.agent.maxOutputTokens || 4096, 8192), temperature: 0.2 });
    return { provider: cfg.id, model, role: args.role || 'specialist', answer: result.text, usage: result.usage || null };
  },
}];
