'use strict';
/**
 * Browser tools (blueprint §10, Phase 8). Two families:
 *  - browser.search / browser.open: plain HTTP fetch, no visible tab —
 *    fast background reads.
 *  - browser.new_tab and friends: drive a real, visible, interactive
 *    browser tab (see src/main/browser-tabs.js) — for pages that need
 *    JavaScript, login, or clicking/typing to reach the content.
 * Interactive tools were written and validated for OOXML-style correctness
 * where that was possible; this part relies on Electron's WebContentsView
 * and could not be exercised on a real display in the environment that
 * built it — see README "What's not battle-tested".
 */
const fs = require('fs');
const path = require('path');
const { LEVEL } = require('../../permissions/levels');
const { fetchJson } = require('../net');
const { truncate, uid } = require('../../utils/misc');
const { slugify } = require('../../utils/slug');
const { OBSERVE_SCRIPT, GET_TEXT_SCRIPT, GET_LINKS_SCRIPT, buildClickScript, buildTypeScript, buildScrollScript } = require('../../main/browser-accessibility');

const MAX_TEXT = 12000;

function stripHtml(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|li|h[1-6]|tr)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

const MAX_FETCH_BYTES = 3 * 1024 * 1024;

/**
 * Hosts a web page must never make the agent fetch: loopback, private LAN, link-local
 * (incl. cloud metadata 169.254.169.254). A prompt-injected page could otherwise use
 * browser.open to probe/attack services on the user's own machine or network.
 */
function isPrivateHost(hostname) {
  const h = String(hostname || '').toLowerCase().replace(/^\[|\]$/g, '');
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h === '0.0.0.0' || h === '::' || h === '::1') return true;
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(h);
  if (m) {
    const [a, b] = [+m[1], +m[2]];
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  if (/^(fc|fd|fe80)/.test(h) || h.startsWith('::ffff:')) return true;
  return false;
}

function assertPublicHttpUrl(u, { allowPrivate = false } = {}) {
  if (!/^https?:$/.test(u.protocol)) throw new Error('Only http/https URLs are allowed.');
  if (!allowPrivate && isPrivateHost(u.hostname)) throw new Error(`Refusing to fetch a local/private network address (${u.hostname}).`);
}

async function fetchText(url, signal) {
  // Follow redirects manually so a public URL can't bounce us onto localhost.
  let current = new URL(url);
  // A URL the user approved as local may stay local; a public URL may never redirect into the LAN.
  const allowPrivate = isPrivateHost(current.hostname);
  let res;
  for (let hop = 0; hop <= 5; hop++) {
    assertPublicHttpUrl(current, { allowPrivate });
    res = await fetch(current, { signal, redirect: 'manual', headers: { 'User-Agent': 'Mozilla/5.0 (AkhtarAgent/1.0)' } });
    if (res.status >= 300 && res.status < 400 && res.headers.get('location')) {
      try { await res.body?.cancel(); } catch { /* ignore */ }
      current = new URL(res.headers.get('location'), current);
      continue;
    }
    break;
  }
  if (res.status >= 300 && res.status < 400) throw new Error('Too many redirects.');
  if (!res.ok) throw new Error(`HTTP ${res.status} fetching ${current}`);
  const ct = res.headers.get('content-type') || '';
  // Read at most MAX_FETCH_BYTES: an endless or huge response must not exhaust memory.
  const chunks = []; let size = 0; let truncatedBody = false;
  if (res.body) {
    const reader = res.body.getReader();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_FETCH_BYTES) { truncatedBody = true; chunks.push(value.subarray(0, value.byteLength - (size - MAX_FETCH_BYTES))); try { await reader.cancel(); } catch { /* ignore */ } break; }
      chunks.push(value);
    }
  }
  const body = Buffer.concat(chunks.map((c) => Buffer.from(c))).toString('utf8');
  return { body, isHtml: ct.includes('html'), finalUrl: current.toString(), truncatedBody };
}

const base = { group: 'browser', permission: LEVEL.NETWORK, category: 'network.browser' };

module.exports = [
  {
    ...base, name: 'browser.search',
    description: 'Search the web and get a list of result titles, URLs and snippets.',
    inputSchema: { type: 'object', properties: { query: { type: 'string', maxLength: 400 } }, required: ['query'] },
    async execute({ query }, ctx) {
      const j = await fetchJson(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`, { signal: ctx.signal });
      const results = [];
      if (j.AbstractURL) results.push({ title: j.Heading || query, url: j.AbstractURL, snippet: j.AbstractText || '' });
      const walk = (topics) => {
        for (const t of topics || []) {
          if (t.FirstURL) results.push({ title: t.Text?.split(' - ')[0] || t.Text, url: t.FirstURL, snippet: t.Text || '' });
          else if (t.Topics) walk(t.Topics);
        }
      };
      walk(j.RelatedTopics);
      if (!results.length) return { query, results: [], note: 'No instant results. Try browser.open on a specific site, or refine the query.' };
      return { query, results: results.slice(0, 10) };
    },
  },
  {
    ...base, name: 'browser.open',
    description: 'Fetch a URL and return its visible text content (HTML tags stripped).',
    inputSchema: { type: 'object', properties: { url: { type: 'string', maxLength: 2000 } }, required: ['url'] },
    async preview({ url }) {
      let host = '';
      try { host = new URL(url).hostname; } catch { /* execute() reports invalid URLs */ }
      // Local/LAN targets (dev servers, router pages, cloud metadata) need their own explicit approval.
      if (host && isPrivateHost(host)) return { title: 'Fetch a local-network address', summary: url, level: LEVEL.SENSITIVE, category: 'network.local', warning: `This reads from ${host} on your own machine/network. Only allow it if you asked for it (e.g. your dev server).` };
      return { title: 'Fetch web page', summary: url };
    },
    async execute({ url }, ctx) {
      let parsed;
      try { parsed = new URL(url); } catch { throw new Error('Invalid URL.'); }
      assertPublicHttpUrl(parsed, { allowPrivate: true }); // local hosts are gated by preview() below
      const { body, isHtml } = await fetchText(parsed.toString(), ctx.signal);
      const titleMatch = isHtml && body.match(/<title[^>]*>([^<]*)<\/title>/i);
      const text = isHtml ? stripHtml(body) : body;
      return { url: parsed.toString(), title: titleMatch ? titleMatch[1].trim() : null, text: truncate(text, MAX_TEXT) };
    },
  },

  // ---------- interactive tab tools ----------
  {
    ...base, name: 'browser.new_tab',
    description: 'Open a new interactive browser tab (JS-rendered, can be clicked/typed into), optionally navigating to a URL. Use this instead of browser.open for pages that need JavaScript or login.',
    inputSchema: { type: 'object', properties: { url: { type: 'string', maxLength: 2000 } } },
    async preview({ url }) { return { title: 'Open browser tab', summary: url || '(blank tab)' }; },
    async execute({ url }, ctx) {
      const tab = ctx.browser.newTab(url);
      if (url) await ctx.browser.waitForLoad(tab.id);
      return ctx.browser.list().find((t) => t.id === tab.id) || tab;
    },
  },
  {
    name: 'browser.list_tabs', group: 'browser', permission: LEVEL.NONE, category: 'none',
    description: 'List currently open interactive browser tabs.',
    inputSchema: { type: 'object', properties: {} },
    async execute(_a, ctx) { return { tabs: ctx.browser.list() }; },
  },
  {
    name: 'browser.close_tab', group: 'browser', permission: LEVEL.NONE, category: 'none',
    description: 'Close an interactive browser tab.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' } } },
    async execute({ tab_id }, ctx) { return ctx.browser.closeTab(tab_id); },
  },
  {
    name: 'browser.switch_tab', group: 'browser', permission: LEVEL.NONE, category: 'none',
    description: 'Make another open tab the active one.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' } }, required: ['tab_id'] },
    async execute({ tab_id }, ctx) { return ctx.browser.switchTab(tab_id); },
  },
  {
    ...base, name: 'browser.navigate',
    description: 'Navigate an interactive tab to a URL (defaults to the active tab).',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' }, url: { type: 'string', maxLength: 2000 } }, required: ['url'] },
    async preview({ url }) { return { title: 'Navigate browser tab', summary: url }; },
    async execute({ tab_id, url }, ctx) {
      const r = ctx.browser.navigate(tab_id, url);
      await ctx.browser.waitForLoad(tab_id || ctx.browser.activeId);
      return r;
    },
  },
  {
    name: 'browser.observe', group: 'browser', permission: LEVEL.NONE, category: 'none',
    description: 'List interactive elements (links, buttons, inputs) currently visible on the tab, each with a numeric id. Call this before browser.click / browser.type — element ids are only valid until the page next changes.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' } } },
    async execute({ tab_id }, ctx) { return ctx.browser.runScript(tab_id, OBSERVE_SCRIPT); },
  },
  {
    name: 'browser.get_text', group: 'browser', permission: LEVEL.NONE, category: 'none',
    description: 'Get the visible text content of the current page in an interactive tab.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' } } },
    async execute({ tab_id }, ctx) { return ctx.browser.runScript(tab_id, GET_TEXT_SCRIPT); },
  },
  {
    name: 'browser.get_links', group: 'browser', permission: LEVEL.NONE, category: 'none',
    description: 'List links (text + href) on the current page in an interactive tab.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' } } },
    async execute({ tab_id }, ctx) { return ctx.browser.runScript(tab_id, GET_LINKS_SCRIPT); },
  },
  {
    name: 'browser.click', group: 'browser', permission: LEVEL.SENSITIVE, category: 'browser.interact',
    description: 'Click an element by the numeric id from browser.observe. Consequential clicks (submit, buy, delete, send) need the user\'s permission, same as any other sensitive action.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' }, id: { type: 'integer', minimum: 0 } }, required: ['id'] },
    async preview({ id }) { return { title: 'Click page element', summary: `element #${id}` }; },
    async execute({ tab_id, id }, ctx) { return ctx.browser.runScript(tab_id, buildClickScript(id)); },
  },
  {
    name: 'browser.type', group: 'browser', permission: LEVEL.SENSITIVE, category: 'browser.interact',
    description: 'Type text into an input/textarea by the numeric id from browser.observe. Set submit=true to submit the form afterwards (e.g. pressing Enter in a search box).',
    inputSchema: {
      type: 'object',
      properties: { tab_id: { type: 'string' }, id: { type: 'integer', minimum: 0 }, text: { type: 'string', maxLength: 5000 }, submit: { type: 'boolean' } },
      required: ['id', 'text'],
    },
    async preview({ id, text }) { return { title: 'Type into page element', summary: `element #${id}: ${truncate(text, 200)}` }; },
    async execute({ tab_id, id, text, submit }, ctx) { return ctx.browser.runScript(tab_id, buildTypeScript(id, text, submit)); },
  },
  {
    name: 'browser.keypress', group: 'browser', permission: LEVEL.SENSITIVE, category: 'browser.interact',
    description: 'Send a single key press to the page (e.g. "Enter", "Escape", "Tab") — useful for submitting forms or dismissing dialogs.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' }, key: { type: 'string', maxLength: 30 } }, required: ['key'] },
    async preview({ key }) { return { title: 'Send key press', summary: key }; },
    async execute({ tab_id, key }, ctx) {
      await ctx.browser.sendKey(tab_id, { type: 'keyDown', keyCode: key });
      await ctx.browser.sendKey(tab_id, { type: 'keyUp', keyCode: key });
      return { ok: true, key };
    },
  },
  {
    name: 'browser.scroll', group: 'browser', permission: LEVEL.NONE, category: 'none',
    description: 'Scroll the page in a direction by a pixel amount (default 600).',
    inputSchema: {
      type: 'object',
      properties: { tab_id: { type: 'string' }, direction: { type: 'string', enum: ['up', 'down', 'left', 'right'] }, amount: { type: 'integer', minimum: 50, maximum: 5000 } },
      required: ['direction'],
    },
    async execute({ tab_id, direction, amount = 600 }, ctx) { return ctx.browser.runScript(tab_id, buildScrollScript(direction, amount)); },
  },
  {
    name: 'browser.wait', group: 'browser', permission: LEVEL.NONE, category: 'none',
    description: 'Wait for the tab to finish loading, or for a fixed number of milliseconds (e.g. after a click that triggers a page change).',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' }, ms: { type: 'integer', minimum: 0, maximum: 30000 } } },
    async execute({ tab_id, ms }, ctx) {
      if (ms) await new Promise((resolve) => setTimeout(resolve, ms));
      else await ctx.browser.waitForLoad(tab_id);
      return { ok: true };
    },
  },
  {
    name: 'browser.vision_rescue', group: 'browser', permission: LEVEL.NETWORK, category: 'network.browser',
    description: 'EXPENSIVE FALLBACK ONLY. After DOM/accessibility/text matching has failed, send one compressed screenshot to the configured vision model to locate a visual target. Limited per task (default 3). Do not call routinely.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' }, goal: { type: 'string', maxLength: 500 } }, required: ['goal'] },
    async preview({ goal }) { return { title: 'Use Browser Vision Rescue', summary: goal, warning: 'Consumes one vision rescue from this task quota.' }; },
    async execute({ tab_id, goal }, ctx) {
      if (!ctx.browserVision) throw new Error('Browser Vision Rescue is unavailable.');
      return ctx.browserVision.inspect({ taskId: ctx.taskId, tabId: tab_id, goal, signal: ctx.signal });
    },
  },
  {
    name: 'browser.click_at', group: 'browser', permission: LEVEL.SENSITIVE, category: 'browser.interact',
    description: 'Click browser viewport coordinates, normally only after browser.vision_rescue identifies a target. Coordinates are in the CURRENT browser viewport.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' }, x: { type: 'integer', minimum: 0 }, y: { type: 'integer', minimum: 0 } }, required: ['x','y'] },
    async preview({ x,y }) { return { title: 'Click visual browser target', summary: `viewport (${x}, ${y})` }; },
    async execute({ tab_id, x, y }, ctx) {
      ctx.browser.sendInputEvent(tab_id, { type:'mouseMove', x, y });
      ctx.browser.sendInputEvent(tab_id, { type:'mouseDown', x, y, button:'left', clickCount:1 });
      ctx.browser.sendInputEvent(tab_id, { type:'mouseUp', x, y, button:'left', clickCount:1 });
      return { ok:true, x, y };
    },
  },
  {
    name: 'browser.screenshot', group: 'browser', permission: LEVEL.NONE, category: 'none',
    description: 'Capture a screenshot of the current tab and save it as an artifact.',
    inputSchema: { type: 'object', properties: { tab_id: { type: 'string' } } },
    async execute({ tab_id }, ctx) {
      const png = await ctx.browser.capturePng(tab_id);
      const dir = ctx.workspace ? path.join(ctx.workspace.root_path, 'akhtar-artifacts') : ctx.artifactsDir;
      fs.mkdirSync(dir, { recursive: true });
      const filePath = path.join(dir, `screenshot-${slugify(String(Date.now()))}-${uid().slice(0, 6)}.png`);
      fs.writeFileSync(filePath, png);
      const artifact = ctx.artifacts.create({ workspaceId: ctx.workspaceId, taskId: ctx.taskId, name: path.basename(filePath), path: filePath, type: 'image' });
      return { artifactId: artifact.id, path: filePath, verified: fs.existsSync(filePath) };
    },
  },
];

module.exports._internals = { isPrivateHost, fetchText };
