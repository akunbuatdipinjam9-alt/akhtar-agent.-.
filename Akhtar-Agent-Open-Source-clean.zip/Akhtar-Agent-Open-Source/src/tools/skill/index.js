'use strict';
/** Skill tools: let the agent discover and load SKILL.md prompts (blueprint §46). */
const { LEVEL } = require('../../permissions/levels');

const base = { group: 'skill', permission: LEVEL.NONE, category: 'none' };

module.exports = [
  {
    ...base, name: 'skill.list',
    description: 'List available skills (specialised instructions) with their descriptions.',
    inputSchema: { type: 'object', properties: {} },
    async execute(_a, ctx) { return { skills: ctx.skills.list().map(({ name, description }) => ({ name, description })) }; },
  },
  {
    ...base, name: 'skill.load',
    description: 'Load a skill\'s full instructions by name before doing that kind of work.',
    inputSchema: { type: 'object', properties: { name: { type: 'string' } }, required: ['name'] },
    async execute({ name }, ctx) {
      const s = ctx.skills.get(name);
      if (!s) throw new Error(`Skill "${name}" not found. Call skill.list to see options.`);
      return { name: s.name, instructions: s.body };
    },
  },
];
