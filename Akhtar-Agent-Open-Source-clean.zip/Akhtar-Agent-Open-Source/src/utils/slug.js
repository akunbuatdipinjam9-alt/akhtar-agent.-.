'use strict';
const fs = require('fs');
const path = require('path');

function slugify(s, fallback = 'untitled') {
  const slug = String(s || '')
    .normalize('NFKD').replace(/[\u0300-\u036f]/g, '') // "Résumé" -> "resume" instead of "r-sum"
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
  return slug || fallback;
}

/**
 * Pick a slug that no existing artifact uses yet. Titles in non-Latin scripts all slugify to
 * "untitled", and repeating a title reused the same name: the new document silently
 * overwrote the previous one (no checkpoint, no warning).
 */
function uniqueSlug(dir, base, exts) {
  const taken = (slug) => exts.some((ext) => fs.existsSync(path.join(dir, `${slug}${ext}`)));
  if (!taken(base)) return base;
  for (let i = 2; i < 10000; i++) { const s = `${base}-${i}`; if (!taken(s)) return s; }
  return `${base}-${Date.now()}`;
}

module.exports = { slugify, uniqueSlug };
