'use strict';
/* Renderer — talks to main only through window.akhtar (see preload.js). No Node here. */

const el = (id) => document.getElementById(id);
const messagesEl = el('messages');
const emptyState = el('emptyState');
const convList = el('convList');
const todoList = el('todoList');
const activityLog = el('activityLog');
const timelineEl = el('timeline');
const input = el('input');
const sendBtn = el('sendBtn');
const stopBtn = el('stopBtn');
const takeoverBtn = el('takeoverBtn');
const continueBtn = el('continueBtn');
const topbarStatus = el('topbarStatus');

const state = {
  settings: null,
  workspace: null,
  conversationId: null,
  mode: 'assist',
  running: false,
  takenOver: false,
  streamBubble: null,
  streamText: '',
  toolCards: new Map(),
  permQueue: [],
  permBusy: false,
  visionUsed: 0,
  visionMax: 3,
  currentTaskId: null,
  ghost: null,
};

// ---------- tiny markdown (escape first, then a few safe replacements) ----------
function escapeHtml(s) {
  // Also escape quotes: this is used inside attribute values (title="…").
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function mdToHtml(text) {
  const parts = String(text || '').split(/```([\s\S]*?)```/g);
  return parts.map((chunk, i) => {
    if (i % 2 === 1) {
      const nl = chunk.indexOf('\n');
      const code = nl === -1 ? chunk : chunk.slice(nl + 1);
      return `<pre><code>${escapeHtml(code.replace(/\n$/, ''))}</code></pre>`;
    }
    let h = escapeHtml(chunk);
    h = h.replace(/`([^`\n]+)`/g, '<code>$1</code>');
    h = h.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    return h;
  }).join('');
}

// ---------- message rendering ----------
function clearEmptyState() { emptyState.classList.add('hidden'); }

function addUserBubble(text) {
  clearEmptyState();
  const div = document.createElement('div');
  div.className = 'msg user';
  div.innerHTML = `<div class="bubble">${mdToHtml(text)}</div>`;
  messagesEl.appendChild(div);
  scrollDown();
}

function startAssistantBubble() {
  clearEmptyState();
  const div = document.createElement('div');
  div.className = 'msg assistant';
  div.innerHTML = `<div class="bubble"></div>`;
  messagesEl.appendChild(div);
  state.streamBubble = div.querySelector('.bubble');
  state.streamText = '';
  scrollDown();
  return div;
}

function appendStreamDelta(delta) {
  if (!state.streamBubble) startAssistantBubble();
  state.streamText += delta;
  // Re-rendering the whole bubble on every token is O(n^2) and freezes the UI on long
  // answers; render at most once per animation frame.
  if (state.streamFrame) return;
  state.streamFrame = requestAnimationFrame(() => {
    state.streamFrame = null;
    if (state.streamBubble) { state.streamBubble.innerHTML = mdToHtml(state.streamText); scrollDown(); }
  });
}

function finalizeStreamBubble() {
  if (state.streamFrame) { cancelAnimationFrame(state.streamFrame); state.streamFrame = null; }
  if (state.streamBubble) state.streamBubble.innerHTML = mdToHtml(state.streamText);
  state.streamBubble = null;
  state.streamText = '';
}

function toolCard(call) {
  clearEmptyState();
  const div = document.createElement('div');
  div.className = 'tool-card';
  div.innerHTML = `<span class="tool-status running">berjalan</span><span class="tool-name">${escapeHtml(call.name)}</span>
    <div class="tool-args">${escapeHtml(JSON.stringify(call.arguments || {}))}</div>`;
  messagesEl.appendChild(div);
  state.toolCards.set(call.id, div);
  scrollDown();
  return div;
}

function toolCardDone(call, ok, resultOrError) {
  const div = state.toolCards.get(call.id);
  if (!div) return;
  const status = div.querySelector('.tool-status');
  status.textContent = ok ? 'selesai' : 'gagal';
  status.className = `tool-status ${ok ? 'success' : 'error'}`;
  if (!ok) {
    const errEl = document.createElement('div');
    errEl.className = 'tool-args';
    errEl.style.color = 'var(--danger)';
    errEl.textContent = resultOrError;
    div.appendChild(errEl);
  }
}

function scrollDown() { messagesEl.scrollTop = messagesEl.scrollHeight; }

function logActivity(text) {
  const row = document.createElement('div');
  row.textContent = text;
  activityLog.prepend(row);
  while (activityLog.children.length > 60) activityLog.removeChild(activityLog.lastChild);
}


function renderVisionBudget() {
  const max = Number(state.visionMax || state.settings?.browserVision?.maxCallsPerTask || 3);
  const used = Math.min(max, Number(state.visionUsed || 0));
  const remaining = Math.max(0, max - used);
  if (el('visionRemaining')) el('visionRemaining').textContent = String(remaining);
  const meter = el('visionDots');
  if (meter) {
    meter.innerHTML = '';
    for (let i=0;i<max;i++) { const d=document.createElement('i'); if (i < used) d.classList.add('used'); meter.appendChild(d); }
  }
  if (el('visionModeBadge')) el('visionModeBadge').textContent = used ? 'VISION' : 'DOM';
}


async function refreshTimeline(taskId = state.currentTaskId) {
  if (!timelineEl) return;
  if (!taskId) { timelineEl.innerHTML = '<div class="muted">Jejak muncul saat tugas berjalan.</div>'; return; }
  const res = await window.akhtar.getTaskTimeline({ taskId });
  if (!res.ok) return;
  timelineEl.innerHTML = '';
  const rows = res.data || [];
  if (!rows.length) { timelineEl.innerHTML = '<div class="muted">Belum ada event.</div>'; return; }
  for (const item of rows.slice(-80)) {
    const row = document.createElement('div'); row.className = 'timeline-row';
    const time = item.created_at ? new Date(item.created_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'}) : '';
    const label = item.kind === 'tool' ? `${item.status === 'success' ? '✓' : item.status === 'error' ? '✗' : '→'} ${item.name}` : (item.message || item.type || 'event');
    row.innerHTML = `<span class="timeline-dot"></span><div class="timeline-copy"><div>${escapeHtml(label)}</div><span>${escapeHtml(time)}</span></div>${item.kind === 'event' ? '<button class="mini-action timeline-fork" title="Fork from this point">Fork</button>' : ''}`;
    const fork = row.querySelector('.timeline-fork'); if (fork) fork.onclick = () => forkCurrentTask(item.id);
    timelineEl.appendChild(row);
  }
  timelineEl.scrollTop = timelineEl.scrollHeight;
}
if (el('refreshTimeline')) el('refreshTimeline').addEventListener('click', () => refreshTimeline());
async function forkCurrentTask(eventId = null) {
  if (!state.currentTaskId) return;
  const r = await window.akhtar.forkTask({ taskId: state.currentTaskId, eventId });
  if (!r.ok) return logActivity(`Fork gagal: ${r.error}`);
  state.conversationId = r.data.id; await loadConversations(); await selectConversation(r.data.id); logActivity('Replay fork created — original run preserved.');
}
el('forkTaskBtn')?.addEventListener('click', () => forkCurrentTask());
el('diagnoseTaskBtn')?.addEventListener('click', async () => {
  if (!state.currentTaskId) return;
  const r = await window.akhtar.diagnoseTask({ taskId: state.currentTaskId }); if (!r.ok) return logActivity(`Diagnose gagal: ${r.error}`);
  const d=r.data, div=document.createElement('div'); div.className='diagnostic-card';
  div.innerHTML=`<h4>Agent Black Box</h4><p><strong>${escapeHtml(d.task.status.toUpperCase())}</strong> · ${d.counts.events} timeline entries · ${d.counts.errors} error(s)</p><div>${escapeHtml(d.summary)}</div><p>${escapeHtml((d.suggestions||[]).join(' · '))}</p>`;
  messagesEl.appendChild(div); scrollDown();
});

// ---------- todos ----------
function renderTodos(todos) {
  todoList.innerHTML = '';
  if (!todos || !todos.length) { todoList.innerHTML = '<li class="muted">Belum ada tugas yang berjalan.</li>'; return; }
  for (const t of todos) {
    const li = document.createElement('li');
    li.innerHTML = `<span class="todo-status ${t.status}"></span><span>${escapeHtml(t.title)}</span>`;
    todoList.appendChild(li);
  }
}
async function refreshTodos(taskId) {
  if (!taskId) return;
  const res = await window.akhtar.listTodos({ taskId });
  if (res.ok) renderTodos(res.data);
}

// ---------- artifacts & checkpoints ----------
async function refreshArtifacts() {
  const list = el('artifactList');
  const res = await window.akhtar.listArtifacts({ workspaceId: state.workspace?.id || null });
  if (!res.ok) return;
  list.innerHTML = '';
  if (!res.data.length) { list.innerHTML = '<li class="muted">Belum ada artifact.</li>'; return; }
  for (const a of res.data.slice(0, 30)) {
    const li = document.createElement('li');
    const isChart = a.type === 'chart';
    li.innerHTML = `<span class="name" title="${escapeHtml(a.path)}">${escapeHtml(a.name)}</span><button data-open>${isChart ? 'Lihat' : 'Buka'}</button>`;
    li.querySelector('button').onclick = () => isChart ? openChartArtifact(a.id) : window.akhtar.openArtifact({ path: a.path });
    list.appendChild(li);
  }
}
async function refreshCheckpoints() {
  const list = el('checkpointList');
  if (!state.workspace) { list.innerHTML = '<li class="muted">Buka workspace dulu.</li>'; return; }
  const res = await window.akhtar.listCheckpoints({ workspaceId: state.workspace.id });
  if (!res.ok) return;
  list.innerHTML = '';
  if (!res.data.length) { list.innerHTML = '<li class="muted">Belum ada checkpoint.</li>'; return; }
  for (const c of res.data.slice(0, 20)) {
    const li = document.createElement('li');
    const when = new Date(c.created_at).toLocaleString('id-ID');
    const restored = c.restored_at ? ' (sudah di-restore)' : '';
    li.innerHTML = `<span class="name" title="${when}">${when}${restored}</span><button data-restore title="Kembalikan file seperti sebelum tugas ini">Batalkan</button>`;
    li.querySelector('button').onclick = async () => {
      if (!confirm('Kembalikan file ke kondisi sebelum checkpoint ini?')) return;
      const r = await window.akhtar.restoreCheckpoint({ id: c.id });
      if (r.ok) { logActivity('Checkpoint direstore.'); refreshCheckpoints(); }
      else alert('Gagal restore: ' + r.error);
    };
    list.appendChild(li);
  }
}


let activeArtifactChart = null;
async function openChartArtifact(artifactId) {
  const res = await window.akhtar.getChartArtifact({ artifactId });
  if (!res.ok) return logActivity(`Chart gagal dibuka: ${res.error}`);
  const spec = res.data.spec;
  el('chartModalTitle').textContent = spec.title || 'Visualization';
  el('chartModal').classList.remove('hidden');
  if (activeArtifactChart) activeArtifactChart.destroy();
  const ctx = el('artifactChart').getContext('2d');
  activeArtifactChart = new Chart(ctx, {
    type: spec.type,
    data: { labels: spec.labels || [], datasets: spec.datasets || [] },
    options: { responsive: true, maintainAspectRatio: false, ...(spec.options || {}) }
  });
}
el('closeChartModal').onclick = () => { el('chartModal').classList.add('hidden'); if (activeArtifactChart) { activeArtifactChart.destroy(); activeArtifactChart = null; } };
el('chartModal').addEventListener('click', (e) => { if (e.target === el('chartModal')) el('closeChartModal').click(); });

// ---------- embedded browser panel ----------
const browserBody = el('browserBody');
const browserSurface = el('browserSurface');
const browserTabstrip = el('browserTabstrip');
const browserAddress = el('browserAddress');
let browserTabs = [];
let currentView = 'chat';

function activeBrowserTab() { return browserTabs.find((t) => t.active) || null; }

function renderBrowserTabs(tabs) {
  browserTabs = tabs || [];
  browserTabstrip.innerHTML = '';
  el('browserEmpty').classList.toggle('hidden', browserTabs.length > 0);
  for (const t of browserTabs) {
    const chip = document.createElement('div');
    chip.className = 'browser-tab' + (t.active ? ' active' : '');
    chip.innerHTML = `<span class="t-title">${escapeHtml(t.loading ? 'Memuat…' : (t.title || t.url || 'Tab baru'))}</span><span class="t-close">✕</span>`;
    chip.addEventListener('click', () => window.akhtar.switchBrowserTab({ tabId: t.id }));
    chip.querySelector('.t-close').addEventListener('click', (e) => { e.stopPropagation(); window.akhtar.closeBrowserTab({ tabId: t.id }); });
    browserTabstrip.appendChild(chip);
  }
  const active = activeBrowserTab();
  if (active && document.activeElement !== browserAddress) browserAddress.value = active.url === 'about:blank' ? '' : active.url;
}
window.akhtar.onBrowserTabsChanged(renderBrowserTabs);

function reportBrowserBounds() {
  if (currentView !== 'browser') return;
  const r = browserSurface.getBoundingClientRect();
  window.akhtar.setBrowserBounds({ bounds: { x: Math.round(r.x), y: Math.round(r.y), width: Math.round(r.width), height: Math.round(r.height) } });
}
new ResizeObserver(reportBrowserBounds).observe(browserSurface);
window.addEventListener('resize', reportBrowserBounds);

function setView(view) {
  currentView = view;
  document.querySelectorAll('.view-btn').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
  document.querySelector('.body').style.display = view === 'chat' ? 'flex' : 'none';
  browserBody.style.display = view === 'browser' ? 'flex' : 'none';
  if (typeof mapBody !== 'undefined' && mapBody) mapBody.style.display = view === 'map' ? 'flex' : 'none';
  window.akhtar.setBrowserVisible({ visible: view === 'browser' });
  if (view === 'map') setTimeout(() => ensureMap()?.invalidateSize(), 0);
  if (view === 'browser') requestAnimationFrame(reportBrowserBounds);
}
document.querySelectorAll('.view-btn').forEach((btn) => btn.addEventListener('click', () => setView(btn.dataset.view)));

async function browserGo() {
  const url = browserAddress.value.trim();
  if (!url) return;
  const active = activeBrowserTab();
  if (active) await window.akhtar.navigateBrowserTab({ tabId: active.id, url });
  else await window.akhtar.newBrowserTab({ url });
}
el('browserGo').addEventListener('click', browserGo);
browserAddress.addEventListener('keydown', (e) => { if (e.key === 'Enter') browserGo(); });
el('browserNewTab').addEventListener('click', () => window.akhtar.newBrowserTab({}));
el('browserBack').addEventListener('click', () => { const t = activeBrowserTab(); if (t) window.akhtar.browserBack({ tabId: t.id }); });
el('browserForward').addEventListener('click', () => { const t = activeBrowserTab(); if (t) window.akhtar.browserForward({ tabId: t.id }); });
el('browserReload').addEventListener('click', () => { const t = activeBrowserTab(); if (t) window.akhtar.browserReload({ tabId: t.id }); });

// ---------- downloads ----------
const downloadRows = new Map();
function renderDownloadRow(d) {
  const list = el('downloadList');
  let row = downloadRows.get(d.id);
  if (!row) {
    if (list.querySelector('.muted')) list.innerHTML = '';
    row = document.createElement('li');
    row.innerHTML = `<span class="name"></span><span class="dl-actions"></span>`;
    list.appendChild(row);
    downloadRows.set(d.id, row);
  }
  const pct = d.totalBytes ? Math.round((d.receivedBytes / d.totalBytes) * 100) : 0;
  row.querySelector('.name').textContent = `${d.filename} — ${d.state}${d.state === 'progressing' ? ` ${pct}%` : ''}`;
  const actions = row.querySelector('.dl-actions');
  actions.innerHTML = '';
  const addBtn = (label, fn) => { const b = document.createElement('button'); b.textContent = label; b.onclick = fn; actions.appendChild(b); };
  if (d.state === 'progressing') { addBtn('Pause', () => window.akhtar.pauseDownload({ id: d.id })); addBtn('Cancel', () => window.akhtar.cancelDownload({ id: d.id })); }
  else if (d.state === 'paused') addBtn('Resume', () => window.akhtar.resumeDownload({ id: d.id }));
}
window.akhtar.onDownloadEvent(renderDownloadRow);

// ---------- schedules ----------
async function refreshSchedules() {
  const list = el('scheduleList');
  const res = await window.akhtar.listSchedules({ workspaceId: state.workspace?.id || null });
  if (!res.ok) return;
  list.innerHTML = '';
  if (!res.data.length) { list.innerHTML = '<li class="muted">Belum ada jadwal.</li>'; return; }
  for (const s of res.data) {
    const li = document.createElement('li');
    const when = s.recurrence === 'once' ? new Date(s.run_at).toLocaleString('id-ID') : `${s.recurrence} ${s.time || ''} ${s.day_of_week || (s.day_of_month ? 'tgl ' + s.day_of_month : '')}`.trim();
    li.title = s.instruction;
    li.innerHTML = `<span class="name">${escapeHtml(s.title)} — ${escapeHtml(when)}${s.enabled ? '' : ' (pause)'}</span><span class="dl-actions"></span>`;
    const actions = li.querySelector('.dl-actions');
    const toggleBtn = document.createElement('button');
    toggleBtn.textContent = s.enabled ? 'Pause' : 'Resume';
    toggleBtn.onclick = async () => { await window.akhtar.setScheduleEnabled({ id: s.id, enabled: !s.enabled }); refreshSchedules(); };
    const delBtn = document.createElement('button');
    delBtn.textContent = 'Hapus';
    delBtn.onclick = async () => { if (confirm(`Hapus jadwal "${s.title}"?`)) { await window.akhtar.removeSchedule({ id: s.id }); refreshSchedules(); } };
    actions.appendChild(toggleBtn); actions.appendChild(delBtn);
    list.appendChild(li);
  }
}
window.akhtar.onScheduleEvent((ev) => {
  if (ev.type === 'task_end') { refreshSchedules(); logActivity(`⏰ ${ev.status === 'completed' ? 'Jadwal selesai' : 'Jadwal ' + ev.status}`); }
});

// ---------- agent events ----------
function setRunning(running) {
  state.running = running;
  if (!running) state.takenOver = false;
  sendBtn.classList.toggle('hidden', running);
  stopBtn.classList.toggle('hidden', !running);
  takeoverBtn.classList.toggle('hidden', !running || state.takenOver);
  continueBtn.classList.toggle('hidden', !running || !state.takenOver);
  topbarStatus.textContent = running ? (state.takenOver ? 'Kamu yang memegang kendali' : 'Agen sedang bekerja…') : '';
  document.body.classList.toggle('is-running', running && !state.takenOver);
}
function setTakenOver(value) {
  state.takenOver = value;
  setRunning(state.running);
}

window.akhtar.onAgentEvent((ev) => {
  // Track the running conversation regardless of which one is on screen. Previously, switching
  // conversations mid-run dropped the task_end event, state.running stayed true forever and no
  // message could be sent anywhere until the app was restarted.
  if (ev.type === 'task_start') state.runningConversationId = ev.conversationId;
  if ((ev.type === 'task_end' || ev.type === 'fatal_error') && ev.conversationId === state.runningConversationId) {
    state.runningConversationId = null;
    if (ev.conversationId !== state.conversationId) { setRunning(false); logActivity(ev.type === 'task_end' && ev.status === 'completed' ? 'Tugas di percakapan lain selesai.' : 'Tugas di percakapan lain berhenti.'); }
  }
  if (ev.conversationId !== state.conversationId) return;
  switch (ev.type) {
    case 'task_start':
      state.currentTaskId = ev.task?.id || null;
      state.visionUsed = 0; state.visionMax = state.settings?.browserVision?.maxCallsPerTask || 3; renderVisionBudget();
      setRunning(true);
      renderTodos([]);
      refreshTimeline();
      break;
    case 'text_delta':
      appendStreamDelta(ev.delta);
      break;
    case 'assistant_message':
      finalizeStreamBubble();
      break;
    case 'stream_reset':
      // The model call is being retried: drop the partial text instead of showing it twice.
      if (state.streamFrame) { cancelAnimationFrame(state.streamFrame); state.streamFrame = null; }
      state.streamText = '';
      if (state.streamBubble) state.streamBubble.innerHTML = '';
      break;
    case 'model_retry':
      logActivity(`Model sibuk/error — mencoba lagi (${ev.attempt}) dalam ${Math.round(ev.waitMs / 1000)} detik`);
      break;
    case 'knowledge':
      logActivity(`Knowledge: ${ev.count} relevant chunk(s)`);
      refreshTimeline();
      break;
    case 'takeover_requested':
      topbarStatus.textContent = 'Take over requested…';
      logActivity('Take over requested — waiting for a safe point');
      break;
    case 'takeover_started':
      setTakenOver(true);
      logActivity(`Take over — agent paused ${ev.label ? 'at ' + ev.label : ''}`);
      refreshTimeline();
      break;
    case 'takeover_ended':
      setTakenOver(false);
      logActivity('Control returned to agent');
      break;
    case 'context_compressed':
      logActivity(`Context compressed: ~${ev.savedChars} chars saved`);
      refreshTimeline();
      break;
    case 'tool_call_start':
      logActivity(`→ ${ev.call.name}`);
      toolCard(ev.call);
      refreshTimeline();
      break;
    case 'tool_call_end':
      toolCardDone(ev.call, ev.ok, ev.ok ? undefined : ev.error);
      if (ev.call?.name === 'browser.vision_rescue' && ev.ok && ev.result?.quota) { state.visionUsed = ev.result.quota.used; state.visionMax = ev.result.quota.max; renderVisionBudget(); }
      logActivity(`${ev.ok ? '✓' : '✗'} ${ev.call.name}`);
      refreshTodos(state.currentTaskId);
      refreshTimeline();
      break;
    case 'task_end':
      finalizeStreamBubble(); // a stopped/failed run must not leave a half bubble for the next run to append to
      state.currentTaskId = ev.task?.id || null;
      refreshTodos(state.currentTaskId);
      refreshArtifacts();
      refreshCheckpoints();
      refreshTimeline();
      setRunning(false);
      if (ev.status === 'failed' && ev.error) {
        const div = document.createElement('div');
        div.className = 'tool-card';
        div.style.borderColor = 'var(--danger)';
        div.textContent = `Tugas gagal: ${ev.error}`;
        messagesEl.appendChild(div);
        scrollDown();
      }
      break;
    case 'fatal_error':
      finalizeStreamBubble();
      setRunning(false);
      break;
    default:
      break;
  }
});

// ---------- permission dialog ----------
const permOverlay = el('permissionOverlay');
window.akhtar.onPermissionRequest((payload) => {
  state.permQueue.push(payload);
  drainPermQueue();
});
window.akhtar.onPermissionCancel?.(({ id }) => {
  state.permQueue = state.permQueue.filter((r) => r.id !== id);
  if (state.permCurrentId === id) {
    permOverlay.classList.add('hidden');
    state.permBusy = false; state.permCurrentId = null;
    drainPermQueue();
  }
});
function drainPermQueue() {
  if (state.permBusy || !state.permQueue.length) return;
  state.permBusy = true;
  const req = state.permQueue.shift();
  state.permCurrentId = req.id;
  el('permTitle').textContent = req.title || req.name;
  el('permSummary').textContent = [req.command, req.path, req.summary].filter(Boolean).join('\n') || '(tidak ada detail tambahan)';
  const diffEl = el('permDiff');
  if (req.diff) { diffEl.textContent = req.diff; diffEl.classList.remove('hidden'); } else diffEl.classList.add('hidden');
  const warnEl = el('permWarning');
  if (req.warning) { warnEl.textContent = req.warning; warnEl.classList.remove('hidden'); } else warnEl.classList.add('hidden');
  el('permAllowAlways').classList.toggle('hidden', !req.allowAlways);
  el('permAllowProject').classList.toggle('hidden', !req.allowProject || req.allowAlways);
  permOverlay.classList.remove('hidden');
  const respond = (decision) => {
    if (state.permCurrentId !== req.id) return; // dialog was already cancelled by the run
    state.permCurrentId = null;
    permOverlay.classList.add('hidden');
    window.akhtar.respondPermission(req.id, decision);
    state.permBusy = false;
    drainPermQueue();
  };
  el('permAllowOnce').onclick = () => respond('allow_once');
  el('permAllowAlways').onclick = () => respond('allow_always');
  el('permAllowProject').onclick = () => respond('allow_project');
  el('permDeny').onclick = () => respond('deny');
}

// ---------- sending ----------
async function ensureConversation() {
  if (state.conversationId) return state.conversationId;
  const res = await window.akhtar.createConversation({ workspaceId: state.workspace?.id || null, mode: state.mode });
  if (!res.ok) throw new Error(res.error);
  state.conversationId = res.data.id;
  await loadConversations();
  selectConversation(state.conversationId, { skipLoad: true });
  return state.conversationId;
}

async function sendMessage() {
  const text = input.value.trim();
  if (!text || state.running) return;
  const showError = (msg) => {
    const div = document.createElement('div');
    div.className = 'tool-card';
    div.style.borderColor = 'var(--danger)';
    div.textContent = `Error: ${msg}`;
    messagesEl.appendChild(div);
    scrollDown();
  };
  setRunning(true); // block double-send (Enter spam) while the conversation is being created
  try {
    await ensureConversation();
  } catch (e) {
    setRunning(false);
    showError(e.message); // keep the typed text in the box: nothing was sent
    return;
  }
  input.value = '';
  autoResize();
  addUserBubble(text);
  let res;
  try {
    res = await window.akhtar.sendMessage({ conversationId: state.conversationId, workspaceId: state.workspace?.id || null, mode: state.mode, text });
  } catch (e) { res = { ok: false, error: e.message }; }
  if (!res.ok) {
    setRunning(false);
    showError(res.error);
  }
}
sendBtn.addEventListener('click', sendMessage);
takeoverBtn.addEventListener('click', async () => {
  if (!state.conversationId || !state.running) return;
  takeoverBtn.disabled = true;
  const res = await window.akhtar.takeOverAgent({ conversationId: state.conversationId });
  takeoverBtn.disabled = false;
  if (!res.ok) logActivity(`Take over gagal: ${res.error}`);
});
continueBtn.addEventListener('click', async () => {
  if (!state.conversationId || !state.running) return;
  const res = await window.akhtar.continueAgent({ conversationId: state.conversationId });
  if (!res.ok) logActivity(`Continue gagal: ${res.error}`);
});
stopBtn.addEventListener('click', () => window.akhtar.stopAgent({ conversationId: state.conversationId }));
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});
function autoResize() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 180) + 'px'; }
input.addEventListener('input', autoResize);

// ---------- conversations ----------
async function loadConversations() {
  const res = await window.akhtar.listConversations({ workspaceId: state.workspace?.id || null });
  convList.innerHTML = '';
  if (!res.ok) return;
  state.convModes = new Map(res.data.map((c) => [c.id, c.mode]));
  for (const c of res.data) {
    const div = document.createElement('div');
    div.className = 'conv-item' + (c.id === state.conversationId ? ' active' : '');
    div.textContent = c.title || 'Percakapan baru';
    div.title = c.title || '';
    div.onclick = () => selectConversation(c.id);
    convList.appendChild(div);
  }
}

async function selectConversation(id, { skipLoad } = {}) {
  // Drop references to bubbles/cards of the conversation we're leaving (they get detached below);
  // otherwise coming back mid-run streams into an invisible, detached node.
  if (!skipLoad) { if (state.streamFrame) cancelAnimationFrame(state.streamFrame); state.streamFrame = null; state.streamBubble = null; state.streamText = ''; state.toolCards.clear(); }
  state.conversationId = id;
  // Each conversation remembers its own mode; the switch used to keep the previous one's.
  const convMode = state.convModes?.get(id);
  if (convMode && convMode !== state.mode) applyMode(convMode, { persist: false });
  [...convList.children].forEach((c) => c.classList.remove('active'));
  const res = skipLoad ? { ok: true, data: [] } : await window.akhtar.listMessages({ conversationId: id });
  messagesEl.innerHTML = '';
  if (res.ok && res.data.length) {
    clearEmptyState();
    for (const m of res.data) {
      if (m.role === 'user') addUserBubble(m.content);
      else if (m.role === 'assistant' && m.content) {
        const div = document.createElement('div');
        div.className = 'msg assistant';
        div.innerHTML = `<div class="bubble">${mdToHtml(m.content)}</div>`;
        messagesEl.appendChild(div);
      }
    }
  } else if (!res.data || !res.data.length) {
    emptyState.classList.remove('hidden');
  }
  loadConversations();
  scrollDown();
}

el('newChatBtn').addEventListener('click', async () => {
  const res = await window.akhtar.createConversation({ workspaceId: state.workspace?.id || null, mode: state.mode });
  if (res.ok) { state.conversationId = res.data.id; messagesEl.innerHTML = ''; emptyState.classList.remove('hidden'); renderTodos([]); await loadConversations(); }
});

// ---------- workspace ----------
el('workspaceBtn').addEventListener('click', async () => {
  const res = await window.akhtar.openWorkspace();
  if (res.ok && res.data) {
    const changed = state.workspace?.id !== res.data.id;
    state.workspace = res.data;
    el('workspaceName').textContent = res.data.name;
    if (changed && !state.running) {
      // Messages would otherwise keep going into the previous project's conversation.
      state.conversationId = null; messagesEl.innerHTML = ''; emptyState.classList.remove('hidden'); renderTodos([]);
    }
    await loadConversations();
    await refreshArtifacts();
    await refreshCheckpoints();
  }
});

// ---------- Ghost Workspace ----------
function renderGhost() { const b=el('ghostBanner'); b?.classList.toggle('hidden', !state.ghost); if(state.ghost) el('workspaceName').textContent = `${state.workspace?.name || 'Project'} (salinan)`; }
el('ghostCreateBtn')?.addEventListener('click', async () => {
  if (!state.workspace) return logActivity('Pilih folder project dulu, baru buat salinan aman.');
  if (state.ghost) return;
  const source=state.workspace; const r=await window.akhtar.createGhostWorkspace({workspaceId:source.id});
  if(!r.ok) return logActivity(`Salinan gagal dibuat: ${r.error}`);
  state.ghost={...r.data,source}; state.workspace=r.data.workspace; state.conversationId=null; renderGhost(); await loadConversations(); logActivity('Salinan aman siap. Perubahan belum menyentuh project asli.');
});
el('ghostApplyBtn')?.addEventListener('click', async () => {
  if(!state.ghost || !confirm('Terapkan semua perubahan dari salinan ke project asli?')) return;
  let r=await window.akhtar.applyGhostWorkspace({ghostId:state.ghost.id});
  if(!r.ok && /Ghost apply blocked/.test(r.error||'')){
    // Files changed in the real project meanwhile — never overwrite without an explicit second confirmation.
    if(!confirm(`${r.error}\n\nTimpa file-file itu dengan versi dari salinan?`)) return logActivity('Apply dibatalkan: ada konflik dengan project asli.');
    r=await window.akhtar.applyGhostWorkspace({ghostId:state.ghost.id, force:true});
  }
  if(!r.ok) return logActivity(`Apply gagal: ${r.error}`);
  const source=state.ghost.source; await window.akhtar.discardGhostWorkspace({ghostId:state.ghost.id}); state.ghost=null; state.workspace=source; el('workspaceName').textContent=source.name; renderGhost(); await loadConversations(); logActivity(`Diterapkan: ${r.data.applied} perubahan.`);
});
el('ghostDiscardBtn')?.addEventListener('click', async () => {
  if(!state.ghost || !confirm('Buang salinan ini beserta semua perubahannya?')) return;
  const source=state.ghost.source; await window.akhtar.discardGhostWorkspace({ghostId:state.ghost.id}); state.ghost=null; state.workspace=source; el('workspaceName').textContent=source.name; renderGhost(); await loadConversations(); logActivity('Salinan dibuang.');
});

// ---------- mode switch ----------
const MODE_HINTS = {
  chat: 'Hanya menjawab. Agen tidak membuka atau mengubah file.',
  assist: 'Agen minta izin setiap kali mau mengubah sesuatu.',
  agent: 'Agen bekerja sendiri. Izin yang kamu beri untuk project ini akan diingat.',
};
function applyMode(mode, { persist = true } = {}) {
  if (!MODE_HINTS[mode]) mode = 'assist';
  state.mode = mode;
  document.querySelectorAll('.mode-btn').forEach((b) => {
    const on = b.dataset.mode === mode;
    b.classList.toggle('active', on);
    b.setAttribute('aria-checked', String(on));
  });
  if (el('modeHint')) el('modeHint').textContent = MODE_HINTS[mode];
  if (persist && state.conversationId) window.akhtar.setConversationMode({ id: state.conversationId, mode });
  if (state.convModes && state.conversationId) state.convModes.set(state.conversationId, mode);
}
document.querySelectorAll('.mode-btn').forEach((btn) => btn.addEventListener('click', () => applyMode(btn.dataset.mode)));

// ---------- side panel tabs & toggle ----------
document.querySelectorAll('.panel-tab').forEach((tab) => tab.addEventListener('click', () => {
  document.querySelectorAll('.panel-tab').forEach((t) => { t.classList.toggle('active', t === tab); t.setAttribute('aria-selected', String(t === tab)); });
  document.querySelectorAll('.panel-page').forEach((p) => p.classList.toggle('hidden', p.dataset.page !== tab.dataset.panel));
  if (tab.dataset.panel === 'history') refreshTimeline();
}));
(function initPanelToggle() {
  const btn = el('panelToggle'); const body = document.querySelector('.body');
  if (!btn || !body) return;
  let collapsed = false;
  try { collapsed = localStorage.getItem('akhtar.panelCollapsed') === '1'; } catch { /* storage unavailable */ }
  const narrow = () => window.matchMedia('(max-width: 980px)').matches;
  const apply = () => {
    body.classList.toggle('panel-collapsed', collapsed && !narrow());
    body.classList.toggle('panel-open', !collapsed && narrow());
    btn.setAttribute('aria-pressed', String(!collapsed));
  };
  if (narrow()) collapsed = true;
  btn.addEventListener('click', () => { collapsed = !collapsed; try { localStorage.setItem('akhtar.panelCollapsed', collapsed ? '1' : '0'); } catch { /* ignore */ } apply(); });
  window.addEventListener('resize', apply);
  apply();
})();

// ---------- starter prompts ----------
document.querySelectorAll('.starter').forEach((b) => b.addEventListener('click', () => {
  input.value = b.dataset.prompt || b.textContent; autoResize(); input.focus();
  input.setSelectionRange(input.value.length, input.value.length);
}));

// ---------- Ask About Anything On Screen ----------
el('askScreenBtn')?.addEventListener('click', async () => {
  const tab=activeBrowserTab(); if(!tab) return logActivity('Buka tab browser dulu.');
  topbarStatus.textContent='Klik bagian halaman yang ingin ditanyakan…';
  const r=await window.akhtar.askBrowserScreen({tabId:tab.id}); topbarStatus.textContent='';
  if(!r.ok) return logActivity(`Ask Screen gagal: ${r.error}`);
  const x=r.data; setView('chat'); input.value=`About this screen element on ${x.url}:
- tag: ${x.tag}
- role: ${x.role || 'none'}
- label/text: ${x.aria || x.text || '(none)'}
- link: ${x.href || 'none'}

Explain what this is and help me with it.`; autoResize(); input.focus();
});

// ---------- provider / model selects ----------
const providerSelect = el('providerSelect');
const modelSelect = el('modelSelect');

function renderProviderOptions() {
  providerSelect.innerHTML = '';
  for (const p of state.settings.providers) {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.label + (!p.requiresKey || p.hasKey ? '' : ' (no key)');
    providerSelect.appendChild(opt);
  }
  providerSelect.value = state.settings.activeModel.providerId;
  renderModelOptions();
}
function renderModelOptions() {
  const p = state.settings.providers.find((x) => x.id === providerSelect.value);
  modelSelect.innerHTML = '';
  const models = (p?.models || []).slice();
  if (state.settings.activeModel.model && !models.includes(state.settings.activeModel.model)) models.unshift(state.settings.activeModel.model);
  for (const m of models) {
    const opt = document.createElement('option');
    opt.value = m; opt.textContent = m;
    modelSelect.appendChild(opt);
  }
  const custom = document.createElement('option');
  custom.value = '__custom__'; custom.textContent = 'Model lain…';
  modelSelect.appendChild(custom);
  if (p?.id === providerSelect.value && state.settings.activeModel.providerId === p?.id) modelSelect.value = state.settings.activeModel.model || '__custom__';
}
providerSelect.addEventListener('change', async () => {
  renderModelOptions();
  const model = modelSelect.value === '__custom__' ? '' : modelSelect.value;
  await saveActiveModel(providerSelect.value, model);
});
modelSelect.addEventListener('change', async () => {
  let model = modelSelect.value;
  if (model === '__custom__') {
    model = prompt('Nama model:', '') || '';
    if (!model) { renderModelOptions(); return; }
  }
  await saveActiveModel(providerSelect.value, model);
});
async function saveActiveModel(providerId, model) {
  const res = await window.akhtar.updateSettings({ activeModel: { providerId, model } });
  if (res.ok) {
    state.settings = res.data;
    if (el('setSecondaryProvider')) renderSecondaryProviderOptions();
  }
}

// ---------- AI collaboration settings ----------
function availableSecondaryProviders() {
  const activeId = state.settings?.activeModel?.providerId;
  return (state.settings?.providers || []).filter((p) => p.id !== activeId && (!p.requiresKey || p.hasKey));
}

function renderSecondaryProviderOptions() {
  const select = el('setSecondaryProvider');
  if (!select || !state.settings) return;
  const collab = state.settings.collaboration || {};
  const providers = availableSecondaryProviders();
  select.innerHTML = '';

  const auto = document.createElement('option');
  auto.value = '';
  auto.textContent = 'Otomatis — pilih AI lain yang sudah diatur';
  select.appendChild(auto);

  for (const p of providers) {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.label;
    select.appendChild(opt);
  }
  select.value = providers.some((p) => p.id === collab.secondaryProviderId) ? collab.secondaryProviderId : '';
  renderSecondaryModelOptions();
}

function renderSecondaryModelOptions() {
  const providerSel = el('setSecondaryProvider');
  const modelSel = el('setSecondaryModel');
  if (!providerSel || !modelSel || !state.settings) return;
  const providerId = providerSel.value;
  const collab = state.settings.collaboration || {};
  modelSel.innerHTML = '';

  const automatic = document.createElement('option');
  automatic.value = '';
  automatic.textContent = providerId ? 'Auto — provider default / first model' : 'Auto';
  modelSel.appendChild(automatic);

  const p = state.settings.providers.find((x) => x.id === providerId);
  const models = (p?.models || []).slice();
  if (providerId === collab.secondaryProviderId && collab.secondaryModel && !models.includes(collab.secondaryModel)) {
    models.unshift(collab.secondaryModel);
  }
  for (const m of models) {
    const opt = document.createElement('option');
    opt.value = m;
    opt.textContent = m;
    modelSel.appendChild(opt);
  }
  const custom = document.createElement('option');
  custom.value = '__custom__';
  custom.textContent = 'Custom model…';
  modelSel.appendChild(custom);
  modelSel.value = providerId === collab.secondaryProviderId ? (collab.secondaryModel || '') : '';
}

function updateCollabDisabledState() {
  const off = el('setCollabMode')?.value === 'off';
  if (el('setSecondaryProvider')) el('setSecondaryProvider').disabled = off;
  if (el('setSecondaryModel')) el('setSecondaryModel').disabled = off;
  if (el('refreshSecondaryModels')) el('refreshSecondaryModels').disabled = off;
}

async function saveCollaboration(patch) {
  const res = await window.akhtar.updateSettings({ collaboration: patch });
  if (res.ok) {
    state.settings = res.data;
    renderSecondaryProviderOptions();
    updateCollabDisabledState();
  }
}

el('setCollabMode').addEventListener('change', async (e) => {
  await saveCollaboration({ mode: e.target.value });
});
el('setSecondaryProvider').addEventListener('change', async (e) => {
  await saveCollaboration({ secondaryProviderId: e.target.value, secondaryModel: '' });
});
el('setSecondaryModel').addEventListener('change', async (e) => {
  let model = e.target.value;
  if (model === '__custom__') {
    model = prompt('Nama model second AI:', '') || '';
    if (!model) { renderSecondaryModelOptions(); return; }
  }
  await saveCollaboration({ secondaryModel: model });
});
el('refreshSecondaryModels').addEventListener('click', async () => {
  const providerId = el('setSecondaryProvider').value;
  if (!providerId) return;
  const btn = el('refreshSecondaryModels');
  const old = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'Refreshing…';
  try {
    const res = await window.akhtar.listModels({ providerId });
    if (!res.ok) throw new Error(res.error);
    const p = state.settings.providers.find((x) => x.id === providerId);
    if (p && Array.isArray(res.data.models)) p.models = res.data.models;
    renderSecondaryModelOptions();
  } catch (e) {
    alert('Gagal memuat model: ' + e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = old;
    updateCollabDisabledState();
  }
});

// ---------- Browser Vision settings ----------
function renderVisionProviderOptions() {
  const select = el('setVisionProvider'); if (!select || !state.settings) return;
  const eligible = (state.settings.providers || []).filter(p => ['openai','openrouter','openai-compatible','local'].includes(p.type));
  select.innerHTML = '<option value="">Same as primary model</option>';
  for (const p of eligible) { const o=document.createElement('option'); o.value=p.id; o.textContent=p.label; select.appendChild(o); }
  select.value = state.settings.browserVision?.providerId || '';
}
async function saveVisionSettings(patch) {
  const res = await window.akhtar.updateSettings({ browserVision: patch });
  if (res.ok) { state.settings=res.data; state.visionMax=res.data.browserVision.maxCallsPerTask; renderVisionBudget(); }
}
el('setVisionMode').addEventListener('change', e => saveVisionSettings({mode:e.target.value}));
el('setVisionMax').addEventListener('change', e => saveVisionSettings({maxCallsPerTask:Number(e.target.value)}));
el('setVisionProvider').addEventListener('change', e => saveVisionSettings({providerId:e.target.value}));
el('setVisionModel').addEventListener('change', e => saveVisionSettings({model:e.target.value.trim()}));

// ---------- settings dialog ----------
const settingsOverlay = el('settingsOverlay');
el('settingsBtn').addEventListener('click', openSettings);
el('settingsClose').addEventListener('click', () => settingsOverlay.classList.add('hidden'));
function showSettingsSection(name) {
  document.querySelectorAll('.settings-nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.section === name));
  document.querySelectorAll('.settings-page').forEach((p) => p.classList.toggle('hidden', p.dataset.section !== name));
}
document.querySelectorAll('.settings-nav-btn').forEach((b) => b.addEventListener('click', () => showSettingsSection(b.dataset.section)));
settingsOverlay.addEventListener('mousedown', (e) => { if (e.target === settingsOverlay) settingsOverlay.classList.add('hidden'); });
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (!settingsOverlay.classList.contains('hidden')) settingsOverlay.classList.add('hidden');
  else if (!el('chartModal')?.classList.contains('hidden')) el('chartModal').classList.add('hidden');
});

async function openSettings() {
  const rows = el('providerRows');
  rows.innerHTML = '';
  for (const p of state.settings.providers) {
    const row = document.createElement('div');
    row.className = 'provider-row';
    if (!p.requiresKey) {
      row.classList.add('no-key');
      row.innerHTML = `
      <span class="p-label">${escapeHtml(p.label)}</span>
      <span class="field-hint" style="flex:1;margin:0;">${p.type === 'supabase-openai' ? 'Tidak perlu kunci API. Cukup masuk di bagian Akun &amp; kredit.' : 'Tidak perlu kunci API.'}</span>`;
    } else {
      row.innerHTML = `
      <span class="p-label">${escapeHtml(p.label)}</span>
      <input type="password" class="text-input" placeholder="Tempel kunci API" data-provider="${p.id}" />
      <span class="p-status ${p.hasKey ? 'on' : ''}">${p.hasKey ? 'Tersimpan' : 'Belum diisi'}</span>
      <button class="btn" data-save="${p.id}">Simpan</button>`;
    }
    rows.appendChild(row);
  }
  rows.querySelectorAll('button[data-save]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.save;
      const input2 = rows.querySelector(`input[data-provider="${id}"]`);
      if (!input2.value) return;
      const res = await window.akhtar.setApiKey({ providerId: id, apiKey: input2.value });
      if (res.ok) { input2.value = ''; const status = input2.parentElement.querySelector('.p-status'); status.textContent = 'Tersimpan'; status.classList.add('on'); const p = state.settings.providers.find((x) => x.id === id); if (p) p.hasKey = true; renderProviderOptions(); }
    });
  });
  el('setMaxIter').value = state.settings.agent.maxIterations;
  el('setRunTimeout').value = state.settings.agent.runTimeoutMin;
  el('setCollabMode').value = state.settings.collaboration?.mode || 'auto';
  renderSecondaryProviderOptions();
  updateCollabDisabledState();
  renderVisionProviderOptions();
  el('setVisionMode').value = state.settings.browserVision?.mode || 'smart';
  el('setVisionMax').value = state.settings.browserVision?.maxCallsPerTask || 3;
  el('setVisionModel').value = state.settings.browserVision?.model || '';
  el('setOsUrl').value = state.settings.computerControl?.osUrl || '';
  el('setMcpServers').value = JSON.stringify(state.settings.mcp?.servers || [], null, 2);
  const ghStatus = el('githubTokenStatus');
  const ghHas = await window.akhtar.hasSecret({ name: 'github:token' });
  ghStatus.textContent = ghHas.ok && ghHas.data.has ? 'Tersimpan' : 'Belum diisi';
  ghStatus.classList.toggle('on', ghHas.ok && ghHas.data.has);
  renderLoadedPlugins();
  await loadBilling();
    settingsOverlay.classList.remove('hidden');
}
el('setMaxIter').addEventListener('change', async (e) => {
  const res = await window.akhtar.updateSettings({ agent: { maxIterations: +e.target.value } });
  if (res.ok) state.settings = res.data;
});
el('setRunTimeout').addEventListener('change', async (e) => {
  const res = await window.akhtar.updateSettings({ agent: { runTimeoutMin: +e.target.value } });
  if (res.ok) state.settings = res.data;
});
el('setOsUrl').addEventListener('change', async (e) => {
  const res = await window.akhtar.updateSettings({ computerControl: { osUrl: e.target.value.trim() } });
  if (res.ok) state.settings = res.data;
});
el('saveMcpServers').addEventListener('click', async () => {
  const status = el('mcpStatus');
  try {
    const servers = JSON.parse(el('setMcpServers').value || '[]');
    if (!Array.isArray(servers)) throw new Error('Harus JSON array.');
    for (const s of servers) {
      if (!s || typeof s.id !== 'string' || !s.id.trim()) throw new Error('Setiap server perlu id.');
      if ((s.transport || 'stdio') !== 'stdio') throw new Error('MCP v1 Akhtar Agent baru mendukung transport stdio.');
      if (typeof s.command !== 'string' || !s.command.trim()) throw new Error(`Server ${s.id} perlu command.`);
    }
    const res = await window.akhtar.updateSettings({ mcp: { servers } });
    if (!res.ok) throw new Error(res.error);
    state.settings = res.data;
    await window.akhtar.resetMcp();
    status.textContent = `Tersimpan: ${servers.length} server.`;
  } catch (e) { status.textContent = `Error: ${e.message}`; }
});
el('saveGithubToken').addEventListener('click', async () => {
  const input = el('setGithubToken');
  if (!input.value) return;
  const res = await window.akhtar.setSecret({ name: 'github:token', value: input.value });
  if (res.ok) {
    input.value = '';
    const status = el('githubTokenStatus');
    status.textContent = 'Tersimpan';
    status.classList.add('on');
  }
});
el('savePluginSecret').addEventListener('click', async () => {
  const nameInput = el('pluginSecretName');
  const valueInput = el('pluginSecretValue');
  if (!nameInput.value.trim() || !valueInput.value) return;
  const res = await window.akhtar.setSecret({ name: nameInput.value.trim(), value: valueInput.value });
  const status = el('pluginSecretStatus');
  if (res.ok) { status.textContent = `Tersimpan: ${nameInput.value.trim()}`; nameInput.value = ''; valueInput.value = ''; }
  else { status.textContent = `Gagal: ${res.error}`; }
});
function renderLoadedPlugins() {
  const el2 = el('loadedPluginsList');
  if (!el2) return;
  const list = state.plugins?.loaded || [];
  el2.textContent = list.length ? `Plugin aktif: ${list.map((p) => `${p.name} (${p.toolCount} tool)`).join(', ')}` : 'Belum ada plugin di folder plugins/.';
}

// ---------- boot ----------
(async function boot() {
  const res = await window.akhtar.bootstrap();
  if (!res.ok) { topbarStatus.textContent = 'Gagal memuat aplikasi: ' + res.error; return; }
  state.settings = res.data.settings;
  state.plugins = res.data.plugins;
  renderProviderOptions();
  state.visionMax = state.settings.browserVision?.maxCallsPerTask || 3; renderVisionBudget();
  if (res.data.workspaces?.length) {
    state.workspace = res.data.workspaces[0];
    el('workspaceName').textContent = state.workspace.name;
  }
  await loadConversations();
  await refreshArtifacts();
  await refreshCheckpoints();
  const dls = await window.akhtar.listDownloads();
  if (dls.ok) dls.data.forEach(renderDownloadRow);
  const tabs = await window.akhtar.listBrowserTabs();
  if (tabs.ok) renderBrowserTabs(tabs.data);
  await refreshSchedules();
})();

// ---------- Billing & plan ----------
const billingUi = { overview:null, planId:null, method:null, session:null };
function moneyIDR(n){ return Number(n||0)===0 ? 'Rp0' : new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n); }
function renderBilling(){
  const grid=el('billingPlanGrid'), methods=el('billingMethods'), btn=el('billingCheckoutBtn');
  if(!grid||!methods||!billingUi.overview) return;
  grid.innerHTML='';
  for(const p of billingUi.overview.plans){
    const card=document.createElement('button'); card.type='button'; card.className='billing-plan-card'+(billingUi.planId===p.id?' selected':'');
    card.innerHTML=`<div class="plan-name">${escapeHtml(p.name)}</div><div class="plan-price">${escapeHtml(moneyIDR(p.price))}<span class="field-hint"> / bulan</span></div><div class="plan-copy">${escapeHtml(p.description)}</div>`;
    card.addEventListener('click',()=>{ billingUi.planId=p.id; renderBilling(); }); grid.appendChild(card);
  }
  methods.innerHTML='';
  for(const m of billingUi.overview.paymentMethods){
    const row=document.createElement('label'); row.className='billing-method'+(billingUi.method===m.id?' selected':'');
    row.innerHTML=`<input type="radio" name="billingMethod" value="${escapeHtml(m.id)}" ${billingUi.method===m.id?'checked':''}><span>${escapeHtml(m.label)}</span>`;
    row.addEventListener('click',()=>{ billingUi.method=m.id; renderBilling(); }); methods.appendChild(row);
  }
  const plan=billingUi.overview.plans.find(p=>p.id===billingUi.planId);
  btn.disabled=!plan || plan.id==='free' || !billingUi.method;
  const auth=el('billingAuthStatus'), form=el('billingAuthForm'), out=el('billingSignOut'); if(auth){auth.textContent=billingUi.session?.signedIn ? `Masuk sebagai ${billingUi.session.user.email}` : 'Masuk untuk memakai kredit dan upgrade paket.'; form?.classList.toggle('hidden',!!billingUi.session?.signedIn); out?.classList.toggle('hidden',!billingUi.session?.signedIn);} btn.disabled=btn.disabled || !billingUi.session?.signedIn;
  // Say why the button is disabled instead of leaving it greyed out without explanation.
  const st=el('billingCheckoutStatus'); if(st && !billingUi.checkoutStarted){ st.textContent = !billingUi.session?.signedIn ? 'Masuk dulu untuk upgrade paket.' : (plan?.id==='free' ? 'Paket Gratis tidak perlu pembayaran.' : 'Pembayaran diproses aman lewat Stripe di browser.'); }
}
async function loadBilling(){
  const sess=await window.akhtar.authSession(); billingUi.session=sess.ok?sess.data:{signedIn:false,user:null};
  const creditEl=el('creditBalance'), rewardEl=el('creditRewardStatus');
  if(billingUi.session?.signedIn){
    const cr=await window.akhtar.creditsClaimLogin();
    if(cr.ok && cr.data?.wallet){ if(creditEl) creditEl.textContent=Number(cr.data.wallet.balance).toLocaleString(); if(rewardEl) rewardEl.textContent='Bonus: +21 per hari, +42 per bulan, dan +423 saat pertama kali masuk.'; }
    else if(rewardEl) rewardEl.textContent=cr.error||'Kredit belum bisa dimuat. Coba lagi sebentar.';
  } else { if(creditEl) creditEl.textContent='—'; if(rewardEl) rewardEl.textContent='Masuk untuk melihat kredit.'; }
  const res=await window.akhtar.billingOverview(); if(!res.ok){ el('billingCheckoutStatus').textContent=res.error; return; }
  billingUi.overview=res.data; billingUi.planId=billingUi.planId||'plus'; billingUi.method='stripe'; renderBilling();
}
el('billingCheckoutBtn')?.addEventListener('click',async()=>{
  const status=el('billingCheckoutStatus'); billingUi.checkoutStarted=true; status.textContent='Menyiapkan pembayaran…';
  const res=await window.akhtar.createCheckout({planId:billingUi.planId,method:billingUi.method});
  if(!res.ok){ status.textContent=res.error; return; }
  const d=res.data; status.textContent=d.status==='setup_required' ? `${moneyIDR(d.amount)} · ${d.message}` : `Payment ${d.status}`;
});


async function billingAuth(mode){const email=el('billingEmail')?.value.trim(),password=el('billingPassword')?.value||'',status=el('billingAuthStatus');if(!email||password.length<6){status.textContent='Isi email dan kata sandi (minimal 6 karakter).';return;}status.textContent=mode==='signin'?'Sedang masuk…':'Membuat akun…';const res=mode==='signin'?await window.akhtar.authSignIn({email,password}):await window.akhtar.authSignUp({email,password,displayName:email.split('@')[0]});if(!res.ok){status.textContent=res.error;return;}if(res.data.confirmationRequired){status.textContent='Akun dibuat. Buka email konfirmasi, lalu masuk.';return;}await loadBilling();}
el('billingSignIn')?.addEventListener('click',()=>billingAuth('signin'));
el('billingSignUp')?.addEventListener('click',()=>billingAuth('signup'));
el('billingSignOut')?.addEventListener('click',async()=>{await window.akhtar.authSignOut();await loadBilling();});

// ---------- interactive map + live navigation ----------
const mapBody = el('mapBody');
let mapUi=null, mapUserMarker=null, mapRouteLayers=[], mapMarkers=new Map(), mapWatchId=null, mapDestination=null;
function ensureMap(){
  if(mapUi||!window.L)return mapUi;
  mapUi=L.map('mapCanvas',{zoomControl:true}).setView([-6.2,106.8],10);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(mapUi);
  return mapUi;
}
function mapSetStatus(t){el('mapStatus').textContent=t;}
function mapShowRoutes(routes){const m=ensureMap();if(!m)return;mapRouteLayers.forEach(x=>m.removeLayer(x));mapRouteLayers=[];(routes||[]).forEach((r,i)=>{const layer=L.polyline(r.geometry.map(p=>[p.latitude,p.longitude]),{weight:i?4:7,opacity:i?.45:.9}).addTo(m);mapRouteLayers.push(layer);if(i===0&&r.geometry.length)m.fitBounds(layer.getBounds(),{padding:[35,35]});});if(routes?.[0])mapSetStatus(`Fastest estimated route: ${routes[0].distance_km} km · ${routes[0].duration_min} min · no live traffic data`);}
function startLocationWatch(){if(mapWatchId!=null)return;if(!navigator.geolocation){mapSetStatus('Location is not supported on this system.');return;}mapWatchId=navigator.geolocation.watchPosition(async pos=>{const c=pos.coords,loc={latitude:c.latitude,longitude:c.longitude,accuracy:c.accuracy,heading:c.heading,speed:c.speed};await window.akhtar.mapLocation(loc);const m=ensureMap();if(m){if(!mapUserMarker)mapUserMarker=L.circleMarker([c.latitude,c.longitude],{radius:8,weight:3}).addTo(m).bindPopup('Your location');else mapUserMarker.setLatLng([c.latitude,c.longitude]);}},err=>mapSetStatus(`Location unavailable: ${err.message}`),{enableHighAccuracy:true,maximumAge:3000,timeout:12000});}
el('mapLocateBtn')?.addEventListener('click',()=>{startLocationWatch();setTimeout(()=>{if(mapUserMarker){ensureMap().setView(mapUserMarker.getLatLng(),16);mapUserMarker.openPopup();}},800)});
el('mapSearchBtn')?.addEventListener('click',()=>{const q=el('mapSearch').value.trim();if(!q){el('mapSearch').focus();return;}input.value=`Tunjukkan ${q} di peta`;autoResize();setView('chat');input.focus();});
el('mapSearch')?.addEventListener('keydown',(e)=>{if(e.key==='Enter')el('mapSearchBtn').click();});
function stopLocationWatch(){if(mapWatchId!=null&&navigator.geolocation){navigator.geolocation.clearWatch(mapWatchId);}mapWatchId=null;}
// Stopping navigation used to leave GPS tracking running (and reporting location) forever.
el('mapStopNavBtn')?.addEventListener('click',async()=>{await window.akhtar.mapNavigationStop({});stopLocationWatch();el('mapNavCard').classList.add('hidden');el('mapStopNavBtn').classList.add('hidden')});
window.akhtar.onMapEvent((e)=>{const m=ensureMap();if(!m)return;if(e.type==='open'){setView('map');if(e.point)m.setView([e.point.latitude,e.point.longitude],e.zoom||14)}else if(e.type==='view_set')m.setView([e.latitude,e.longitude],e.zoom||m.getZoom());else if(e.type==='marker_add'){const mk=L.marker([e.marker.latitude,e.marker.longitude]).addTo(m);if(e.marker.label)mk.bindPopup(e.marker.label).openPopup();mapMarkers.set(e.marker.id,mk)}else if(e.type==='marker_clear'){mapMarkers.forEach(x=>m.removeLayer(x));mapMarkers.clear()}else if(e.type==='routes')mapShowRoutes(e.routes);else if(e.type==='navigation_start'){setView('map');startLocationWatch();mapDestination=e.session.to;mapShowRoutes([e.session.route]);el('mapNavCard').classList.remove('hidden');el('mapStopNavBtn').classList.remove('hidden');el('mapNavTitle').textContent='Navigation active';el('mapNavEta').textContent=`${e.session.route.distance_km} km · ${e.session.route.duration_min} min`;const step=e.session.route.steps?.[0];el('mapNavNext').textContent=step?`${step.instruction} ${step.name}`:''}else if(e.type==='navigation_progress'){el('mapNavEta').textContent=`~${e.session.remaining_km} km · ~${e.session.eta_min} min`;if(e.offRouteM>120)mapSetStatus('Off route — recalculating…')}else if(e.type==='navigation_stop'){stopLocationWatch();el('mapNavCard').classList.add('hidden');el('mapStopNavBtn').classList.add('hidden')}});
