'use strict';
/**
 * Context Manager (blueprint §Agent Core). Builds the object every tool's
 * execute()/preview() receives, and trims conversation history to the
 * configured character budget (blueprint §7 — never dump whole projects
 * or full history into the LLM context).
 */

function createToolContext(app, { workspace, workspaceId, taskId, mode, signal, onOutput, unattended = false }) {
  return {
    db: app.db,
    workspace: workspace || null,
    workspaceId: workspaceId || null,
    taskId: taskId || null,
    mode,
    signal,
    unattended,
    onOutput: onOutput || (() => {}),
    settings: app.settings.get(),
    skills: app.skills,
    todo: app.todo,
    memory: app.memory,
    checkpoints: app.checkpoints,
    artifacts: app.artifacts,
    artifactsDir: app.artifactsDir,
    secrets: app.secrets,
    browser: app.browserTabs,
    browserVision: app.browserVision,
    osBundleUrl: app.osBundleUrl,
    osPreloadPath: app.osPreloadPath,
    scheduler: app.scheduler,
    mcp: app.mcp,
    knowledge: app.knowledge,
  };
}

/** Keep the most recent messages within a character budget; always keep the latest user turn. */
function budgetMessages(messages, budgetChars) {
  let total = 0;
  const kept = [];
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    const len = (m.content || '').length + JSON.stringify(m.toolCalls || '').length;
    if (kept.length > 0 && total + len > budgetChars) break;
    total += len;
    kept.unshift(m);
  }
  return kept.length ? kept : messages.slice(-1);
}

/**
 * Make a history window provider-safe. Every provider rejects:
 *  - a tool result whose tool call is not in the window (budget/compression cut it off),
 *  - an assistant tool call with no matching result (run was stopped / crashed mid-tool),
 *  - (Anthropic) a history that does not start with a user turn.
 * Without this, one Stop press or one context trim leaves the conversation permanently
 * failing with HTTP 400 on every later message.
 */
function repairToolPairs(messages) {
  const src = Array.isArray(messages) ? messages : [];
  const out = [];
  for (let i = 0; i < src.length; i++) {
    const m = src[i];
    if (m.role === 'tool') continue; // emitted only right after their assistant message
    if (m.role === 'assistant' && Array.isArray(m.toolCalls) && m.toolCalls.length) {
      const ids = new Set(m.toolCalls.map((c) => c.id));
      const results = new Map();
      let j = i + 1;
      for (; j < src.length && src[j].role === 'tool'; j++) {
        if (ids.has(src[j].toolCallId) && !results.has(src[j].toolCallId)) results.set(src[j].toolCallId, src[j]);
      }
      out.push(m);
      for (const c of m.toolCalls) {
        out.push(results.get(c.id) || { role: 'tool', toolCallId: c.id, toolName: c.name, content: JSON.stringify({ error: 'Tool call was interrupted before it returned a result.', interrupted: true }) });
      }
      i = j - 1;
      continue;
    }
    out.push(m);
  }
  while (out.length && out[0].role !== 'user') out.shift();
  return out.length ? out : src.filter((m) => m.role === 'user').slice(-1);
}

module.exports = { createToolContext, budgetMessages, repairToolPairs };
