'use strict';
/** Tool Router + Executor (blueprint Agent Core, §13, §54). One controlled tool call. */
const { assertValid } = require('../utils/schema');
const { logger } = require('../utils/logger');
const { AbortError } = require('../utils/misc');
const { evaluateTool } = require('../security/guard');
const { tokenize } = require('../tools/terminal/classifier');
const { withRetry, verifyToolResult, classifyError } = require('./stability');

function withTimeout(operation, timeoutMs, parentSignal) {
  const ctrl = new AbortController();
  let timer = null;
  let onAbortRace = null;
  const abort = (reason) => { if (!ctrl.signal.aborted) ctrl.abort(reason); };
  const onParent = () => abort(parentSignal?.reason?.name === 'AbortError' ? parentSignal.reason : new AbortError('aborted'));
  if (parentSignal) { if (parentSignal.aborted) onParent(); else parentSignal.addEventListener('abort', onParent, { once:true }); }
  if (timeoutMs) timer = setTimeout(() => abort(new AbortError('timeout')), timeoutMs);
  // Race the operation against the abort signal: a tool that ignores ctx.signal must
  // still NOT be able to hang the agent past its timeout or report a late "success".
  const aborted = new Promise((_, reject) => {
    onAbortRace = () => reject(ctrl.signal.reason?.name === 'AbortError' ? ctrl.signal.reason : new AbortError('aborted'));
    if (ctrl.signal.aborted) onAbortRace(); else ctrl.signal.addEventListener('abort', onAbortRace, { once:true });
  });
  aborted.catch(() => {});
  let run;
  try { run = typeof operation === 'function' ? operation(ctrl.signal) : operation; }
  catch (e) { run = Promise.reject(e); }
  const guarded = Promise.resolve(run).catch((e)=>{
    if (ctrl.signal.aborted && ctrl.signal.reason?.name === 'AbortError') throw ctrl.signal.reason;
    throw e;
  });
  guarded.catch(() => {}); // late rejection after the race was lost must not become unhandled
  return Promise.race([guarded, aborted]).finally(() => {
    if (timer) clearTimeout(timer);
    if (parentSignal) parentSignal.removeEventListener('abort', onParent);
    ctrl.signal.removeEventListener('abort', onAbortRace);
  });
}

/**
 * Runs one tool call end-to-end: validate → preview → permission check → execute → log.
 * `conversationId` is only used for the tool_calls log row.
 */
const FILE_CONTENT_TOOLS = new Set(['file.write', 'file.create', 'file.edit']);

/**
 * Hard security check — runs before the permission system is even
 * consulted. Returns matched hazard labels (empty = clean). See
 * src/security/guard.js for what this does and does not catch.
 */
function securityScan(toolName, args) {
  const verdict = evaluateTool(toolName, args || {});
  if (!verdict || verdict.decision !== 'ALLOW') {
    return verdict?.hazards?.length ? verdict.hazards : ['guard returned an invalid/unsafe verdict'];
  }
  return [];
}

/**
 * @returns {Promise<{exit_code, signal, timed_out, cancelled, duration_ms, stdout, stderr}>}
 */
async function executeTool(app, toolName, args, ctx, conversationId) {
  const tool = app.registry.get(toolName);
  if (!tool) throw new Error(`Unknown tool "${toolName}". Call the right tool from your available list.`);
  assertValid(tool.inputSchema, args || {}, toolName);

  const hazards = securityScan(toolName, args);
  if (hazards.length) {
    logger.agent('error', `SECURITY LAYER blocked ${toolName}`, { hazards });
    const err = new Error(`Diblokir oleh security layer (bukan bisa di-override lewat izin): ${hazards.join('; ')}. Kalau ini keliru untuk kebutuhan legitimate, kerjakan bagian ini secara manual di luar agent.`);
    err.securityBlocked = true;
    if (ctx.taskId) app.tasks.addEvent(ctx.taskId, 'security_blocked', err.message, { tool: toolName, hazards });
    throw err;
  }

  let preview = null;
  if (tool.preview) preview = await tool.preview(args, ctx);

  const level = preview?.level || (typeof tool.permission === 'function' ? tool.permission(args, ctx) : tool.permission);
  const category = preview?.category || tool.category || tool.group;

  const logId = ctx.taskId ? app.tasks.logToolCall({ taskId: ctx.taskId, conversationId, name: toolName, args }) : null;
  try {
    const decision = await (ctx.unattended
      ? app.permissions.checkUnattended({ level, category, workspaceId: ctx.workspaceId, lifetime: tool.lifetimePermission === true })
      : app.permissions.check({
        level, category, mode: ctx.mode, workspaceId: ctx.workspaceId, signal: ctx.signal, lifetime: tool.lifetimePermission === true,
        request: {
          name: toolName, title: preview?.title || toolName, summary: preview?.summary,
          diff: preview?.diff, warning: preview?.warning, command: preview?.command, path: preview?.path,
        },
      }));
    if (!decision.allowed) {
      const err = new Error(decision.reason || `Permission denied for ${toolName}.`);
      err.permissionDenied = true;
      throw err;
    }
    const timeoutMs = typeof tool.timeoutMs === 'function' ? tool.timeoutMs(args, ctx) : (tool.timeoutMs || 120000);
    if (logId) app.tasks.setToolCallState?.(logId, 'running');
    const result = await withRetry(async (attempt) => withTimeout((toolSignal) => tool.execute(args, { ...ctx, app, signal: toolSignal, attempt }), timeoutMs, ctx.signal), {
      retries: tool.retryable === false ? 0 : 2, signal: ctx.signal, onRetry: (e, attempt) => {
        if (ctx.taskId) app.tasks.addEvent(ctx.taskId, 'tool_retry', `${toolName} transient failure; retry ${attempt}/2`, { tool: toolName, error: e.message, attempt });
      },
    });
    if (logId) app.tasks.setToolCallState?.(logId, 'verifying');
    const verification = await verifyToolResult(tool, args, result, ctx);
    const verifiedResult = (result && typeof result === 'object') ? { ...result, _verification: verification } : result;
    if (logId) app.tasks.finishToolCall(logId, { status: 'success', result: verifiedResult });
    return verifiedResult;
  } catch (e) {
    logger.tools('error', `${toolName} failed`, { message: e.message });
    if (logId) { const kind = classifyError(e); app.tasks.finishToolCall(logId, { status: kind === 'timeout' ? 'timeout' : kind === 'cancelled' ? 'cancelled' : e.securityBlocked ? 'blocked' : 'failed', result: { error: e.message } }); }
    throw e;
  }
}

module.exports = { executeTool, withTimeout };
