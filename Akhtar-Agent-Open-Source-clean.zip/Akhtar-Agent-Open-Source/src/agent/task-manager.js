'use strict';
/** Task Manager — one row per agent run, plus its activity log (blueprint §32, §55 Phase 4). */
const { uid, now } = require('../utils/misc');

class TaskManager {
  constructor(db) { this.db = db; }

  create({ conversationId, workspaceId = null, title, mode }) {
    const id = uid();
    const t = now();
    this.db.run('INSERT INTO tasks (id, conversation_id, workspace_id, title, status, mode, error, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [id, conversationId, workspaceId, title.slice(0, 200), 'running', mode, null, t, t]);
    return this.get(id);
  }

  get(id) { return this.db.get('SELECT * FROM tasks WHERE id = ?', [id]); }

  listForConversation(conversationId) {
    return this.db.all('SELECT * FROM tasks WHERE conversation_id = ? ORDER BY created_at DESC', [conversationId]);
  }

  update(id, { status, error }) {
    const t = this.get(id);
    if (!t) return null;
    this.db.run('UPDATE tasks SET status = ?, error = ?, updated_at = ? WHERE id = ?',
      [status ?? t.status, error === undefined ? t.error : error, now(), id]);
    return this.get(id);
  }

  addEvent(taskId, type, message, data) {
    this.db.run('INSERT INTO task_events (task_id, type, message, data, created_at) VALUES (?,?,?,?,?)',
      [taskId, type, message || null, data ? JSON.stringify(data) : null, now()]);
  }

  listEvents(taskId) {
    return this.db.all('SELECT * FROM task_events WHERE task_id = ? ORDER BY id ASC', [taskId]);
  }

  listToolCalls(taskId) {
    return this.db.all('SELECT * FROM tool_calls WHERE task_id = ? ORDER BY started_at ASC', [taskId]);
  }

  timeline(taskId) {
    const events = this.listEvents(taskId).map(e => ({ kind: 'event', ...e }));
    const tools = this.listToolCalls(taskId).map(t => ({ kind: 'tool', ...t, created_at: t.started_at }));
    // event ids are integers, tool-call ids are UUID strings: never subtract them (NaN breaks the sort).
    return [...events, ...tools].sort((a,b) => (a.created_at||0) - (b.created_at||0) || String(a.id??'').localeCompare(String(b.id??''), undefined, { numeric: true }));
  }

  logToolCall({ id = uid(), taskId, conversationId, name, args }) {
    this.db.run('INSERT INTO tool_calls (id, task_id, conversation_id, name, args, result, status, started_at, finished_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [id, taskId, conversationId, name, JSON.stringify(args ?? {}), null, 'running', now(), null]);
    return id;
  }

  setToolCallState(id, status, result) {
    this.db.run('UPDATE tool_calls SET status = ?, result = COALESCE(?, result), finished_at = CASE WHEN ? IN (\'success\',\'failed\',\'error\',\'timeout\',\'cancelled\',\'blocked\',\'interrupted\') THEN ? ELSE finished_at END WHERE id = ?',
      [status, result === undefined ? null : JSON.stringify(result), status, now(), id]);
  }

  finishToolCall(id, { status, result }) {
    this.db.run('UPDATE tool_calls SET status = ?, result = ?, finished_at = ? WHERE id = ?',
      [status, JSON.stringify(result ?? null), now(), id]);
  }
}

module.exports = { TaskManager };
