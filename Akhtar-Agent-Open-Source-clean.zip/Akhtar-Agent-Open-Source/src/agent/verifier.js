'use strict';
/**
 * Verification Layer (blueprint §54): "the agent must never assume success
 * just because a tool call did not throw an error." Concretely this is a
 * system-prompt discipline (the model must check build/test/read-back output
 * before reporting success) plus mechanical checks already built into the
 * tools themselves — file.write reads the file back and hashes it
 * (src/tools/filesystem/index.js), and terminal.run reports a real exit code.
 */
const NOTE = `Verification discipline (do not skip):
- A tool call that didn't throw is not proof of success. Read results carefully.
- After editing code: run the project's build/tests (terminal.run) before saying you're done, when a build/test exists.
- After a terminal command: check exit_code and the output, don't assume success from "no error".
- If you cannot verify something, say so plainly instead of reporting completion.
- Mark todo items "failed" (with a reason) rather than "completed" when verification fails.`;

function summarizeToolResult(name, result) {
  if (name === 'terminal.run') return `exit_code=${result.exit_code} timed_out=${!!result.timed_out}`;
  if (name?.startsWith('file.write') || name === 'file.create' || name === 'file.edit') return `verified=${!!result?.verified}`;
  return undefined;
}

module.exports = { VERIFICATION_NOTE: NOTE, summarizeToolResult };
