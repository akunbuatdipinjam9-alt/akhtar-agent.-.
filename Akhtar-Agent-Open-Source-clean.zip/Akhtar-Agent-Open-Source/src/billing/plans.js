'use strict';
const PLANS = Object.freeze({
  free: { id:'free', name:'Free', price:0, currency:'IDR', credits:70, description:'Core agent for personal use · 70 credits' },
  plus: { id:'plus', name:'Plus', price:99000, currency:'IDR', credits:369, description:'More cloud usage and collaboration · 369 credits' },
  pro: { id:'pro', name:'Pro', price:299000, currency:'IDR', credits:573, description:'Highest limits for power users · 573 credits' },
});
function publicPlans(){ return Object.values(PLANS); }
function getPlan(id){ const p=PLANS[id]; if(!p) throw new Error('Unknown plan.'); return p; }
module.exports={PLANS,publicPlans,getPlan};
