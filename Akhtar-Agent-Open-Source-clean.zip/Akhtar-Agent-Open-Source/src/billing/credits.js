'use strict';
const { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } = require('../auth/supabase');

const CREDIT_RULES = Object.freeze({
  cap: 3000,
  firstLogin: 423,
  dailyLogin: 21,
  monthlyBonus: 42,
  codeLine: 0.12,
  effort: { light: 0.2, mid: 0.5, heavy: 1.5, manual: 0.5 },
  tool: { default: 0.15, browser: 0.20, fileRead: 0.10, fileWrite: 0.20, terminal: 0.15, github: 0.20, vision: 1.00, image: 3.00, dualAi: 1.00 },
});

function toolCost(name) {
  if (/^browser\./.test(name)) return CREDIT_RULES.tool.browser;
  if (/^file\.(read|list|search|find)/.test(name)) return CREDIT_RULES.tool.fileRead;
  if (/^file\.(write|create|edit|move|delete|rename)/.test(name)) return CREDIT_RULES.tool.fileWrite;
  if (/^terminal\./.test(name)) return CREDIT_RULES.tool.terminal;
  if (/^(git|github)\./.test(name)) return CREDIT_RULES.tool.github;
  if (/vision|screenshot.*analy/i.test(name)) return CREDIT_RULES.tool.vision;
  if (/^image\./.test(name)) return CREDIT_RULES.tool.image;
  if (name === 'ai.delegate') return CREDIT_RULES.tool.dualAi;
  return CREDIT_RULES.tool.default;
}
function countCodeLines(args={}) {
  const text = [args.content, args.new_str].filter(v=>typeof v==='string').join('\n');
  if (!text) return 0;
  return text.split(/\r?\n/).filter(x=>x.trim()).length;
}
function usageCostForTool(name,args={}) {
  const base=toolCost(name); const lines=/^file\.(write|create|edit)$/.test(name)?countCodeLines(args):0;
  return { amount: Math.round((base + lines*CREDIT_RULES.codeLine)*100)/100, base, codeLines:lines, codeCost:Math.round(lines*CREDIT_RULES.codeLine*100)/100 };
}

class CreditManager {
  constructor({auth}) { this.auth=auth; }
  async _call(body) {
    const token=await this.auth.accessToken();
    if(!token) { const e=new Error('Sign in to use Akhtar Agent credits.'); e.code='NOT_SIGNED_IN'; throw e; }
    // Never let a slow credit service hang an agent run.
    const r=await fetch(`${SUPABASE_URL}/functions/v1/credits`,{method:'POST',signal:AbortSignal.timeout(15000),headers:{apikey:SUPABASE_PUBLISHABLE_KEY,Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify(body)});
    const data=await r.json().catch(()=>({}));
    if(!r.ok) { const e=new Error(data.error==='INSUFFICIENT_CREDITS'?'Not enough Akhtar credits.':(data.error||`Credit service failed (${r.status})`)); e.code=data.error; throw e; }
    return data;
  }
  status(){ return this._call({action:'status'}); }
  claimLoginRewards(){ return this._call({action:'login_rewards'}); }
  spend(amount,eventType,referenceId=null,metadata={}){ if(!(amount>0)) return Promise.resolve(null); return this._call({action:'spend',amount,event_type:eventType,reference_id:referenceId,metadata}); }
  spendEffort(tier,taskId){ const amount=CREDIT_RULES.effort[tier]??CREDIT_RULES.effort.manual; return this.spend(amount,'model_effort',taskId,{tier}); }
  spendTool(name,args,taskId){ const c=usageCostForTool(name,args); return this.spend(c.amount,'tool_usage',taskId,{tool:name,...c}); }
}
/**
 * Charge without letting billing break the agent:
 *  - not signed in / credit service down  -> run continues, charge is skipped and logged
 *  - INSUFFICIENT_CREDITS                 -> { stop: true } so the caller can end the run cleanly
 * A charge failing AFTER a tool succeeded must never turn that success into a failure:
 * the model would retry and repeat the side effect (write twice, comment twice, ...).
 */
async function chargeSafely(fn) {
  try { await fn(); return { charged: true, stop: false }; }
  catch (e) {
    if (e?.code === 'INSUFFICIENT_CREDITS') return { charged: false, stop: true, error: e };
    return { charged: false, stop: false, error: e };
  }
}
module.exports={CreditManager,CREDIT_RULES,usageCostForTool,chargeSafely};
