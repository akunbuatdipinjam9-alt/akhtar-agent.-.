'use strict';
const { publicPlans } = require('./plans');
const { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } = require('../auth/supabase');

class BillingManager {
  constructor({ auth }) { this.auth=auth; }
  getConfig(){ return { provider:'stripe', environment:'live', backend:'supabase-edge-functions' }; }
  overview(){ return { plans:publicPlans(), config:this.getConfig(), paymentMethods:[{id:'stripe',label:'Stripe Checkout'}] }; }
  async createCheckout({ planId }){
    const token=await this.auth.accessToken();
    if(!token) throw new Error('Sign in to Akhtar Account before upgrading.');
    if(!['plus','pro'].includes(planId)) throw new Error('Choose Plus or Pro.');
    const r=await fetch(`${SUPABASE_URL}/functions/v1/billing-checkout`,{method:'POST',headers:{Authorization:`Bearer ${token}`,apikey:SUPABASE_PUBLISHABLE_KEY,'Content-Type':'application/json'},body:JSON.stringify({planId})});
    const data=await r.json().catch(()=>({}));
    if(!r.ok){
      if(data.error==='stripe_not_configured') throw new Error('Stripe backend is ready, but STRIPE_SECRET_KEY has not been added to Supabase yet.');
      throw new Error(data.message || data.error || `Checkout failed (${r.status})`);
    }
    return data;
  }
}
module.exports={BillingManager};
