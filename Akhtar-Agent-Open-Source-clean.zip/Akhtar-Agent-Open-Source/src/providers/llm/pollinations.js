'use strict';
/**
 * Pollinations text generation (https://text.pollinations.ai) — free,
 * no API key required. Speaks a near-identical dialect of the OpenAI
 * Chat Completions API (classic max_tokens/temperature body, same
 * streaming SSE chunk shape), confirmed against Pollinations' own docs:
 *
 *   POST https://text.pollinations.ai/openai
 *   { "model": "openai", "messages": [...], "temperature": 1.0, "max_tokens": 100 }
 *
 * Note the endpoint is the API root + "/openai" directly — NOT
 * ".../chat/completions" like real OpenAI-compatible APIs — hence the
 * chatCompletionsUrl override below. The model list lives one level up,
 * at GET https://text.pollinations.ai/models (baseUrl + "/models",
 * inherited unchanged from OpenAIProvider).
 */
const { OpenAICompatibleProvider } = require('./openai');

class PollinationsTextProvider extends OpenAICompatibleProvider {
  get label() { return this.config.label || 'Pollinations'; }
  get requiresKey() { return false; }
  get supportsUsage() { return false; } // avoid sending stream_options the endpoint's own docs never mention
  get chatCompletionsUrl() { return `${this.baseUrl}/openai`; }
}

module.exports = { PollinationsTextProvider };
