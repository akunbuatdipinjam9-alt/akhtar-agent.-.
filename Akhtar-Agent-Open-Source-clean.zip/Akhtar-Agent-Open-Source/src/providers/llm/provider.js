'use strict';
/**
 * LLM provider abstraction (blueprint §3.2).
 *
 * Internal message format (shared by every provider):
 *   { role: 'user' | 'assistant' | 'tool', content: string,
 *     toolCalls?: [{ id, name, arguments, meta? }],   // assistant
 *     toolCallId?: string, toolName?: string }         // tool
 *
 * stream() yields events:
 *   { type: 'text', delta }
 *   { type: 'tool_call', id, name, arguments, meta? }
 *   { type: 'usage', usage: { input, output } }
 */
const { randomUUID } = require('crypto');
const { redact } = require('../../utils/logger');

// Provider APIs only allow [a-zA-Z0-9_-] in function names; our tools use dots.
const encodeToolName = (name) => name.replace(/\./g, '__');
const decodeToolName = (name) => String(name || '').replace(/__/g, '.');

function parseArgs(raw) {
  if (raw && typeof raw === 'object') return raw;
  if (!raw || !String(raw).trim()) return {};
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' ? v : { __invalid_json: String(raw) };
  } catch { return { __invalid_json: String(raw) }; }
}

class ProviderError extends Error {
  constructor(message, status, retryable) {
    super(message);
    this.name = 'ProviderError';
    this.status = status;
    this.retryable = retryable;
  }
}

async function httpError(res, label) {
  let body = '';
  try { body = await res.text(); } catch { /* ignore */ }
  let msg = body;
  try { const j = JSON.parse(body); msg = j.error?.message || j.message || j.error || body; } catch { /* not json */ }
  const retryable = res.status === 429 || res.status === 408 || res.status === 529 || res.status >= 500;
  const err = new ProviderError(`${label} HTTP ${res.status}: ${redact(String(msg)).slice(0, 500)}`, res.status, retryable);
  const ra = Number(res.headers?.get?.('retry-after'));
  if (Number.isFinite(ra) && ra >= 0) err.retryAfterMs = ra * 1000;
  return err;
}

const SSE_IDLE_MS = 150000; // providers send data or keep-alive pings far more often than this

/**
 * Parse a Server-Sent Events response body.
 * A stalled connection (no bytes at all for SSE_IDLE_MS) used to hang the run until the
 * whole-run timeout (up to hours); now it fails fast with a retryable error.
 */
async function* sseEvents(res, { idleMs = SSE_IDLE_MS } = {}) {
  const decoder = new TextDecoder();
  let buf = '';
  let event = null;
  let data = [];
  const flush = function* () {
    if (data.length) yield { event, data: data.join('\n') };
    event = null;
    data = [];
  };
  const lines = function* () {
    let nl;
    while ((nl = buf.indexOf('\n')) !== -1) {
      const line = buf.slice(0, nl).replace(/\r$/, '');
      buf = buf.slice(nl + 1);
      if (line === '') { yield* flush(); continue; }
      if (line.startsWith(':')) continue;
      if (line.startsWith('data:')) data.push(line.slice(5).replace(/^ /, ''));
      else if (line.startsWith('event:')) event = line.slice(6).trim();
    }
  };
  // Real fetch bodies are ReadableStreams; tests and some polyfills give a plain async iterable.
  const reader = typeof res.body?.getReader === 'function' ? res.body.getReader() : (() => {
    const it = res.body[Symbol.asyncIterator]();
    return { read: () => it.next(), cancel: async () => { it.return?.(); }, releaseLock() {} };
  })();
  let done = false;
  try {
    for (;;) {
      let timer;
      const idle = new Promise((_, reject) => { timer = setTimeout(() => reject(new ProviderError(`Stream stalled: no data for ${Math.round(idleMs / 1000)}s`, 0, true)), idleMs); });
      let step;
      try { step = await Promise.race([reader.read(), idle]); } finally { clearTimeout(timer); }
      if (step.done) { done = true; break; }
      buf += decoder.decode(step.value, { stream: true });
      yield* lines();
    }
    buf += decoder.decode(); // flush a trailing multi-byte character
    buf += '\n';
    yield* lines();
    yield* flush();
  } finally {
    // cancel() (not iterator.return()) — return() would wait for the stalled read forever.
    // It also closes the underlying HTTP connection when the consumer stops early.
    if (!done) reader.cancel().catch(() => {});
    try { reader.releaseLock(); } catch { /* pending read */ }
  }
}

/** Error for a stream that closed before the provider said it was finished. */
function truncatedStream(label) {
  return new ProviderError(`${label}: the response stream ended unexpectedly (connection dropped).`, 0, true);
}

/** Should a failed model call be retried? Only transient, provider-side failures. */
function isRetryableModelError(e) {
  if (!e || e.name === 'AbortError') return false;
  if (e.retryable === true) return true;
  if (e.retryable === false) return false;
  return /overloaded|rate.?limit|too many requests|econnreset|etimedout|socket hang up|fetch failed|network|temporarily unavailable|stream (ended|stalled)/i.test(String(e.message || ''));
}

class LLMProvider {
  constructor(config, apiKey) {
    this.config = config;
    this.apiKey = apiKey || '';
    this.baseUrl = (config.baseUrl || '').replace(/\/+$/, '');
  }

  get label() { return this.config.label || this.config.id; }
  get requiresKey() { return true; }

  // eslint-disable-next-line require-yield
  async *stream(_opts) { throw new Error('stream() not implemented'); }

  /** Non-streaming convenience built on stream(). */
  async generate(opts) {
    let text = '';
    const toolCalls = [];
    let usage = null;
    for await (const ev of this.stream(opts)) {
      if (ev.type === 'text') text += ev.delta;
      else if (ev.type === 'tool_call') toolCalls.push(ev);
      else if (ev.type === 'usage') usage = ev.usage;
    }
    return { text, toolCalls, usage };
  }

  /** Same as generate() — kept to satisfy the provider interface in the blueprint. */
  async toolCall(opts) { return this.generate(opts); }

  async getModels() { return []; }

  ensureKey() {
    if (this.requiresKey && !this.apiKey) throw new ProviderError(`No API key set for ${this.label}. Add it in Settings → Models.`, 0, false);
  }
}

const newId = () => 'call_' + randomUUID().replace(/-/g, '').slice(0, 20);

module.exports = { LLMProvider, ProviderError, httpError, sseEvents, encodeToolName, decodeToolName, parseArgs, newId, truncatedStream, isRetryableModelError };
