'use strict';
const { OpenAIProvider } = require('./openai');
const { ProviderError } = require('./provider');

/**
 * OpenAI through Akhtar Agent's Supabase Edge Function.
 * The OpenAI API key never lives in the Electron client. `apiKey` here is
 * the signed-in user's Supabase access token used to authenticate the proxy.
 */
class SupabaseOpenAIProvider extends OpenAIProvider {
  get requiresKey() { return false; }
  get chatCompletionsUrl() { return this.baseUrl; }

  ensureKey() {
    if (!this.apiKey) {
      throw new ProviderError('Sign in to Akhtar Agent first so Akhtar Cloud models can use the secure cloud proxy.', 401, false);
    }
  }

  headers() {
    this.ensureKey();
    const publishableKey = this.config.publishableKey || '';
    const h = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.apiKey}`,
    };
    if (publishableKey) h.apikey = publishableKey;
    return h;
  }

  async getModels() {
    return Array.isArray(this.config.models) && this.config.models.length
      ? [...this.config.models]
      : ['gpt-oss-120b', 'gpt-5-mini', 'gpt-5.6-luna'];
  }
}

module.exports = { SupabaseOpenAIProvider };
