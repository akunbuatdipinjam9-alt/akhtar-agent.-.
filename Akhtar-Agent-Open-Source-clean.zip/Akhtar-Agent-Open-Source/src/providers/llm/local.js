'use strict';
const { OpenAICompatibleProvider } = require('./openai');

/** Local servers (Ollama, LM Studio, llama.cpp) via their OpenAI-compatible endpoint. No key required. */
class LocalProvider extends OpenAICompatibleProvider {
  get requiresKey() { return false; }
  get supportsUsage() { return false; }
}

module.exports = { LocalProvider };
