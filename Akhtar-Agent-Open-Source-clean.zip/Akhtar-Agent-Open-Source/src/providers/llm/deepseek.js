'use strict';
const { OpenAICompatibleProvider } = require('./openai');

/** DeepSeek uses the OpenAI-compatible Chat Completions API. */
class DeepSeekProvider extends OpenAICompatibleProvider {}

module.exports = { DeepSeekProvider };
