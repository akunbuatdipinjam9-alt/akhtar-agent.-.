'use strict';
/** Image Provider abstraction — mirrors the LLM provider interface, kept swappable (blueprint Phase 13). */
class ImageProvider {
  constructor(apiKey) { this.apiKey = apiKey || ''; }
  get label() { return 'Image Provider'; }
  ensureKey() { if (!this.apiKey) throw new Error(`No API key set for ${this.label}.`); }
  // eslint-disable-next-line no-unused-vars
  async generate({ prompt, size, signal }) { throw new Error('generate() not implemented'); }
}
module.exports = { ImageProvider };
