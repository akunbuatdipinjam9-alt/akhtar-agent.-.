'use strict';
const assert=require('assert');
const {EVENTS}=require('../src/main/islamic-event-reminder');
const {buildRegistry}=require('../src/tools');
assert(EVENTS['1-10'] && /عيد فطر مبارك/.test(EVENTS['1-10'].body));
assert(EVENTS['10-12'] && /عيد أضحى مبارك/.test(EVENTS['10-12'].body));
const r=buildRegistry();
for(const n of ['islamic_reminder.enable','islamic_reminder.disable','islamic_reminder.status','islamic_reminder.check']) assert(r.get(n),`missing ${n}`);
console.log('islamic-event-reminder: PASS');
