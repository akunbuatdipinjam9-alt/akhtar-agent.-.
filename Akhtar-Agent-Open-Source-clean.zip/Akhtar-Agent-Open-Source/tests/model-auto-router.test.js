'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { classifyComplexity, routeForRequest } = require('../src/agent/model-router');

test('light chat routes to GPT-OSS-120B', () => {
  assert.equal(classifyComplexity({ text: 'hai bro lagi apa', mode: 'chat' }), 'light');
});
test('mid task routes to GPT-5 mini tier', () => {
  assert.equal(classifyComplexity({ text: 'tolong ringkas teks ini dan jelaskan poin pentingnya', mode: 'assist' }), 'mid');
});
test('agent/tool task routes to GPT-5.6 Luna tier', () => {
  assert.equal(classifyComplexity({ text: 'implementasikan migration Supabase dan debug agent tools project ini', mode: 'agent' }), 'heavy');
});
test('route models are the configured three-tier stack', () => {
  const settings = { routing: { auto: true } };
  assert.equal(routeForRequest(settings,{text:'halo',mode:'chat'}).model,'gpt-oss-120b');
  assert.equal(routeForRequest(settings,{text:'jelaskan dan ringkas ini',mode:'assist'}).model,'gpt-5-mini');
  assert.equal(routeForRequest(settings,{text:'debug codebase dan deploy database',mode:'agent'}).model,'gpt-5.6-luna');
});
