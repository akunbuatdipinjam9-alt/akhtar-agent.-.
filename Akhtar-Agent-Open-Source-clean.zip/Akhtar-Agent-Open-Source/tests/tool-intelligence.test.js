'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildRegistry } = require('../src/tools');
const { shortlistTools, ToolFailureMemory, inferGroups } = require('../src/agent/tool-intelligence');
const { ToolRegistry } = require('../src/tools/registry');

test('tool intelligence shortlists coding capabilities but keeps foundation tools', () => {
  const all = buildRegistry().forMode('agent', { hasWorkspace: true });
  const chosen = shortlistTools(all, { text: 'Implement and test a fix in this code project', mode: 'agent' });
  const names = new Set(chosen.map(x => x.name));
  assert.ok([...names].some(n => n.startsWith('file.')));
  assert.ok(names.has('terminal.run'));
  assert.ok([...names].some(n => n.startsWith('todo.')));
  assert.ok(names.has('skill.load'));
  assert.ok(chosen.length < all.length, `expected shortlist < ${all.length}, got ${chosen.length}`);
});

test('tool intelligence carries previously-used tool groups into later iterations', () => {
  const all = buildRegistry().forMode('agent', { hasWorkspace: true });
  const chosen = shortlistTools(all, { text: 'fix code', mode: 'agent', previousToolNames: ['browser.observe'] });
  assert.ok(chosen.some(x => x.name === 'browser.observe'));
});

test('failure memory requires replanning after repeated identical failures', () => {
  const m = new ToolFailureMemory({ maxSameStrategy: 2 });
  assert.equal(m.shouldReplan('browser.click', { element: 4 }), false);
  m.record('browser.click', { element: 4 }, 'detached');
  assert.equal(m.shouldReplan('browser.click', { element: 4 }), false);
  m.record('browser.click', { element: 4 }, 'detached');
  assert.equal(m.shouldReplan('browser.click', { element: 4 }), true);
  assert.match(m.promptNote(), /Do not blindly repeat/);
});

test('schemas include intelligence hints without changing function schema shape', () => {
  const all = buildRegistry().forMode('agent', { hasWorkspace: true });
  const tools = shortlistTools(all, { text: 'edit file', mode: 'agent' });
  const schemas = ToolRegistry.toSchemas(tools);
  const write = schemas.find(x => x.name === 'file.write') || schemas.find(x => x.name === 'file.edit');
  assert.ok(write);
  assert.match(write.description, /Tool guidance:/);
  assert.ok(write.inputSchema);
});

test('chat ambiguity fails open instead of hiding info tools', () => {
  assert.equal(inferGroups('hello there', 'chat'), null);
});
