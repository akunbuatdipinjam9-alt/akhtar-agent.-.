'use strict';
/**
 * Runs the REAL Agent.run loop with a scripted fake model and in-memory services, so
 * agent-level behavior (tool failures, timeouts, stop, billing) can be tested end-to-end.
 * Needs sql.js (npm install) for the real Database/Repos/TaskManager.
 */
const Module = require('node:module');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

let hasSql = true;
try { require.resolve('sql.js'); } catch { hasSql = false; }

function installFakeModel(script) {
  const realLoad = Module._load;
  const routerPath = require.resolve('../../src/agent/model-router');
  const real = require(routerPath);
  let iteration = 0;
  const fake = {
    ...real,
    routeForRequest: () => null,
    getProvider: () => ({
      model: 'fake', providerConfig: { id: 'fake' },
      provider: {
        async *stream({ messages, signal }) {
          const step = script[Math.min(iteration++, script.length - 1)];
          const events = typeof step === 'function' ? step(messages) : step;
          for await (const ev of events) { if (signal?.aborted) throw signal.reason; yield ev; }
        },
      },
    }),
  };
  require.cache[routerPath].exports = fake;
  delete require.cache[require.resolve('../../src/agent/agent')];
  return { restore() { require.cache[routerPath].exports = real; delete require.cache[require.resolve('../../src/agent/agent')]; }, get calls() { return iteration; } };
}

async function makeApp({ tools = [], credits = null, settingsPatch = {} } = {}) {
  const { Database } = require('../../src/database/database');
  const { Repos } = require('../../src/database/repos');
  const { TaskManager } = require('../../src/agent/task-manager');
  const { ToolRegistry } = require('../../src/tools/registry');
  const { DEFAULTS } = require('../../src/main/settings');
  const db = new Database();
  await db.init(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'harness-')), 'a.sqlite'));
  const registry = new ToolRegistry();
  registry.registerAll(tools);
  const settings = JSON.parse(JSON.stringify(DEFAULTS));
  settings.agent = { ...settings.agent, maxIterations: 6, runTimeoutMin: 1, ...(settingsPatch.agent || {}) };
  const app = {
    db, repos: new Repos(db), tasks: new TaskManager(db), registry,
    settings: { get: () => settings },
    secrets: { get: () => 'x', has: () => true },
    skills: { list: () => [], get: () => null, load: () => null },
    memory: { list: () => [] },
    permissions: { check: async () => ({ allowed: true }), checkUnattended: () => ({ allowed: true }) },
    checkpoints: { record() {} }, artifacts: {}, todo: {},
    auth: { accessToken: async () => null },
    credits,
  };
  const conv = app.repos.createConversation({ title: 't', mode: 'agent' });
  return { app, conversationId: conv.id };
}

module.exports = { hasSql, installFakeModel, makeApp };
