'use strict';
/** DB-backed regression tests (need sql.js: run `npm install` first). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

let hasSql = true;
try { require.resolve('sql.js'); } catch { hasSql = false; }
const opts = { skip: !hasSql && 'sql.js not installed (run npm install)' };

async function freshDb(file) {
  const { Database } = require('../src/database/database');
  const db = new Database();
  await db.init(file || path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-db-')), 'a.sqlite'));
  return db;
}

test('database: a corrupt file does not crash startup; a backup is kept', opts, async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-db-'));
  const file = path.join(dir, 'a.sqlite');
  fs.writeFileSync(file, Buffer.from('this is definitely not a sqlite database '.repeat(200)));
  const db = await freshDb(file);
  assert.ok(db.get("SELECT value FROM meta WHERE key = 'schema_version'"));
  assert.ok(fs.readdirSync(dir).some((f) => f.includes('.corrupt-')));
});

function schedulerWith(db, runImpl, extra = {}) {
  const { Repos } = require('../src/database/repos');
  const { SchedulerManager } = require('../src/scheduler/manager');
  const app = { db, repos: new Repos(db), agent: { run: runImpl }, getWindow: () => null, activeRuns: new Map(), ...extra };
  return { app, sch: new SchedulerManager(app) };
}

test('scheduler: slot is claimed before running (a crash mid-run does not replay it)', opts, async () => {
  const db = await freshDb();
  let seenStatusDuringRun = null;
  const { sch } = schedulerWith(db, async () => { seenStatusDuringRun = sch.get(s.id); return { task: { status: 'completed' } }; });
  const s = sch.create({ title: 't', instruction: 'x', recurrence: 'daily', time: '00:00', timezone: 'UTC' });
  db.run('UPDATE schedules SET next_run_at = ? WHERE id = ?', [Date.now() - 1000, s.id]);
  await sch._runOne(sch.get(s.id));
  assert.equal(seenStatusDuringRun.last_status, 'running');
  assert.ok(seenStatusDuringRun.next_run_at > Date.now(), 'next_run_at advanced before the run started');
  assert.equal(sch.get(s.id).last_status, 'success');
});

test('scheduler: runs left "running" by a crash are marked interrupted on start', opts, async () => {
  const db = await freshDb();
  const { sch } = schedulerWith(db, async () => ({}));
  const s = sch.create({ title: 't', instruction: 'x', recurrence: 'once', run_at: new Date(Date.now() + 3600e3).toISOString() });
  db.run("UPDATE schedules SET last_status = 'running' WHERE id = ?", [s.id]);
  sch.start(1e9); sch.stop();
  assert.equal(sch.get(s.id).last_status, 'interrupted');
});

test('scheduler: skips a schedule whose conversation already has an active run; stop() aborts runs', opts, async () => {
  const db = await freshDb();
  let started = 0; let aborted = false;
  const { app, sch } = schedulerWith(db, ({ signal }) => { started++; return new Promise((res) => signal.addEventListener('abort', () => { aborted = true; res({ task: { status: 'stopped' } }); })); });
  const s = sch.create({ title: 't', instruction: 'x', recurrence: 'once', run_at: new Date(Date.now() - 1000).toISOString() });
  const conv = app.repos.createConversation({ title: 'c', mode: 'agent' });
  db.run('UPDATE schedules SET conversation_id = ? WHERE id = ?', [conv.id, s.id]);
  app.activeRuns.set(conv.id, { ctrl: new AbortController() });
  await sch.tick();
  assert.equal(started, 0, 'must not run concurrently with the user');
  app.activeRuns.clear();
  await sch.tick();
  await new Promise((r) => setImmediate(r));
  assert.equal(started, 1);
  assert.ok(app.activeRuns.has(conv.id), 'scheduled run is visible to the UI lock (and Stop)');
  sch.stop();
  await new Promise((r) => setTimeout(r, 20));
  assert.ok(aborted);
  assert.equal(sch.get(s.id).last_status, 'stopped');
  assert.ok(!app.activeRuns.has(conv.id));
});

test('checkpoints: one checkpoint per task across iterations; copy_dir undo; no double restore; unrestorable is never deleted', opts, async () => {
  const db = await freshDb();
  const { CheckpointManager } = require('../src/checkpoints/manager');
  const cm = new CheckpointManager(db);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cp-'));
  const big = path.join(dir, 'big.bin'); fs.writeFileSync(big, 'huge');
  const copied = path.join(dir, 'copy'); fs.mkdirSync(copied); fs.writeFileSync(path.join(copied, 'x'), '1');
  const created = path.join(dir, 'new.txt'); fs.writeFileSync(created, 'n');
  const ctx1 = { workspaceId: 'w', taskId: 't1' }; const ctx2 = { workspaceId: 'w', taskId: 't1' }; // two iterations
  const a = cm.record(ctx1, { action: 'copy_dir', path: copied, before: null, extra: { dest: copied } });
  const b = cm.record(ctx2, { action: 'write', path: big, before: null, extra: { unrestorable: true } });
  cm.record(ctx2, { action: 'write', path: created, before: null });
  assert.equal(a, b, 'same task => same checkpoint');
  const res = await cm.restore(a);
  assert.ok(!fs.existsSync(copied), 'copied folder removed');
  assert.ok(fs.existsSync(big), 'unrestorable file must NOT be deleted');
  assert.ok(!fs.existsSync(created));
  assert.ok(res.some((r) => !r.ok && r.path === big));
  fs.writeFileSync(created, 'user recreated it');
  await assert.rejects(cm.restore(a), /already restored/);
  assert.ok(fs.existsSync(created));
});
