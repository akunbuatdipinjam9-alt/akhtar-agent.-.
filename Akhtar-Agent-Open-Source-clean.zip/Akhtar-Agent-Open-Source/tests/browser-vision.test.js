'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { DEFAULTS } = require('../src/main/settings');
const browserTools = require('../src/tools/browser');

test('Browser Vision defaults to smart fallback with three rescues', () => {
  assert.equal(DEFAULTS.browserVision.mode, 'smart');
  assert.equal(DEFAULTS.browserVision.maxCallsPerTask, 3);
});

test('browser exposes vision rescue and coordinate click', () => {
  const names = new Set(browserTools.map(t => t.name));
  assert.ok(names.has('browser.vision_rescue'));
  assert.ok(names.has('browser.click_at'));
});

test('vision rescue is network gated and click_at is sensitive', () => {
  const rescue = browserTools.find(t => t.name === 'browser.vision_rescue');
  const click = browserTools.find(t => t.name === 'browser.click_at');
  assert.ok(rescue.permission);
  assert.ok(click.permission);
  assert.notEqual(rescue.permission, 'NONE');
  assert.notEqual(click.permission, 'NONE');
});


test('DOM perception remains unlimited and separate from vision quota', () => {
  const source = require('fs').readFileSync(require('path').join(__dirname, '../src/agent/planner.js'), 'utf8');
  assert.match(source, /FREE AND UNLIMITED/);
  assert.match(source, /no DOM observation quota/i);
  assert.match(source, /Only a screenshot actually sent to a vision model consumes one rescue/i);
});
