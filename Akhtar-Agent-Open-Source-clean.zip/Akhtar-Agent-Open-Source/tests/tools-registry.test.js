'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const { ToolRegistry } = require('../src/tools/registry');
const { validate, assertValid } = require('../src/utils/schema');
const { slugify } = require('../src/utils/slug');
const { buildRegistry } = require('../src/tools');

test('schema: validate catches missing required, wrong type, out-of-range', () => {
  const schema = { type: 'object', properties: { n: { type: 'number', minimum: 0, maximum: 10 }, s: { type: 'string', maxLength: 3 } }, required: ['n'] };
  assert.equal(validate(schema, { n: 5, s: 'ab' }).length, 0);
  assert.ok(validate(schema, {}).length > 0, 'missing required n');
  assert.ok(validate(schema, { n: 'x' }).length > 0, 'wrong type');
  assert.ok(validate(schema, { n: 99 }).length > 0, 'out of range');
  assert.throws(() => assertValid(schema, {}), /Invalid input/);
});

test('slug: slugify produces safe, lowercase, hyphenated filenames', () => {
  assert.equal(slugify('Laporan Q3 2026!'), 'laporan-q3-2026');
  assert.equal(slugify('  spaces   and---dashes  '), 'spaces-and-dashes');
  assert.equal(slugify(''), 'untitled');
  assert.equal(slugify(null, 'fallback'), 'fallback');
});

test('registry: register + duplicate detection + forMode filtering', () => {
  const reg = new ToolRegistry();
  reg.register({ name: 'demo.read', group: 'demo', description: 'x', inputSchema: { type: 'object', properties: {} }, permission: 'NONE', execute: async () => ({}) });
  reg.register({ name: 'demo.write', group: 'demo', description: 'x', inputSchema: { type: 'object', properties: {} }, permission: 'WRITE', requiresWorkspace: true, execute: async () => ({}) });
  assert.equal(reg.all().length, 2);
  assert.throws(() => reg.register({ name: 'demo.read', group: 'demo', description: 'x', inputSchema: { type: 'object', properties: {} }, permission: 'NONE', execute: async () => ({}) }), /Duplicate tool/);
  assert.throws(() => reg.register({ name: 'BadName', group: 'demo', description: 'x', inputSchema: { type: 'object', properties: {} }, permission: 'NONE', execute: async () => ({}) }), /Invalid tool name/);

  const withWorkspace = reg.forMode('agent', { hasWorkspace: true });
  assert.equal(withWorkspace.length, 2);
  const withoutWorkspace = reg.forMode('agent', { hasWorkspace: false });
  assert.equal(withoutWorkspace.length, 1, 'requiresWorkspace tool should be filtered out');
});

test('registry: the real tool set builds cleanly with unique dotted names', () => {
  const reg = buildRegistry();
  const all = reg.all();
  assert.ok(all.length > 50, `expected 50+ tools, got ${all.length}`);
  const names = new Set();
  for (const t of all) {
    assert.ok(!names.has(t.name), `duplicate tool name ${t.name}`);
    names.add(t.name);
    assert.match(t.name, /^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$/, `tool name "${t.name}" should be dotted`);
    assert.equal(typeof t.execute, 'function');
    assert.ok(t.description && t.description.length > 0);
  }
});

test('registry: chat mode only exposes read-only / info tool groups', () => {
  const reg = buildRegistry();
  const chatTools = reg.forMode('chat', { hasWorkspace: true });
  const forbiddenGroups = ['filesystem', 'terminal', 'documents', 'presentations'];
  for (const t of chatTools) {
    assert.ok(!forbiddenGroups.includes(t.group), `"${t.group}" tool "${t.name}" should not be offered in chat mode`);
  }
});
