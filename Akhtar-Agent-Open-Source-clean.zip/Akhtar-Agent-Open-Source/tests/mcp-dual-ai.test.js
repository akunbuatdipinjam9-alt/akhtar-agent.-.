'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildRegistry } = require('../src/tools');
const { McpManager } = require('../src/mcp/client');
const { DEFAULTS } = require('../src/main/settings');

test('registry exposes MCP and dual-AI tools', () => {
  const r = buildRegistry();
  assert.ok(r.get('mcp.servers'));
  assert.ok(r.get('mcp.tools'));
  assert.ok(r.get('mcp.call'));
  assert.ok(r.get('ai.delegate'));
});

test('MCP manager lists configured servers without starting them', () => {
  const m = new McpManager(() => ({ mcp: { servers: [{ id: 'demo', command: 'demo-cmd', enabled: true }] } }));
  assert.equal(m.listServers()[0].id, 'demo');
});

test('five additional cloud providers are present', () => {
  for (const id of ['xai','groq','mistral','together','cerebras']) {
    assert.ok(DEFAULTS.providers.find((p) => p.id === id), `missing ${id}`);
  }
});
