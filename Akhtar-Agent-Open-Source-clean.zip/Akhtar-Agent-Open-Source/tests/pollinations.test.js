'use strict';
/** Uses a mocked global.fetch — no real network call, works offline/in CI. */
const test = require('node:test');
const assert = require('node:assert/strict');

const { PollinationsImageProvider } = require('../src/providers/image/pollinations');

function fakeImageResponse(bytes = 600, contentType = 'image/png') {
  return { ok: true, headers: { get: (k) => (k.toLowerCase() === 'content-type' ? contentType : null) }, arrayBuffer: async () => Buffer.alloc(bytes).buffer };
}

test('pollinations: builds the expected URL with width/height/model/seed and returns a Buffer', async (t) => {
  let capturedUrl = null;
  t.mock.method(global, 'fetch', async (url) => { capturedUrl = url; return fakeImageResponse(); });

  const provider = new PollinationsImageProvider();
  const buf = await provider.generate({ prompt: 'a fox in a suit', size: '768x512', model: 'flux-realism', seed: 42 });

  assert.ok(Buffer.isBuffer(buf));
  assert.equal(buf.length, 600);
  const url = new URL(capturedUrl);
  assert.equal(url.hostname, 'image.pollinations.ai');
  assert.equal(decodeURIComponent(url.pathname), '/prompt/a fox in a suit');
  assert.equal(url.searchParams.get('width'), '768');
  assert.equal(url.searchParams.get('height'), '512');
  assert.equal(url.searchParams.get('model'), 'flux-realism');
  assert.equal(url.searchParams.get('seed'), '42');
});

test('pollinations: requires no API key', () => {
  const provider = new PollinationsImageProvider();
  assert.equal(provider.requiresKey, false);
  assert.doesNotThrow(() => provider.ensureKey());
});

test('pollinations: invalid size string falls back to 1024x1024 instead of throwing', async (t) => {
  let capturedUrl = null;
  t.mock.method(global, 'fetch', async (url) => { capturedUrl = url; return fakeImageResponse(); });
  const provider = new PollinationsImageProvider();
  await provider.generate({ prompt: 'x', size: 'not-a-size' });
  const url = new URL(capturedUrl);
  assert.equal(url.searchParams.get('width'), '1024');
  assert.equal(url.searchParams.get('height'), '1024');
});

test('pollinations: rejects an empty prompt without making a network call', async (t) => {
  const fetchMock = t.mock.fn(async () => fakeImageResponse());
  t.mock.method(global, 'fetch', fetchMock);
  const provider = new PollinationsImageProvider();
  await assert.rejects(() => provider.generate({ prompt: '   ' }), /prompt is empty/);
  assert.equal(fetchMock.mock.callCount(), 0);
});

test('pollinations: surfaces a clear error on a non-OK HTTP response', async (t) => {
  t.mock.method(global, 'fetch', async () => ({ ok: false, status: 503, text: async () => 'Service Unavailable' }));
  const provider = new PollinationsImageProvider();
  await assert.rejects(() => provider.generate({ prompt: 'x' }), /HTTP 503/);
});

test('pollinations: treats a non-image / too-small response as an error, not a corrupt image', async (t) => {
  t.mock.method(global, 'fetch', async () => fakeImageResponse(10, 'text/html'));
  const provider = new PollinationsImageProvider();
  await assert.rejects(() => provider.generate({ prompt: 'x' }), /did not look like an image/);
});
