'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { conflicts, buildWaves, runParallelToolCalls } = require('../src/agent/parallel-engine');

const c = (name, args={}) => ({ name, arguments: args });

test('independent reads share a wave up to concurrency limit', () => {
  const waves = buildWaves([c('file.read',{path:'a.js'}), c('browser.search',{query:'docs'}), c('weather.current',{city:'x'}), c('time.current')], {maxConcurrency:3});
  assert.equal(waves[0].length, 3);
  assert.equal(waves.flat().length, 4);
});

test('same-path mutation conflicts with read/write', () => {
  assert.equal(conflicts(c('file.edit',{path:'a.js'}), c('file.read',{path:'a.js'})), true);
  assert.equal(conflicts(c('file.read',{path:'a.js'}), c('file.read',{path:'a.js'})), false);
});

test('browser actions on same tab serialize', () => {
  const waves = buildWaves([c('browser.click',{tabId:'1'}), c('browser.observe',{tabId:'1'})], {maxConcurrency:3});
  assert.equal(waves.length, 2);
});

test('different browser tabs can execute together', () => {
  const waves = buildWaves([c('browser.observe',{tabId:'1'}), c('browser.observe',{tabId:'2'})], {maxConcurrency:3});
  assert.equal(waves.length, 1);
});

test('parallel runner preserves original result order and isolates failures', async () => {
  const calls = [c('file.read',{path:'a'}), c('weather.current'), c('time.current')];
  const {results} = await runParallelToolCalls(calls, {maxConcurrency:3, execute: async (call, i) => {
    await new Promise(r=>setTimeout(r, (2-i)*5));
    if (i===1) throw new Error('boom');
    return call.name;
  }});
  assert.equal(results[0].value, 'file.read');
  assert.equal(results[1].ok, false);
  assert.equal(results[2].value, 'time.current');
});
