'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
const {compressMessages}=require('../src/agent/context-compressor');
test('keeps short context unchanged',()=>{const m=[{role:'user',content:'hi'}];const r=compressMessages(m,{budgetChars:100});assert.equal(r.compressed,false);assert.deepEqual(r.messages,m);});
test('compresses old turns and preserves recent messages',()=>{const m=Array.from({length:20},(_,i)=>({role:i%2?'assistant':'user',content:'x'.repeat(1000)+i}));const r=compressMessages(m,{budgetChars:5000,recentCount:4,summaryChars:1000});assert.equal(r.compressed,true);assert.equal(r.messages.at(-1).content,m.at(-1).content);assert.match(r.messages[0].content,/Compressed earlier conversation/);});
