'use strict';
/**
 * These spawn the real `git` binary against a throwaway temp repo — no
 * mocking. Skipped automatically if `git` isn't on PATH (e.g. a minimal
 * CI image), so this suite degrades gracefully rather than failing hard.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const gitTools = require('../src/tools/git');
const byName = Object.fromEntries(gitTools.map((t) => [t.name, t]));

let gitAvailable = true;
try { execFileSync('git', ['--version'], { stdio: 'ignore' }); } catch { gitAvailable = false; }

function freshRepo() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-git-'));
  execFileSync('git', ['init', '-q'], { cwd: dir });
  execFileSync('git', ['config', 'user.email', 'test@test.com'], { cwd: dir });
  execFileSync('git', ['config', 'user.name', 'Tester'], { cwd: dir });
  return dir;
}

function ctxFor(root) {
  return { workspace: { root_path: root }, settings: { agent: { toolTimeoutSec: 30 } }, signal: undefined };
}

test('git tools: status/add/diff/commit/log/branch round-trip on a real repo', { skip: !gitAvailable && 'git not on PATH' }, async () => {
  const root = freshRepo();
  fs.writeFileSync(path.join(root, 'readme.txt'), 'hello world\n');
  fs.mkdirSync(path.join(root, 'sub'));
  fs.writeFileSync(path.join(root, 'sub', 'file.txt'), 'nested\n');
  const ctx = ctxFor(root);

  const s1 = await byName['git.status'].execute({}, ctx);
  assert.deepEqual(s1.untracked.sort(), ['readme.txt', 'sub/']);
  assert.equal(s1.clean, false);

  await byName['git.add'].execute({ paths: ['readme.txt', 'sub/file.txt'] }, ctx);
  const s2 = await byName['git.status'].execute({}, ctx);
  assert.equal(s2.staged.length, 2);
  assert.equal(s2.untracked.length, 0);

  const d = await byName['git.diff'].execute({ staged: true }, ctx);
  assert.ok(d.diff.includes('+hello world'));
  assert.ok(d.diff.includes('+nested'));

  const c = await byName['git.commit'].execute({ message: 'Initial commit' }, ctx);
  assert.equal(c.committed, true);
  assert.match(c.hash, /^[0-9a-f]{40}$/);

  const log = await byName['git.log'].execute({ limit: 5 }, ctx);
  assert.equal(log.commits.length, 1);
  assert.equal(log.commits[0].message, 'Initial commit');
  assert.equal(log.commits[0].hash, c.hash);

  const s3 = await byName['git.status'].execute({}, ctx);
  assert.equal(s3.clean, true);

  const commitAgain = await byName['git.commit'].execute({ message: 'nothing changed' }, ctx);
  assert.equal(commitAgain.committed, false, 'nothing staged -> committed:false, not an error');
});

test('git tools: branch list/create/switch', { skip: !gitAvailable && 'git not on PATH' }, async () => {
  const root = freshRepo();
  fs.writeFileSync(path.join(root, 'a.txt'), 'a');
  const ctx = ctxFor(root);
  await byName['git.add'].execute({ paths: ['a.txt'] }, ctx);
  await byName['git.commit'].execute({ message: 'init' }, ctx);

  const before = await byName['git.branch'].execute({ action: 'list' }, ctx);
  assert.equal(before.branches.length, 1);
  assert.equal(before.branches[0].current, true);

  const created = await byName['git.branch'].execute({ action: 'create', name: 'feature/x' }, ctx);
  assert.equal(created.created, 'feature/x');

  const after = await byName['git.branch'].execute({ action: 'list' }, ctx);
  const current = after.branches.find((b) => b.current);
  assert.equal(current.name, 'feature/x');
});

test('git tools: path arguments cannot escape the workspace', { skip: !gitAvailable && 'git not on PATH' }, async () => {
  const root = freshRepo();
  const ctx = ctxFor(root);
  await assert.rejects(() => byName['git.add'].execute({ paths: ['../outside.txt'] }, ctx), /outside the workspace/);
  await assert.rejects(() => byName['git.diff'].execute({ path: '../../etc/passwd' }, ctx), /outside the workspace/);
});

test('git tools: a clear error when the workspace is not a git repo', { skip: !gitAvailable && 'git not on PATH' }, async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-notgit-'));
  const ctx = ctxFor(dir);
  await assert.rejects(() => byName['git.status'].execute({}, ctx), /not a git repository/);
});
