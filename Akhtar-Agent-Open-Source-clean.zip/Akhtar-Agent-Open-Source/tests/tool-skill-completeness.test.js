'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

test('tools skill documents every registered tool command', () => {
  const root = path.join(__dirname, '..');
  const skill = fs.readFileSync(path.join(root, 'skills', 'tools', 'SKILL.md'), 'utf8');
  const toolsRoot = path.join(root, 'src', 'tools');
  const groups = fs.readdirSync(toolsRoot, { withFileTypes: true }).filter(d => d.isDirectory());
  const names = [];
  for (const group of groups) {
    const file = path.join(toolsRoot, group.name, 'index.js');
    if (!fs.existsSync(file)) continue;
    const source = fs.readFileSync(file, 'utf8');
    for (const match of source.matchAll(/name\s*:\s*['\"]([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+)['\"]/g)) names.push(match[1]);
  }
  assert.ok(names.length > 0, 'expected registered tool commands');
  const missing = [...new Set(names)].filter(name => !skill.includes('`' + name + '`'));
  assert.deepEqual(missing, [], 'SKILL.md is missing registered tool commands');
});
