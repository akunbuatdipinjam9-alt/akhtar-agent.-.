'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { hasSql, installFakeModel, makeApp } = require('./helpers/agent-harness');
const { LEVEL } = require('../src/permissions/levels');
const opts = { skip: !hasSql && 'sql.js not installed (run npm install)' };

const call = (id, name, args = {}) => ({ type: 'tool_call', id, name, arguments: args });
const say = (t) => [{ type: 'text', delta: t }];

function writeTool(counter) {
  return { name: 'demo.write', group: 'demo', description: 'd', inputSchema: { type: 'object', properties: {} }, permission: LEVEL.NONE, category: 'none',
    execute: async () => { counter.n++; return { ok: true }; } };
}

test('e2e: signed-out user (no credits) still completes a run; a successful tool is not reported as failed', opts, async () => {
  const counter = { n: 0 };
  const fake = installFakeModel([[call('c1', 'demo.write')], say('done')]);
  try {
    const { CreditManager } = require('../src/billing/credits');
    const { app, conversationId } = await makeApp({ tools: [writeTool(counter)], credits: new CreditManager({ auth: { accessToken: async () => null } }) });
    const { Agent } = require('../src/agent/agent');
    const r = await new Agent(app).run({ conversationId, workspaceId: null, mode: 'agent', text: 'go' });
    assert.equal(r.task.status, 'completed');
    assert.equal(counter.n, 1, 'tool ran exactly once (no retry of a side effect)');
    const toolMsg = app.repos.listMessages(conversationId).find((m) => m.role === 'tool');
    assert.ok(!String(toolMsg.content).includes('"error"'), 'tool result must be the real result, not a billing error');
  } finally { fake.restore(); }
});

test('e2e: out of credits ends the run cleanly instead of looping', opts, async () => {
  const counter = { n: 0 };
  const fake = installFakeModel([[call('c1', 'demo.write')], [call('c2', 'demo.write')], say('done')]);
  try {
    const credits = { spendEffort: async () => { const e = new Error('Not enough'); e.code = 'INSUFFICIENT_CREDITS'; throw e; }, spendTool: async () => {} };
    const { app, conversationId } = await makeApp({ tools: [writeTool(counter)], credits });
    const { Agent } = require('../src/agent/agent');
    await assert.rejects(new Agent(app).run({ conversationId, workspaceId: null, mode: 'agent', text: 'go' }), /credits/);
    assert.equal(counter.n, 0);
    assert.equal(fake.calls, 1);
  } finally { fake.restore(); }
});

test('e2e: a hanging tool times out, the run continues, and the next model call sees a valid tool result', opts, async () => {
  let secondCallMessages = null;
  const fake = installFakeModel([[call('c1', 'demo.hang')], (msgs) => { secondCallMessages = msgs; return say('recovered'); }]);
  try {
    const hang = { name: 'demo.hang', group: 'demo', description: 'd', inputSchema: { type: 'object', properties: {} }, permission: LEVEL.NONE, category: 'none', timeoutMs: 100, retryable: false, execute: () => new Promise(() => {}) };
    const { app, conversationId } = await makeApp({ tools: [hang] });
    const { Agent } = require('../src/agent/agent');
    const t0 = Date.now();
    const r = await new Agent(app).run({ conversationId, workspaceId: null, mode: 'agent', text: 'go' });
    assert.equal(r.task.status, 'completed');
    assert.ok(Date.now() - t0 < 3000);
    const tr = secondCallMessages.find((m) => m.role === 'tool');
    assert.equal(tr.toolCallId, 'c1');
    assert.match(tr.content, /timed out/i);
  } finally { fake.restore(); }
});

test('e2e: Stop mid-tool, then the next message still gets a provider-valid history', opts, async () => {
  let historyOnNextRun = null;
  const ctrl = new AbortController();
  const fake = installFakeModel([[call('c1', 'demo.slow'), call('c2', 'demo.slow')], (msgs) => { historyOnNextRun = msgs; return say('ok'); }]);
  try {
    const slow = { name: 'demo.slow', group: 'demo', description: 'd', inputSchema: { type: 'object', properties: {} }, permission: LEVEL.NONE, category: 'none', retryable: false,
      execute: (_a, ctx) => new Promise((res, rej) => { setTimeout(() => ctrl.abort(), 20); ctx.signal.addEventListener('abort', () => rej(ctx.signal.reason)); }) };
    const { app, conversationId } = await makeApp({ tools: [slow], settingsPatch: { agent: { parallelTools: false } } });
    const { Agent } = require('../src/agent/agent');
    const r1 = await new Agent(app).run({ conversationId, workspaceId: null, mode: 'agent', text: 'go', signal: ctrl.signal });
    assert.equal(r1.task.status, 'stopped');
    await new Agent(app).run({ conversationId, workspaceId: null, mode: 'agent', text: 'again' });
    const assistant = historyOnNextRun.find((m) => m.toolCalls?.length);
    for (const c of assistant.toolCalls) assert.ok(historyOnNextRun.some((m) => m.role === 'tool' && m.toolCallId === c.id), `result for ${c.id}`);
  } finally { fake.restore(); }
});

test('e2e: a 429 is retried (partial text cleared) and Gemini thoughtSignature is persisted', opts, async () => {
  const { ProviderError } = require('../src/providers/llm/provider');
  let calls = 0;
  const events = [];
  const fake = installFakeModel([
    () => { calls++; return { [Symbol.asyncIterator]: async function* () { yield { type: 'text', delta: 'partial' }; throw Object.assign(new ProviderError('HTTP 429 rate limited', 429, true), { retryAfterMs: 10 }); } }; },
    () => { calls++; return [{ type: 'tool_call', id: 'g1', name: 'demo.write', arguments: {}, meta: { thoughtSignature: 'SIG' } }]; },
    say('done'),
  ]);
  try {
    const counter = { n: 0 };
    const { app, conversationId } = await makeApp({ tools: [writeTool(counter)] });
    const { Agent } = require('../src/agent/agent');
    const r = await new Agent(app).run({ conversationId, workspaceId: null, mode: 'agent', text: 'go', onEvent: (e) => events.push(e.type) });
    assert.equal(r.task.status, 'completed');
    assert.ok(events.includes('stream_reset') && events.includes('model_retry'));
    const withCalls = app.repos.listMessages(conversationId).find((m) => m.toolCalls?.length);
    assert.equal(withCalls.toolCalls[0].meta.thoughtSignature, 'SIG');
    assert.ok(!withCalls.content.includes('partial'));
  } finally { fake.restore(); }
});
