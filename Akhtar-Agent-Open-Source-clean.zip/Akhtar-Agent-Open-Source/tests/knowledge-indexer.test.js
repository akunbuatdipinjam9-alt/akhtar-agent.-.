'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const fs=require('fs'); const os=require('os'); const path=require('path');
const {ProjectKnowledge}=require('../src/knowledge/indexer');
test('indexes and retrieves relevant project text',()=>{const root=fs.mkdtempSync(path.join(os.tmpdir(),'akhtar-rag-'));fs.writeFileSync(path.join(root,'auth.js'),'function verifyToken(){ return "jwt authentication"; }');fs.writeFileSync(path.join(root,'math.js'),'function add(a,b){return a+b}');const db={run(){}};const k=new ProjectKnowledge(db);const ws={id:'w',root_path:root};const idx=k.index(ws);assert.equal(idx.files,2);const hits=k.search(ws,'authentication token');assert.equal(hits[0].path,'auth.js');fs.rmSync(root,{recursive:true,force:true});});
