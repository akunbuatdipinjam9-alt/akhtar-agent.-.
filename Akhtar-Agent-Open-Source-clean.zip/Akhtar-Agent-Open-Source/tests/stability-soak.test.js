'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
const {buildRegistry}=require('../src/tools'); const {shortlistTools}=require('../src/agent/tool-intelligence'); const {runSoak}=require('../src/agent/soak-runner');
test('500-cycle deterministic registry/shortlist soak',async()=>{const r=await runSoak({iterations:500,registry:buildRegistry(),shortlist:shortlistTools});assert.equal(r.ok,true);assert.equal(r.failures,0)});
