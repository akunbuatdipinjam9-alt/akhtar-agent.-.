'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { SkillLoader } = require('../src/skills/loader');
const { inferSkillNames, loadRelevantSkills, buildSkillContext } = require('../src/agent/skill-intelligence');

test('coding task auto-selects tools and coding SKILL.md', () => {
  const names = inferSkillNames('Implement and test this Electron project', { mode: 'agent', toolGroups: ['todo','skill','filesystem','terminal','git'] });
  assert.ok(names.includes('tools'));
  assert.ok(names.includes('coding'));
});

test('browser task auto-selects browser and tools manuals', () => {
  const names = inferSkillNames('Open this website and inspect the page', { mode: 'agent', toolGroups: ['todo','skill','browser'] });
  assert.ok(names.includes('tools'));
  assert.ok(names.includes('browser'));
});

test('runtime actually reads selected SKILL.md content into prompt context', () => {
  const loader = new SkillLoader(path.join(__dirname, '..', 'skills')).reload();
  const loaded = loadRelevantSkills(loader, ['tools','coding']);
  assert.equal(loaded.length, 2);
  const prompt = buildSkillContext(loaded);
  assert.match(prompt, /BUILT-IN SKILL: tools/);
  assert.match(prompt, /BUILT-IN SKILL: coding/);
  assert.match(prompt, /SKILL\.md/);
  assert.match(prompt, /Guard|Permission/i);
});

test('unknown skill is ignored rather than invented', () => {
  const loader = new SkillLoader(path.join(__dirname, '..', 'skills')).reload();
  assert.deepEqual(loadRelevantSkills(loader, ['definitely-not-real']), []);
});
