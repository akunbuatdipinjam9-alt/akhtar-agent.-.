'use strict';
/**
 * SettingsStore only touches the database through a couple of simple
 * SELECT/INSERT-OR-UPDATE calls on one `settings` row, so a tiny in-memory
 * fake standing in for `Database` is enough to test it fully — no need
 * for the real sql.js-backed one here.
 */
const test = require('node:test');
const assert = require('node:assert/strict');

const { SettingsStore, DEFAULTS } = require('../src/main/settings');

function fakeDb() {
  let stored; // SettingsStore only ever touches the single 'app' settings row
  return {
    get() { return stored === undefined ? undefined : { value: stored }; },
    run(sql, params) { stored = params[0]; },
  };
}

test('settings: get() returns full defaults when nothing stored', () => {
  const store = new SettingsStore(fakeDb());
  const s = store.get();
  assert.equal(s.activeModel.providerId, DEFAULTS.activeModel.providerId);
  assert.equal(s.providers.length, DEFAULTS.providers.length);
  assert.equal(s.computerControl.osUrl, '');
});

test('settings: update() merges deeply, keeps unrelated fields, clamps out-of-range numbers', () => {
  const store = new SettingsStore(fakeDb());
  store.update({ agent: { maxIterations: 999 } }); // way over the clamp ceiling
  const s1 = store.get();
  assert.equal(s1.agent.maxIterations, 100, 'clamped to the max');
  assert.equal(s1.agent.runTimeoutMin, DEFAULTS.agent.runTimeoutMin, 'untouched field keeps its default');

  store.update({ computerControl: { osUrl: '  https://example.com/os  ' } });
  const s2 = store.get();
  assert.equal(s2.computerControl.osUrl, 'https://example.com/os', 'trimmed');
  assert.equal(s2.agent.maxIterations, 100, 'earlier update persisted across calls');
});

test('settings: update() preserves a per-provider API-key-independent field and appends unknown custom providers', () => {
  const store = new SettingsStore(fakeDb());
  store.update({ providers: [{ id: 'openai', label: 'OpenAI (renamed)' }, { id: 'my-custom', type: 'openai-compatible', label: 'Custom', baseUrl: 'http://localhost:9999/v1' }] });
  const s = store.get();
  const openai = s.providers.find((p) => p.id === 'openai');
  assert.equal(openai.label, 'OpenAI (renamed)');
  assert.equal(openai.baseUrl, DEFAULTS.providers.find((p) => p.id === 'openai').baseUrl, 'unspecified field keeps its default');
  const custom = s.providers.find((p) => p.id === 'my-custom');
  assert.ok(custom, 'unknown provider id is kept, not dropped');
  assert.equal(custom.baseUrl, 'http://localhost:9999/v1');
});

test('settings: getProvider() looks up by id', () => {
  const store = new SettingsStore(fakeDb());
  assert.equal(store.getProvider('anthropic').label, 'Anthropic');
  assert.equal(store.getProvider('does-not-exist'), null);
});
