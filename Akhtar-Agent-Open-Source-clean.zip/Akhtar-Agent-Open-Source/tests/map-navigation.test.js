'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const mapTools=require('../src/tools/map');const {haversineM,MapNavigationManager}=require('../src/main/map-navigation');
test('map/navigation command surface exists',()=>{const names=new Set(mapTools.map(t=>t.name));for(const n of ['map.open','map.geocode','map.marker_add','map.marker_clear','map.view_set','map.routes','navigation.start','navigation.status','navigation.pause','navigation.resume','navigation.stop','navigation.recalculate'])assert.ok(names.has(n),n)});
test('distance helper is sane',()=>{const d=haversineM({latitude:0,longitude:0},{latitude:0,longitude:1});assert.ok(d>110000&&d<112000)});
test('navigation manager accepts device location',()=>{const m=new MapNavigationManager({getWindow:()=>null});const x=m.setLocation({latitude:-6.2,longitude:106.8,accuracy:10});assert.equal(x.latitude,-6.2);assert.equal(m.status().location.accuracy,10)});
