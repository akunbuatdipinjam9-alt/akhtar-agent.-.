'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { SettingsStore } = require('../src/main/settings');
const { buildSystemPrompt } = require('../src/agent/planner');

function fakeDb(initial = null) {
  let value = initial;
  return {
    get() { return value ? { value } : null; },
    run(_sql, params) { value = params[0]; },
  };
}

test('collaboration defaults to auto and keeps a separate second AI', () => {
  const store = new SettingsStore(fakeDb());
  const s = store.get();
  assert.equal(s.collaboration.mode, 'auto');
  assert.equal(s.collaboration.secondaryProviderId, '');
  assert.equal(s.collaboration.secondaryModel, '');
});

test('collaboration sanitizes invalid mode and disallows primary provider as secondary', () => {
  const store = new SettingsStore(fakeDb());
  const s = store.update({
    activeModel: { providerId: 'openai', model: 'primary-model' },
    collaboration: { mode: 'banana', secondaryProviderId: 'openai', secondaryModel: 'other-model' },
  });
  assert.equal(s.collaboration.mode, 'auto');
  assert.equal(s.collaboration.secondaryProviderId, '');
  assert.equal(s.collaboration.secondaryModel, '');
});

test('planner follows user collaboration mode', () => {
  const base = { mode: 'agent', workspace: null, skills: [], dateTimeIso: '2026-09-26T00:00:00Z', unattended: false };
  const off = buildSystemPrompt({ ...base, collaboration: { mode: 'off' } });
  const auto = buildSystemPrompt({ ...base, collaboration: { mode: 'auto', secondaryProviderId: 'gemini', secondaryModel: 'x' } });
  assert.match(off, /Do not call ai\.delegate/);
  assert.match(auto, /AI collaboration is Auto/);
  assert.match(auto, /Preferred second AI provider: gemini \/ x/);
});
