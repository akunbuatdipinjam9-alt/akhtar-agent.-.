'use strict';
/**
 * Randomized end-to-end soak of the REAL Agent.run loop: tool success / failure / hang,
 * model 429s and dropped streams, and Stop pressed at random moments. Invariants:
 *  - every run reaches a terminal task status (no hang, no unhandled rejection)
 *  - the stored history is always provider-valid (every tool call has exactly one result)
 *  - no "running" tool_call rows are left behind
 *  - AbortSignal listeners don't pile up (MaxListenersExceededWarning)
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const { hasSql, installFakeModel, makeApp } = require('./helpers/agent-harness');
const { LEVEL } = require('../src/permissions/levels');
const { ProviderError } = require('../src/providers/llm/provider');
const { repairToolPairs } = require('../src/agent/context');

const RUNS = Number(process.env.CHAOS_RUNS || 150);

function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 2 ** 32); }

test(`chaos soak: ${RUNS} randomized agent runs keep every invariant`, { skip: !hasSql && 'sql.js not installed (run npm install)', timeout: 180000 }, async () => {
  const warnings = [];
  const onWarn = (w) => warnings.push(w.name);
  const unhandled = [];
  const onUnhandled = (e) => unhandled.push(e);
  process.on('warning', onWarn);
  process.on('unhandledRejection', onUnhandled);
  const rand = rng(42);
  const pick = (arr) => arr[Math.floor(rand() * arr.length)];
  const tools = [
    { name: 'demo.ok', execute: async () => ({ ok: true }) },
    { name: 'demo.fail', execute: async () => { throw new Error('boom'); } },
    { name: 'demo.hang', timeoutMs: 40, retryable: false, execute: () => new Promise(() => {}) },
    { name: 'demo.slow', execute: (_a, ctx) => new Promise((res, rej) => { const t = setTimeout(() => res({ slow: true }), 30); ctx.signal.addEventListener('abort', () => { clearTimeout(t); rej(ctx.signal.reason); }, { once: true }); }) },
  ].map((t) => ({ group: 'demo', description: 'd', inputSchema: { type: 'object', properties: {} }, permission: LEVEL.NONE, category: 'none', ...t }));

  const statuses = {};
  const { app, conversationId } = await makeApp({ tools, settingsPatch: { agent: { maxIterations: 5 } } });
  const { Agent } = require('../src/agent/agent');
  for (let i = 0; i < RUNS; i++) {
    let callNo = 0;
    const script = Array.from({ length: 4 }, () => () => {
      callNo++;
      const r = rand();
      if (r < 0.12) return { [Symbol.asyncIterator]: async function* () { yield { type: 'text', delta: 'x' }; throw new ProviderError('HTTP 429', 429, true); } };
      if (r < 0.55) return Array.from({ length: 1 + Math.floor(rand() * 3) }, (_, k) => ({ type: 'tool_call', id: `r${i}c${callNo}k${k}`, name: pick(tools).name, arguments: {} }));
      return [{ type: 'text', delta: 'done' }];
    });
    const fake = installFakeModel(script);
    const { Agent: A } = require('../src/agent/agent');
    const ctrl = new AbortController();
    if (rand() < 0.25) setTimeout(() => ctrl.abort(), Math.floor(rand() * 60));
    let r;
    try { r = await new A(app).run({ conversationId, workspaceId: null, mode: 'agent', text: `run ${i}`, signal: ctrl.signal }); }
    catch (e) { r = { task: app.tasks.listForConversation(conversationId)[0], error: e }; }
    finally { fake.restore(); }
    const st = r.task?.status; statuses[st] = (statuses[st] || 0) + 1;
    assert.ok(['completed', 'failed', 'stopped', 'timeout'].includes(st), `run ${i} ended in non-terminal status ${st}`);
  }
  void Agent;

  // History is provider-valid after repair, and repair never has to drop a result that exists.
  const history = repairToolPairs(app.repos.listMessages(conversationId));
  for (let k = 0; k < history.length; k++) {
    const m = history[k];
    if (m.role === 'assistant' && m.toolCalls?.length) {
      for (const c of m.toolCalls) assert.equal(history.filter((x) => x.role === 'tool' && x.toolCallId === c.id).length, 1, `exactly one result for ${c.id}`);
    }
  }
  const stuck = app.db.all("SELECT count(*) AS n FROM tool_calls WHERE status IN ('running','verifying')")[0].n;
  assert.equal(stuck, 0, 'no tool_call rows left running');
  await new Promise((res) => setTimeout(res, 100));
  process.off('warning', onWarn); process.off('unhandledRejection', onUnhandled);
  assert.deepEqual(unhandled, [], 'no unhandled rejections');
  assert.ok(!warnings.includes('MaxListenersExceededWarning'), 'no AbortSignal listener leak');
  console.log('chaos soak statuses:', statuses);
});
