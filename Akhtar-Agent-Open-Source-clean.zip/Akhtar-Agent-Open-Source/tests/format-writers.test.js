'use strict';
/**
 * These run with plain `node --test` — no install needed, no Electron,
 * no sql.js. They check the hand-rolled ZIP/PDF/DOCX/PPTX writers, which
 * is the highest-risk hand-written code in the project (binary file
 * formats, no library backing them). Because ZIP entries here are always
 * STORED (uncompressed), the source XML text is verbatim in the output
 * buffer, so these tests can assert on it directly without needing an
 * unzip tool on PATH — keeps this test portable to Windows CI too.
 */
const test = require('node:test');
const assert = require('node:assert/strict');

const { buildZip, crc32 } = require('../src/utils/zip');
const { textToPdf } = require('../src/utils/pdf');
const { textToDocx } = require('../src/utils/docx');
const { slidesToPptx } = require('../src/utils/pptx');

test('zip: crc32 is a known value', () => {
  // Standard reference value for the ASCII string "123456789".
  assert.equal(crc32(Buffer.from('123456789')), 0xcbf43926);
});

test('zip: buildZip produces a well-formed local+central+EOCD structure', () => {
  const buf = buildZip([
    { name: 'a.txt', data: Buffer.from('hello') },
    { name: 'dir/b.txt', data: Buffer.from('world!') },
  ]);
  assert.equal(buf.readUInt32LE(0), 0x04034b50, 'starts with a local file header signature');
  // End Of Central Directory signature must appear somewhere near the tail.
  const eocdSig = Buffer.from([0x50, 0x4b, 0x05, 0x06]);
  assert.ok(buf.includes(eocdSig), 'contains an EOCD signature');
  assert.ok(buf.includes(Buffer.from('a.txt')));
  assert.ok(buf.includes(Buffer.from('dir/b.txt')));
  assert.ok(buf.includes(Buffer.from('hello')));
  // EOCD's entry count field (2 bytes, offset 8 from EOCD start) must read 2.
  const eocdStart = buf.lastIndexOf(eocdSig);
  assert.equal(buf.readUInt16LE(eocdStart + 8), 2);
});

test('pdf: textToPdf produces a syntactically plausible single/multi-page PDF', () => {
  const short = textToPdf('Judul Pendek', 'Baris pertama.\nBaris kedua.');
  const head = short.toString('latin1', 0, 8);
  assert.equal(head, '%PDF-1.4');
  assert.ok(short.toString('latin1').trim().endsWith('%%EOF'));
  assert.ok(short.includes(Buffer.from('Judul Pendek', 'latin1')));

  // A long body must paginate into more than one page object.
  const longBody = Array.from({ length: 200 }, (_, i) => `Baris nomor ${i + 1} untuk memaksa banyak halaman.`).join('\n');
  const long = textToPdf('Dokumen Panjang', longBody);
  const pageObjMatches = long.toString('latin1').match(/\/Type \/Page\b/g) || [];
  assert.ok(pageObjMatches.length >= 2, `expected multiple /Page objects, got ${pageObjMatches.length}`);
});

test('docx: textToDocx embeds title, paragraph, bold and bullet markup', () => {
  const buf = textToDocx('Judul Dokumen', '## Sub\n\nParagraf dengan **tebal**.\n\n- Butir satu\n- Butir dua');
  const s = buf.toString('utf8'); // STORED entries: source text is verbatim (mod XML escaping) in the buffer
  assert.ok(s.includes('word/document.xml'));
  assert.ok(s.includes('Judul Dokumen'));
  assert.ok(s.includes('<w:b/>'), 'bold run present for heading/bold text');
  assert.ok(s.includes('Butir satu') && s.includes('Butir dua'));
  assert.ok(s.includes('[Content_Types].xml') && s.includes('_rels/.rels'));
});

test('docx: escapes XML-sensitive characters', () => {
  const buf = textToDocx('A & B < C > D', 'Quote: "x" and an ampersand & here.');
  const s = buf.toString('utf8');
  assert.ok(s.includes('A &amp; B &lt; C &gt; D'));
  assert.ok(!s.includes('Quote: "x" and an ampersand & here.'), 'raw unescaped text should not appear verbatim');
});

test('pptx: slidesToPptx embeds every slide title and bullet, one slide file per entry plus a title slide', () => {
  const buf = slidesToPptx('Judul Presentasi', [
    { title: 'Slide Satu', bullets: ['Poin A', 'Poin B'] },
    { title: 'Slide Dua', bullets: ['Poin C'] },
  ]);
  const s = buf.toString('utf8');
  for (const needle of ['Judul Presentasi', 'Slide Satu', 'Poin A', 'Poin B', 'Slide Dua', 'Poin C']) {
    assert.ok(s.includes(needle), `missing "${needle}" in pptx output`);
  }
  assert.ok(s.includes('ppt/slides/slide1.xml'));
  assert.ok(s.includes('ppt/slides/slide2.xml'));
  assert.ok(s.includes('ppt/slides/slide3.xml'), 'title slide + 2 content slides = 3 slide parts');
  assert.ok(!s.includes('ppt/slides/slide4.xml'));
});

test('pptx: content types lists one Override per slide', () => {
  const buf = slidesToPptx('T', [{ title: 'S1' }, { title: 'S2' }, { title: 'S3' }]);
  const s = buf.toString('utf8');
  const matches = s.match(/ContentType="application\/vnd\.openxmlformats-officedocument\.presentationml\.slide\+xml"/g) || [];
  assert.equal(matches.length, 4, '3 content slides + 1 title slide = 4 slide parts');
});
