'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
const tools=require('../src/tools/system-controls');
test('system controls expose volume and brightness commands',()=>{assert.deepEqual(tools.map(t=>t.name),['volume.get','volume.set','volume.up','volume.down','volume.mute','brightness.get','brightness.set','brightness.up','brightness.down']);});
test('mutating system controls are sensitive',()=>{for(const t of tools.filter(x=>!x.name.endsWith('.get'))) assert.equal(t.permission,'SENSITIVE');});
test('set commands require 0-100 values',()=>{for(const n of ['volume.set','brightness.set']){const t=tools.find(x=>x.name===n);assert.equal(t.inputSchema.properties.value.minimum,0);assert.equal(t.inputSchema.properties.value.maximum,100);}});
