'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const fs=require('node:fs'); const path=require('node:path');
const { SkillLoader }=require('../src/skills/loader');
test('tools skill documents core commands and Ummah tools',()=>{const l=new SkillLoader(path.join(__dirname,'..','skills')).reload(); const s=l.get('tools'); assert.ok(s); for(const n of ['hadith.search','hadith.get','moon.current','moon.to_hijri','qibla.direction','skill.load','browser.observe','ai.delegate','mcp.call','chart.create']) assert.match(s.body,new RegExp(n.replace('.','\\.')));});
test('planner tells model when to load tools skill',()=>{const p=fs.readFileSync(path.join(__dirname,'..','src','agent','planner.js'),'utf8'); assert.match(p,/load the tools skill/); assert.match(p,/Hadith\/Moon\/Qibla/);});
