'use strict';
/** Regression tests for bug-hunt round 3 (git, terminal git, github, ghost, checkpoints, code). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execSync } = require('node:child_process');

const gitTools = require('../src/tools/git');
const terminal = require('../src/tools/terminal');
const { classify } = require('../src/tools/terminal/classifier');
const gh = require('../src/tools/github');
const { GhostWorkspaceManager } = require('../src/agent/ghost-workspace');

let hasGit = true; try { execSync('git --version', { stdio: 'ignore' }); } catch { hasGit = false; }

test('git.status in an untrusted repo does not run core.fsmonitor', { skip: !hasGit || process.platform === 'win32' }, async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'evil-'));
  const marker = path.join(os.tmpdir(), `pwned-${Date.now()}`);
  execSync(`git init -q && git config core.fsmonitor "touch ${marker}; false #"`, { cwd: root });
  const ctx = { workspace: { root_path: root }, settings: { agent: { toolTimeoutSec: 10 } } };
  await gitTools.find((t) => t.name === 'git.status').execute({}, ctx).catch(() => {});
  assert.equal(fs.existsSync(marker), false);
});

test('git.branch rejects option-like / path-like names', () => {
  const { assertBranchName } = gitTools.helpers;
  for (const bad of ['-f', '--force', 'a..b', 'x y', 'a~1', 'HEAD@{1}', 'foo.lock', '']) assert.throws(() => assertBranchName(bad));
  assert.equal(assertBranchName('feature/login-v2'), 'feature/login-v2');
});

test('terminal: git is run with config-driven program execution disabled', () => {
  const argv = terminal.hardenGitArgv(['git', 'diff', 'HEAD'], 'SAFE');
  assert.ok(argv.includes('core.fsmonitor=false') && argv.includes('--no-textconv') && argv.includes('--no-ext-diff'));
  assert.equal(argv[argv.indexOf('diff') + 1], '--no-textconv');
  assert.deepEqual(terminal.hardenGitArgv(['npm', 'test'], 'CAUTION'), ['npm', 'test']);
  for (const c of ['git -c core.fsmonitor=x status', 'git diff --ext-diff', 'git log --textconv']) assert.equal(classify(c, { cwd: '/tmp', root: '/tmp' }).level, 'CAUTION', c);
});

test('github: owner/repo cannot traverse to other API endpoints', () => {
  const { assertRepoRef } = gh.helpers;
  for (const bad of [{ owner: '..', repo: 'x' }, { owner: 'a/../../user', repo: 'x' }, { owner: 'a', repo: 'b?x=1' }]) assert.throws(() => assertRepoRef(bad));
  assert.ok(assertRepoRef({ owner: 'akunbuatdipinjam9-alt', repo: 'akhtaros.-' }));
});

test('ghost apply refuses to overwrite files changed in the real workspace, unless forced', () => {
  const src = fs.mkdtempSync(path.join(os.tmpdir(), 'ghost-src-'));
  fs.writeFileSync(path.join(src, 'a.txt'), 'v1');
  const g = new GhostWorkspaceManager();
  const s = g.create({ id: 'w', root_path: src });
  fs.writeFileSync(path.join(s.rootPath, 'a.txt'), 'ghost edit');
  fs.writeFileSync(path.join(src, 'a.txt'), 'user edit meanwhile');
  assert.throws(() => g.apply(s.id), /changed in the real workspace/);
  assert.equal(fs.readFileSync(path.join(src, 'a.txt'), 'utf8'), 'user edit meanwhile');
  g.apply(s.id, { force: true });
  assert.equal(fs.readFileSync(path.join(src, 'a.txt'), 'utf8'), 'ghost edit');
  assert.equal(g.apply(s.id).applied, 0, 'second apply is a no-op');
  g.discard(s.id);
});
