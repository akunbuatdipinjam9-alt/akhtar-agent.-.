'use strict';
/** Regression tests for bug-hunt round 2 (browser tabs, MCP, browser.open, scheduler). */
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const Module = require('node:module');

// browser-tabs.js imports electron; stub it so the pure helpers can be tested in plain Node.
const realLoad = Module._load;
Module._load = function (req, ...rest) { return req === 'electron' ? { WebContentsView: class {} } : realLoad.call(this, req, ...rest); };
const { normalizeWebUrl, samePlace } = require('../src/main/browser-tabs');
Module._load = realLoad;

const browserTools = require('../src/tools/browser');
const { McpManager } = require('../src/mcp/client');

test('browser tabs: only http/https (and about:blank) can be loaded in regular tabs', () => {
  assert.equal(normalizeWebUrl('example.com'), 'https://example.com/');
  assert.equal(normalizeWebUrl(''), 'about:blank');
  for (const bad of ['file:///etc/passwd', 'javascript:alert(1)', 'data:text/html,hi', 'chrome://settings']) {
    assert.throws(() => normalizeWebUrl(bad), /Only http\/https/);
  }
});

test('privileged tab may only stay on its own file / origin', () => {
  assert.equal(samePlace('file:///a/os.html#x', 'file:///a/os.html'), true);
  assert.equal(samePlace('https://evil.com/', 'file:///a/os.html'), false);
  assert.equal(samePlace('file:///a/other.html', 'file:///a/os.html'), false);
  assert.equal(samePlace('https://os.example.com/app', 'https://os.example.com/'), true);
});

test('browser.open: local hosts need their own permission; public redirect into LAN is refused', async () => {
  const open = browserTools.find((t) => t.name === 'browser.open');
  assert.equal((await open.preview({ url: 'http://127.0.0.1:3000' })).category, 'network.local');
  assert.equal((await open.preview({ url: 'https://example.com' })).category, undefined);
  const { isPrivateHost } = browserTools._internals;
  assert.ok(isPrivateHost('169.254.169.254') && isPrivateHost('[::1]') && !isPrivateHost('8.8.8.8'));
});

test('browser.open: response body is capped', async () => {
  const srv = http.createServer((_q, r) => { r.writeHead(200, { 'content-type': 'text/plain' }); const b = Buffer.alloc(1 << 20, 97); let n = 0; const w = () => { while (n < 6) { n++; if (!r.write(b)) return r.once('drain', w); } r.end(); }; w(); });
  await new Promise((r) => srv.listen(0, r));
  try {
    const res = await browserTools._internals.fetchText(`http://127.0.0.1:${srv.address().port}/`);
    assert.ok(res.truncatedBody && res.body.length <= 3 * 1024 * 1024);
  } finally { srv.close(); }
});

function fakeServer(code) {
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'mcp-')), 'srv.js');
  fs.writeFileSync(f, code);
  return f;
}

test('MCP: writing to a server whose stdin closed does not crash (EPIPE) and rejects cleanly', async () => {
  const f = fakeServer(`const rl=require('readline').createInterface({input:process.stdin});
    rl.on('line',l=>{const m=JSON.parse(l); if(m.method==='initialize'){process.stdout.write(JSON.stringify({jsonrpc:'2.0',id:m.id,result:{}})+'\\n'); setTimeout(()=>{process.stdin.destroy(); require('fs').closeSync(0)},50);}});
    setInterval(()=>{},1000);`);
  const m = new McpManager(() => ({ mcp: { servers: [{ id: 'f', command: process.execPath, args: [f] }] } }));
  const c = await m.connection('f');
  await new Promise((r) => setTimeout(r, 300));
  for (let i = 0; i < 3; i++) await assert.rejects(c.request('tools/call', { big: 'x'.repeat(200000) }, undefined, 500));
  m.stopAll();
});

test('MCP: answers server ping and recovers after the server exits', async () => {
  const f = fakeServer(`const rl=require('readline').createInterface({input:process.stdin});
    let pong=false;
    rl.on('line',l=>{const m=JSON.parse(l);
      if(m.method==='initialize'){process.stdout.write(JSON.stringify({jsonrpc:'2.0',id:'s1',method:'ping'})+'\\n');process.stdout.write(JSON.stringify({jsonrpc:'2.0',id:m.id,result:{}})+'\\n');}
      else if(m.id==='s1'&&m.result){pong=true;}
      else if(m.method==='tools/list'){process.stdout.write(JSON.stringify({jsonrpc:'2.0',id:m.id,result:{tools:[{name:pong?'pong':'nopong'}]}})+'\\n');}
      else if(m.method==='tools/call'){process.exit(3);} });`);
  const m = new McpManager(() => ({ mcp: { servers: [{ id: 'f', command: process.execPath, args: [f] }] } }));
  await new Promise((r) => setTimeout(r, 50));
  assert.equal((await m.listTools('f'))[0].name, 'pong');
  await assert.rejects(m.callTool('f', 'x', {}), /exited/);
  assert.equal((await m.listTools('f'))[0].name, 'pong'); // auto-restarted
  m.stopAll();
});
