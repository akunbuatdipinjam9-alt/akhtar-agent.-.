'use strict';
/**
 * These need `sql.js` (a real dependency, installed via `npm install`),
 * so — unlike tests/format-writers.test.js and tests/tools-registry.test.js —
 * they could not be run inside the sandbox this project was built in (no
 * network to install anything). Written carefully against the Database
 * class's own API, but run `npm test` after `npm install` on a real
 * machine to be sure.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');

const { Database } = require('../src/database/database');
const { Repos } = require('../src/database/repos');
const { TodoManager } = require('../src/todo/manager');
const { MemoryManager } = require('../src/memory/manager');
const { TaskManager } = require('../src/agent/task-manager');
const { CheckpointManager } = require('../src/checkpoints/manager');
const { ArtifactManager } = require('../src/artifacts/manager');
const { SchedulerManager } = require('../src/scheduler/manager');

async function freshDb() {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-test-')), 'test.sqlite');
  const db = new Database();
  await db.init(file);
  return db;
}

test('todo: create/add/update/complete round-trips and preserves order', async () => {
  const db = await freshDb();
  const todo = new TodoManager(db);
  const taskId = 'task-1';
  todo.create(taskId, [{ title: 'Satu' }, { title: 'Dua', priority: 'high' }]);
  let list = todo.list(taskId);
  assert.equal(list.length, 2);
  assert.equal(list[0].title, 'Satu');
  assert.equal(list[1].priority, 'high');

  const thirdId = todo.add(taskId, { title: 'Tiga' });
  list = todo.list(taskId);
  assert.equal(list.length, 3);
  assert.equal(list[2].id, thirdId);

  todo.update(taskId, list[0].id, { status: 'in_progress' });
  todo.update(taskId, list[1].id, { status: 'completed' });
  list = todo.list(taskId);
  assert.equal(list[0].status, 'in_progress');
  assert.equal(list[1].status, 'completed');
  assert.equal(todo.isDone(taskId), false, 'not all todos are settled yet');

  todo.update(taskId, list[0].id, { status: 'completed' });
  todo.update(taskId, thirdId, { status: 'failed' });
  assert.equal(todo.isDone(taskId), true);

  assert.throws(() => todo.update(taskId, 'no-such-id', { status: 'completed' }), /not found/);
});

test('memory: stores approved facts, refuses secrets, splits global/project scope', async () => {
  const db = await freshDb();
  const mem = new MemoryManager(db);
  mem.add({ scope: 'global', content: 'User prefers concise answers.' });
  mem.add({ scope: 'project', workspaceId: 'ws-1', content: 'This project uses pnpm, not npm.' });
  mem.add({ scope: 'project', workspaceId: 'ws-2', content: 'Different project entirely.' });

  const forWs1 = mem.list('ws-1');
  assert.ok(forWs1.some((m) => m.content.includes('concise')), 'global memory visible in workspace context');
  assert.ok(forWs1.some((m) => m.content.includes('pnpm')), 'ws-1 project memory visible');
  assert.ok(!forWs1.some((m) => m.content.includes('Different project')), 'ws-2 memory must not leak into ws-1');

  const globalOnly = mem.list(null);
  assert.equal(globalOnly.length, 1);

  assert.throws(() => mem.assertStorable('my api_key: sk-abcdef1234567890'), /credential/);
  assert.throws(() => mem.assertStorable('   '), /empty/);
});

test('tasks: create/update/events/tool-call logging', async () => {
  const db = await freshDb();
  const tasks = new TaskManager(db);
  const t = tasks.create({ conversationId: 'c1', workspaceId: 'w1', title: 'Do the thing', mode: 'agent' });
  assert.equal(t.status, 'running');

  tasks.addEvent(t.id, 'tool_error', 'boom', { tool: 'file.write' });
  const events = tasks.listEvents(t.id);
  assert.equal(events.length, 1);
  assert.equal(events[0].type, 'tool_error');

  const callId = tasks.logToolCall({ taskId: t.id, conversationId: 'c1', name: 'file.write', args: { path: 'x.txt' } });
  tasks.finishToolCall(callId, { status: 'success', result: { verified: true } });

  const updated = tasks.update(t.id, { status: 'completed' });
  assert.equal(updated.status, 'completed');
  assert.equal(tasks.listForConversation('c1').length, 1);
});

test('checkpoints: records a before-state and restores it', async () => {
  const db = await freshDb();
  const cp = new CheckpointManager(db);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-cp-'));
  const filePath = path.join(dir, 'file.txt');
  fs.writeFileSync(filePath, 'original content');

  const ctx = { workspaceId: 'w1', taskId: 't1' };
  // Simulate what a filesystem tool does: snapshot BEFORE writing new content.
  const before = fs.readFileSync(filePath);
  cp.record(ctx, { action: 'write', path: filePath, before });
  fs.writeFileSync(filePath, 'new content, oops');

  assert.equal(fs.readFileSync(filePath, 'utf8'), 'new content, oops');
  const results = await cp.restore(ctx._checkpointId);
  assert.equal(results[0].ok, true);
  assert.equal(fs.readFileSync(filePath, 'utf8'), 'original content');
});

test('checkpoints: restoring a create (before=null) deletes the file', async () => {
  const db = await freshDb();
  const cp = new CheckpointManager(db);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-cp2-'));
  const filePath = path.join(dir, 'new-file.txt');
  const ctx = { workspaceId: 'w1', taskId: 't1' };
  cp.record(ctx, { action: 'write', path: filePath, before: null });
  fs.writeFileSync(filePath, 'freshly created');
  assert.ok(fs.existsSync(filePath));
  await cp.restore(ctx._checkpointId);
  assert.ok(!fs.existsSync(filePath), 'file created after the checkpoint should be removed on restore');
});

test('artifacts: create/list/rename/remove', async () => {
  const db = await freshDb();
  const artifacts = new ArtifactManager(db);
  const a = artifacts.create({ workspaceId: 'w1', taskId: 't1', name: 'report.pdf', path: '/tmp/report.pdf', type: 'document' });
  assert.ok(a.id);
  assert.equal(artifacts.list('w1').length, 1);
  const renamed = artifacts.rename(a.id, 'final-report.pdf');
  assert.equal(renamed.name, 'final-report.pdf');
  artifacts.remove(a.id);
  assert.equal(artifacts.list('w1').length, 0);
});

test('scheduler: create validates required fields per recurrence and computes next_run_at', async () => {
  const db = await freshDb();
  const scheduler = new SchedulerManager({ db });
  const s = scheduler.create({ workspaceId: 'w1', title: 'Cek BTC', instruction: 'Cek harga BTC', recurrence: 'daily', time: '07:00', timezone: 'Asia/Jakarta' });
  assert.ok(s.id);
  assert.ok(s.next_run_at > Date.now());
  assert.equal(s.enabled, true);

  assert.throws(() => scheduler.create({ title: 'x', instruction: 'y', recurrence: 'weekly', time: '07:00' }), /day_of_week/);
  assert.throws(() => scheduler.create({ title: 'x', instruction: 'y', recurrence: 'monthly', time: '07:00' }), /day_of_month/);
  assert.throws(() => scheduler.create({ title: 'x', instruction: 'y', recurrence: 'once' }), /run_at/);
  assert.throws(() => scheduler.create({ title: '', instruction: 'y', recurrence: 'daily', time: '07:00' }), /title/);
});

test('scheduler: list/pause/resume/remove round-trip', async () => {
  const db = await freshDb();
  const scheduler = new SchedulerManager({ db });
  const a = scheduler.create({ workspaceId: 'w1', title: 'A', instruction: 'do a', recurrence: 'daily', time: '08:00' });
  scheduler.create({ workspaceId: 'w1', title: 'B', instruction: 'do b', recurrence: 'daily', time: '09:00' });
  scheduler.create({ workspaceId: 'w2', title: 'C', instruction: 'do c', recurrence: 'daily', time: '10:00' });

  assert.equal(scheduler.list('w1').length, 2, 'scoped to workspace');
  assert.equal(scheduler.list().length, 3, 'no workspace filter returns all');

  const paused = scheduler.setEnabled(a.id, false);
  assert.equal(paused.enabled, false);
  assert.equal(scheduler.get(a.id).enabled, false);

  const resumed = scheduler.setEnabled(a.id, true);
  assert.equal(resumed.enabled, true);

  scheduler.remove(a.id);
  assert.equal(scheduler.get(a.id), null);
  assert.equal(scheduler.list('w1').length, 1);
});

test('scheduler: tick only picks up due, enabled schedules', async () => {
  const db = await freshDb();
  const scheduler = new SchedulerManager({ db, repos: null, agent: null, getWindow: () => null });
  const due = scheduler.create({ title: 'Due now', instruction: 'x', recurrence: 'once', run_at: new Date(Date.now() - 1000).toISOString() });
  scheduler.create({ title: 'Future', instruction: 'x', recurrence: 'once', run_at: new Date(Date.now() + 3600000).toISOString() });
  scheduler.setEnabled(scheduler.create({ title: 'Due but paused', instruction: 'x', recurrence: 'once', run_at: new Date(Date.now() - 1000).toISOString() }).id, false);

  const dueRows = db.all('SELECT * FROM schedules WHERE enabled = 1 AND next_run_at <= ?', [Date.now()]);
  assert.equal(dueRows.length, 1);
  assert.equal(dueRows[0].id, due.id);
});

test('repos: workspace + conversation + message CRUD, including cascade delete', async () => {
  const db = await freshDb();
  const repos = new Repos(db);
  const ws = repos.createWorkspace({ name: 'Demo', rootPath: '/tmp/demo' });
  const found = repos.findWorkspaceByRoot('/tmp/demo');
  assert.equal(found.id, ws.id);

  const conv = repos.createConversation({ workspaceId: ws.id, title: 'Chat 1', mode: 'assist' });
  repos.addMessage({ conversationId: conv.id, role: 'user', content: 'Hi' });
  repos.addMessage({ conversationId: conv.id, role: 'assistant', content: 'Hello!' });
  assert.equal(repos.listMessages(conv.id).length, 2);
  assert.equal(repos.lastUserMessage(conv.id).content, 'Hi');

  repos.deleteConversation(conv.id);
  assert.equal(repos.listMessages(conv.id).length, 0);
  assert.equal(repos.listConversations(ws.id).length, 0);
});
