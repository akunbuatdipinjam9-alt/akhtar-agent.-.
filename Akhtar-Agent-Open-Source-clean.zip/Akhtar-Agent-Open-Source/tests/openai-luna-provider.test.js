'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createProvider } = require('../src/providers/llm');
const { DEFAULTS } = require('../src/main/settings');

test('Akhtar Cloud auto router is primary with OSS, Mini, and Luna', () => {
  assert.equal(DEFAULTS.activeModel.providerId, 'akhtar-openai-router');
  assert.equal(DEFAULTS.routing.auto, true);
  const cfg = DEFAULTS.providers.find((p) => p.id === 'akhtar-openai-router');
  assert.ok(cfg);
  assert.equal(cfg.type, 'supabase-openai');
  assert.deepEqual(cfg.models, ['gpt-oss-120b', 'gpt-5-mini', 'gpt-5.6-luna']);
});

test('Supabase OpenAI provider uses user JWT and publishable key, not an OpenAI key', async () => {
  const cfg = DEFAULTS.providers.find((p) => p.id === 'akhtar-luna');
  const p = createProvider(cfg, 'user-jwt');
  assert.equal(p.requiresKey, false);
  assert.equal(p.chatCompletionsUrl, 'https://ldjlvbrzsuykepujsqhy.supabase.co/functions/v1/openai-luna');
  assert.equal(p.headers().Authorization, 'Bearer user-jwt');
  assert.equal(p.headers().apikey, cfg.publishableKey);
  assert.deepEqual(await p.getModels(), ['gpt-5.6-luna']);
});

test('Supabase OpenAI provider requires Akhtar sign-in', () => {
  const cfg = DEFAULTS.providers.find((p) => p.id === 'akhtar-luna');
  const p = createProvider(cfg, '');
  assert.throws(() => p.ensureKey(), /Sign in to Akhtar Agent/i);
});
