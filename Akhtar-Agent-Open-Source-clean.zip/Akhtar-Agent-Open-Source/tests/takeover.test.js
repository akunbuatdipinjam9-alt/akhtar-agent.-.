'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');

test('Take Over IPC is exposed only through preload bridge', () => {
  const ipc = fs.readFileSync(path.join(root, 'src/main/ipc.js'), 'utf8');
  const preload = fs.readFileSync(path.join(root, 'src/preload/preload.js'), 'utf8');
  assert.match(ipc, /agent:takeover/);
  assert.match(ipc, /agent:continue/);
  assert.match(preload, /takeOverAgent: invoke\('agent:takeover'\)/);
  assert.match(preload, /continueAgent: invoke\('agent:continue'\)/);
});

test('Agent yields at safe points for manual takeover', () => {
  const agent = fs.readFileSync(path.join(root, 'src/agent/agent.js'), 'utf8');
  assert.match(agent, /takeover\.safePoint\(`before model iteration/);
  // Safe points receive the run signal so Stop / run-timeout can wake a paused run.
  assert.match(agent, /takeover\.safePoint\(`before \$\{call\.name\}`, ctrl\.signal\)/);
  assert.match(agent, /takeover\.safePoint\(`after \$\{call\.name\}`, ctrl\.signal\)/);
});

test('Renderer contains Take over and Continue controls', () => {
  const html = fs.readFileSync(path.join(root, 'src/renderer/index.html'), 'utf8');
  const app = fs.readFileSync(path.join(root, 'src/renderer/app.js'), 'utf8');
  assert.match(html, /id="takeoverBtn"/);
  assert.match(html, /id="continueBtn"/);
  assert.match(app, /case 'takeover_started'/);
  assert.match(app, /case 'takeover_ended'/);
});
