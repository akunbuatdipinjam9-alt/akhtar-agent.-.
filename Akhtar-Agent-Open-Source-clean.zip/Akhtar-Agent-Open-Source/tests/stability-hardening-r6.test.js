'use strict';
/**
 * R6 stability hardening tests:
 * 1. Checkpoint conflict detection & safe restore
 * 2. Ghost workspace disk manifest & session discovery
 * 3. Terminal executor process-group termination (no zombies, fast cancel)
 */
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { CheckpointManager } = require('../src/checkpoints/manager');
const { GhostWorkspaceManager } = require('../src/agent/ghost-workspace');
const { runCommand } = require('../src/tools/terminal/executor');

// Minimal in-memory DB shim matching the sql.js wrapper API used by CheckpointManager.
function makeDb() {
  const checkpoints = [];
  const files = [];
  let fileId = 0;
  return {
    run(sql, params) {
      if (sql.startsWith('INSERT INTO checkpoints')) {
        checkpoints.push({ id: params[0], workspace_id: params[1], task_id: params[2], label: params[3], created_at: params[4], restored_at: null });
      } else if (sql.startsWith('INSERT INTO checkpoint_files')) {
        files.push({ id: ++fileId, checkpoint_id: params[0], action: params[1], path: params[2], before: params[3], extra: params[4], created_at: params[5] });
      } else if (sql.startsWith('UPDATE checkpoint_files SET extra')) {
        const row = files.find((f) => f.id === params[1]);
        if (row) row.extra = params[0];
      } else if (sql.startsWith('UPDATE checkpoints SET restored_at')) {
        const cp = checkpoints.find((c) => c.id === params[1]);
        if (cp) cp.restored_at = params[0];
      } else if (sql.startsWith('DELETE FROM checkpoint_files')) {
        for (let i = files.length - 1; i >= 0; i--) if (files[i].checkpoint_id === params[0]) files.splice(i, 1);
      } else if (sql.startsWith('DELETE FROM checkpoints')) {
        const i = checkpoints.findIndex((c) => c.id === params[0]);
        if (i >= 0) checkpoints.splice(i, 1);
      }
    },
    get(sql, params) {
      return this.all(sql, params)[0];
    },
    all(sql, params) {
      if (sql.includes('FROM checkpoints WHERE task_id')) return checkpoints.filter((c) => c.task_id === params[0] && !c.restored_at).sort((a, b) => b.created_at - a.created_at);
      if (sql.includes('FROM checkpoints WHERE id')) return checkpoints.filter((c) => c.id === params[0]);
      if (sql.includes('FROM checkpoints WHERE workspace_id')) return checkpoints.filter((c) => c.workspace_id === params[0]).sort((a, b) => b.created_at - a.created_at);
      if (sql.includes('FROM checkpoint_files WHERE checkpoint_id = ? AND path')) return files.filter((f) => f.checkpoint_id === params[0] && f.path === params[1]).sort((a, b) => b.id - a.id);
      if (sql.includes('FROM checkpoint_files WHERE checkpoint_id')) return files.filter((f) => f.checkpoint_id === params[0]).sort((a, b) => b.id - a.id);
      return [];
    },
  };
}

test('Checkpoint Conflict Detection & Safe Restore', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-r6-cp-'));
  const file = path.join(dir, 'a.txt');
  fs.writeFileSync(file, 'original');

  const mgr = new CheckpointManager(makeDb());
  const ctx = { workspaceId: 'w1', taskId: 't1' };
  const before = Buffer.from('original');
  const cpId = mgr.record(ctx, { action: 'write', path: file, before });
  fs.writeFileSync(file, 'agent edit');
  mgr.recordPostState(cpId, file);

  // No conflict right after the agent's edit.
  assert.deepStrictEqual(mgr.checkConflicts(cpId), []);

  // User edits the file manually -> conflict detected, plain restore refused.
  fs.writeFileSync(file, 'user manual edit');
  const conflicts = mgr.checkConflicts(cpId);
  assert.strictEqual(conflicts.length, 1);
  assert.strictEqual(conflicts[0].path, file);
  await assert.rejects(() => mgr.restore(cpId), /Restore blocked/);

  // Force restore without backup overwrites.
  fs.writeFileSync(file, 'user manual edit');
  await mgr.restore(cpId, { force: true, backupConflicts: true });
  assert.strictEqual(fs.readFileSync(file, 'utf8'), 'original');
  const backups = fs.readdirSync(dir).filter((f) => f.startsWith('a.txt.backup-'));
  assert.strictEqual(backups.length, 1);
  assert.strictEqual(fs.readFileSync(path.join(dir, backups[0]), 'utf8'), 'user manual edit');

  fs.rmSync(dir, { recursive: true, force: true });
});

test('Ghost Workspace: Disk Manifest & Discovery', () => {
  const src = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-r6-src-'));
  fs.writeFileSync(path.join(src, 'hello.txt'), 'hi');

  const mgr1 = new GhostWorkspaceManager();
  const session = mgr1.create({ id: 'w1', root_path: src });

  // Manifest persisted inside the ghost root.
  const manifestPath = path.join(session.rootPath, 'manifest.json');
  assert.ok(fs.existsSync(manifestPath));
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  assert.strictEqual(manifest.id, session.id);
  assert.strictEqual(manifest.sourceRoot, src);

  // Simulate a crash: a brand-new manager (empty memory) rediscovers the session.
  const mgr2 = new GhostWorkspaceManager();
  const found = mgr2.discoverSessions().filter((s) => s.id === session.id);
  assert.strictEqual(found.length, 1);
  assert.strictEqual(found[0].sourceRoot, src);

  // Manifest itself must not show up as a change.
  assert.deepStrictEqual(found[0].changes, []);

  // Stale cleanup removes old sessions.
  const stale = mgr2.cleanupStale(0);
  assert.ok(stale.removed >= 1);
  assert.ok(!fs.existsSync(session.rootPath));

  mgr1.discardAll();
  fs.rmSync(src, { recursive: true, force: true });
});

test('Terminal Executor: Process Group Termination', async () => {
  if (process.platform === 'win32') return; // group-kill semantics are Unix-specific
  const marker = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-r6-term-')), 'child-alive');
  const controller = new AbortController();

  // Spawn a shell script whose child writes a marker every 100ms; cancel quickly.
  const started = Date.now();
  const promise = runCommand(
    ['/bin/sh', '-c', `(while true; do touch "${marker}"; sleep 0.1; done) & wait`],
    { cwd: os.tmpdir(), timeoutMs: 30000, signal: controller.signal },
  );
  setTimeout(() => controller.abort(), 150);
  const result = await promise;
  const elapsed = Date.now() - started;

  assert.strictEqual(result.cancelled, true);
  assert.ok(elapsed < 5000, `cancellation took too long: ${elapsed}ms`);

  // Wait past the SIGKILL fallback, then confirm the marker stopped updating (no zombie child).
  const mtime1 = fs.existsSync(marker) ? fs.statSync(marker).mtimeMs : 0;
  await new Promise((r) => setTimeout(r, 3500));
  const mtime2 = fs.existsSync(marker) ? fs.statSync(marker).mtimeMs : 0;
  assert.strictEqual(mtime1, mtime2, 'child process kept running after kill (zombie)');
});
