'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { resolveInWorkspace, relPath } = require('../src/tools/filesystem/pathguard');

function freshRoot() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-osfs-'));
}

test('pathguard: resolves the real-world akhtarFS path shapes used by Akhtar OS', () => {
  const root = freshRoot();
  // Exactly the path strings os/akhtar-os.html's own call sites use (see os-fs.js header).
  for (const p of ['files', 'files/Documents', 'files/Documents/readme.txt', 'wallpaper biasa', 'wallpaper biasa/bg.png', 'Catatan/catatan.txt']) {
    const abs = resolveInWorkspace(root, p);
    assert.ok(abs.startsWith(root), `"${p}" should resolve inside root`);
    assert.equal(relPath(root, abs), p);
  }
});

test('pathguard: rejects escaping the root, including via ..', () => {
  const root = freshRoot();
  assert.throws(() => resolveInWorkspace(root, '../outside.txt'));
  assert.throws(() => resolveInWorkspace(root, 'files/../../outside.txt'));
});

test('pathguard: writeFile-then-readFile round-trips for a nested path (simulating osfs:writeFile/readFile)', () => {
  const root = freshRoot();
  const p = resolveInWorkspace(root, 'Catatan/catatan.txt');
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, 'Isi catatan uji coba', 'utf8');
  assert.equal(fs.readFileSync(resolveInWorkspace(root, 'Catatan/catatan.txt'), 'utf8'), 'Isi catatan uji coba');
});

test('pathguard: allowRoot:false blocks operating on the root itself (simulating osfs:delete safety)', () => {
  const root = freshRoot();
  assert.throws(() => resolveInWorkspace(root, '.', { allowRoot: false }));
  assert.throws(() => resolveInWorkspace(root, '', { allowRoot: false }));
});
