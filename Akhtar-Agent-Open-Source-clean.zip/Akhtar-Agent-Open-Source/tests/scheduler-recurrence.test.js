'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { computeNextRun } = require('../src/scheduler/recurrence');

const TZ = 'Asia/Jakarta'; // WIB, UTC+7, no DST — good for exact-value assertions

test('recurrence: once returns run_at verbatim', () => {
  const runAt = Date.now() + 60000;
  const n = computeNextRun({ recurrence: 'once', run_at: runAt });
  assert.equal(n.getTime(), runAt);
});

test('recurrence: daily rolls to tomorrow once the time has passed today', () => {
  const from = new Date('2026-09-26T10:00:00Z'); // 17:00 WIB, Saturday
  const n = computeNextRun({ recurrence: 'daily', time: '07:00', timezone: TZ }, from);
  assert.equal(n.toISOString(), '2026-09-27T00:00:00.000Z'); // 07:00 WIB tomorrow
});

test('recurrence: daily stays today when the time has not passed yet', () => {
  const from = new Date('2026-09-26T10:00:00Z'); // 17:00 WIB
  const n = computeNextRun({ recurrence: 'daily', time: '20:00', timezone: TZ }, from);
  assert.equal(n.toISOString(), '2026-09-26T13:00:00.000Z'); // 20:00 WIB today
});

test('recurrence: weekly finds the next occurrence of the target weekday', () => {
  const from = new Date('2026-09-26T10:00:00Z'); // Saturday 17:00 WIB
  const n = computeNextRun({ recurrence: 'weekly', day_of_week: 'monday', time: '07:00', timezone: TZ }, from);
  assert.equal(n.toISOString(), '2026-09-28T00:00:00.000Z'); // Monday 07:00 WIB
});

test('recurrence: weekly on today\'s weekday rolls to next week if the time already passed', () => {
  const from = new Date('2026-09-26T10:00:00Z'); // Saturday 17:00 WIB
  const n = computeNextRun({ recurrence: 'weekly', day_of_week: 'saturday', time: '07:00', timezone: TZ }, from);
  assert.equal(n.toISOString(), '2026-10-03T00:00:00.000Z'); // next Saturday, not today
});

test('recurrence: weekly on today\'s weekday stays today if the time has not passed', () => {
  const from = new Date('2026-09-26T10:00:00Z'); // Saturday 17:00 WIB
  const n = computeNextRun({ recurrence: 'weekly', day_of_week: 'saturday', time: '20:00', timezone: TZ }, from);
  assert.equal(n.toISOString(), '2026-09-26T13:00:00.000Z'); // today 20:00 WIB
});

test('recurrence: monthly clamps day_of_month to the last day of a shorter month', () => {
  const from = new Date('2026-04-25T00:00:00Z');
  const n = computeNextRun({ recurrence: 'monthly', day_of_month: 31, time: '09:00', timezone: TZ }, from);
  assert.equal(n.toISOString(), '2026-04-30T02:00:00.000Z'); // April has 30 days
});

test('recurrence: monthly rolls over into January of the next year', () => {
  const from = new Date('2026-12-20T00:00:00Z');
  const n = computeNextRun({ recurrence: 'monthly', day_of_month: 5, time: '08:00', timezone: TZ }, from);
  assert.equal(n.getUTCFullYear(), 2027);
  assert.equal(n.getUTCMonth(), 0); // January
});

test('recurrence: rejects bad input instead of silently producing a wrong date', () => {
  assert.throws(() => computeNextRun({ recurrence: 'daily', time: '25:00', timezone: TZ }));
  assert.throws(() => computeNextRun({ recurrence: 'weekly', day_of_week: 'funday', time: '07:00', timezone: TZ }));
  assert.throws(() => computeNextRun({ recurrence: 'monthly', day_of_month: 40, time: '07:00', timezone: TZ }));
  assert.throws(() => computeNextRun({ recurrence: 'once' })); // missing run_at
});
