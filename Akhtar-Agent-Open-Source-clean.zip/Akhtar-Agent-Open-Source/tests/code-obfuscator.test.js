'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const tools = require('../src/tools/code');

const tool = tools.find(t => t.name === 'code.obfuscate');

test('code.obfuscate is a workspace WRITE tool with three presets', () => {
  assert.ok(tool);
  assert.equal(tool.group, 'code');
  assert.equal(tool.permission, 'WRITE');
  assert.equal(tool.requiresWorkspace, true);
  assert.deepEqual(tool.inputSchema.properties.mode.enum, ['light','balanced','aggressive']);
});

test('code.obfuscate preserves source and writes separate output', async (t) => {
  try { require.resolve('javascript-obfuscator'); } catch { t.skip('dependency not installed in source-only test environment'); return; }
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-obf-'));
  fs.writeFileSync(path.join(root, 'hello.js'), 'function hello(name){ return "hello " + name; } console.log(hello("Akhtar"));\n');
  const result = await tool.execute({ path:'hello.js', mode:'light' }, { workspace:{root_path:root} });
  assert.equal(result.source_preserved, true);
  assert.equal(fs.readFileSync(path.join(root,'hello.js'),'utf8').includes('function hello'), true);
  assert.equal(fs.existsSync(path.join(root,'hello.obfuscated.js')), true);
  assert.notEqual(fs.readFileSync(path.join(root,'hello.obfuscated.js'),'utf8'), fs.readFileSync(path.join(root,'hello.js'),'utf8'));
});

test('code.obfuscate rejects source overwrite and non-JavaScript input in preview', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-obf-'));
  fs.writeFileSync(path.join(root, 'a.js'), 'const a=1;');
  await assert.rejects(() => tool.preview({path:'a.js',output:'a.js'}, {workspace:{root_path:root}}), /Refusing to overwrite/);
  await assert.rejects(() => tool.preview({path:'a.txt'}, {workspace:{root_path:root}}), /JavaScript files only/);
});
