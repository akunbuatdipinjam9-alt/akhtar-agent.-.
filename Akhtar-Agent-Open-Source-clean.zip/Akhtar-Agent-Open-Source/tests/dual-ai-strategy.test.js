'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { scoreDelegation, strategyPrompt, structuredSecondarySystem } = require('../src/agent/dual-ai-strategy');

test('off means no delegation', () => assert.equal(scoreDelegation({ text:'audit auth', mode:'agent', collaboration:{mode:'off'} }).level, 'NONE'));
test('trivial auto task stays primary-only', () => assert.equal(scoreDelegation({ text:'hello', mode:'assist', collaboration:{mode:'auto'} }).level, 'NONE'));
test('complex task consults specialist', () => { const d=scoreDelegation({ text:'implement a complex multi-step integration', mode:'agent', collaboration:{mode:'auto'} }); assert.notEqual(d.level,'NONE'); assert.equal(d.role,'specialist'); });
test('security-sensitive work chooses reviewer', () => { const d=scoreDelegation({ text:'audit authentication token security and database migration', mode:'agent', collaboration:{mode:'auto'} }); assert.ok(['REVIEW','ESCALATE'].includes(d.level)); assert.ok(['reviewer','critic'].includes(d.role)); });
test('repeated failures escalate to critic', () => { const d=scoreDelegation({ text:'debug implementation', mode:'agent', failureCount:2, collaboration:{mode:'auto'} }); assert.equal(d.level,'ESCALATE'); assert.equal(d.role,'critic'); });
test('always mode delegates substantial work', () => { const d=scoreDelegation({ text:'implement feature', mode:'agent', collaboration:{mode:'always'} }); assert.notEqual(d.level,'NONE'); });
test('secondary output contract is structured and tool-free', () => { const s=structuredSecondarySystem('reviewer'); assert.match(s,/VERDICT:/); assert.match(s,/CONFIDENCE:/); assert.match(s,/no tools/i); });
test('strategy note requires verification', () => { const d=scoreDelegation({ text:'audit auth security', mode:'agent', collaboration:{mode:'auto'} }); assert.match(strategyPrompt(d,{maxDelegations:2,usedDelegations:0}),/Verify actionable findings/i); });
