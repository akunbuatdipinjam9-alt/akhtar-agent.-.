'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
const {withTimeout}=require('../src/agent/executor');
test('timeout aborts underlying operation signal',async()=>{let observed=false;await assert.rejects(()=>withTimeout(signal=>new Promise((resolve,reject)=>{signal.addEventListener('abort',()=>{observed=true;reject(signal.reason)},{once:true})}),15));assert.equal(observed,true)});
