'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const tools = require('../src/tools/chart');

test('chart tools expose create/update/delete and use local Chart.js artifacts', async () => {
  assert.deepEqual(tools.map(t=>t.name), ['chart.create','chart.update','chart.delete']);
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'akhtar-chart-'));
  let saved=null;
  const ctx={artifactsDir:dir,workspace:null,workspaceId:null,taskId:'t1',artifacts:{create(x){saved={id:'a1',...x};return saved;},get(){return saved;},remove(){}}};
  const r=await tools[0].execute({title:'Weekly usage',type:'line',labels:['Mon','Tue'],datasets:[{label:'Tokens',data:[10,20]}]},ctx);
  assert.equal(r.engine,'chart.js'); assert.equal(r.imageGenerationUsed,false); assert.ok(fs.existsSync(r.path));
  const spec=JSON.parse(fs.readFileSync(r.path,'utf8')); assert.equal(spec.type,'line'); assert.equal(spec.datasets[0].data[1],20);
});

test('visualisasion skill explicitly prefers charts over image generation', () => {
  const skill=fs.readFileSync(path.join(__dirname,'..','skills','visualisasion','SKILL.md'),'utf8');
  assert.match(skill,/chart\.create/); assert.match(skill,/Do NOT call `image\.generate`/);
});

test('renderer has Chart.js preview wiring', () => {
  const html=fs.readFileSync(path.join(__dirname,'..','src','renderer','index.html'),'utf8');
  const app=fs.readFileSync(path.join(__dirname,'..','src','renderer','app.js'),'utf8');
  assert.match(html,/chart\.umd\.js/); assert.match(html,/artifactChart/); assert.match(app,/getChartArtifact/);
});
