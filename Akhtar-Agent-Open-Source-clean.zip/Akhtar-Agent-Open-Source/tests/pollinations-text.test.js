'use strict';
/** Uses a mocked global.fetch — no real network call, works offline/in CI. */
const test = require('node:test');
const assert = require('node:assert/strict');

const { createProvider } = require('../src/providers/llm');

const CONFIG = { id: 'pollinations', type: 'pollinations', label: 'Pollinations', baseUrl: 'https://text.pollinations.ai', models: ['openai'] };

function sseStream(lines) {
  return (async function* () { for (const l of lines) yield Buffer.from(l); })();
}

test('pollinations text: hits the documented endpoints (chat at baseUrl+/openai, not /chat/completions)', () => {
  const p = createProvider(CONFIG, '');
  assert.equal(p.chatCompletionsUrl, 'https://text.pollinations.ai/openai');
  assert.equal(p.modelsUrl, 'https://text.pollinations.ai/models');
  assert.equal(p.requiresKey, false);
  assert.doesNotThrow(() => p.ensureKey());
});

test('pollinations text: streams and assembles text deltas from SSE, with the documented request body shape', async (t) => {
  let capturedUrl = null, capturedBody = null;
  t.mock.method(global, 'fetch', async (url, opts) => {
    capturedUrl = url;
    capturedBody = JSON.parse(opts.body);
    return {
      ok: true,
      body: sseStream([
        'data: {"choices":[{"delta":{"content":"Halo"}}]}\n\n',
        'data: {"choices":[{"delta":{"content":" dunia"}}]}\n\n',
        'data: [DONE]\n\n',
      ]),
    };
  });

  const p = createProvider(CONFIG, '');
  let text = '';
  for await (const ev of p.stream({ model: 'openai', system: 'Kamu asisten.', messages: [{ role: 'user', content: 'Halo!' }], tools: [], maxTokens: 100, temperature: 1 })) {
    if (ev.type === 'text') text += ev.delta;
  }

  assert.equal(capturedUrl, 'https://text.pollinations.ai/openai');
  assert.equal(text, 'Halo dunia');
  assert.equal(capturedBody.model, 'openai');
  assert.equal(capturedBody.messages[0].role, 'system');
  assert.equal(capturedBody.messages[1].content, 'Halo!');
  assert.equal(capturedBody.max_tokens, 100, "classic max_tokens body, matching Pollinations' own docs example");
  assert.equal(capturedBody.stream_options, undefined, 'supportsUsage is off, so no stream_options sent');
});

test('pollinations text: parses tool_call deltas the same way as any OpenAI-compatible stream', async (t) => {
  t.mock.method(global, 'fetch', async () => ({
    ok: true,
    body: sseStream([
      'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"call_1","function":{"name":"weather__current","arguments":""}}]}}]}\n\n',
      'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{\\"location\\":\\"Jakarta\\"}"}}]}}]}\n\n',
      'data: [DONE]\n\n',
    ]),
  }));
  const p = createProvider(CONFIG, '');
  const calls = [];
  for await (const ev of p.stream({ model: 'openai', system: '', messages: [], tools: [{ name: 'weather.current', description: 'x', inputSchema: {} }] })) {
    if (ev.type === 'tool_call') calls.push(ev);
  }
  assert.equal(calls.length, 1);
  assert.equal(calls[0].name, 'weather.current', 'tool name decoded back from the API-safe encoded form');
  assert.deepEqual(calls[0].arguments, { location: 'Jakarta' });
});

test('pollinations text: remains available as a fallback provider', () => {
  const { DEFAULTS } = require('../src/main/settings');
  assert.notEqual(DEFAULTS.activeModel.providerId, 'pollinations');
  const cfg = DEFAULTS.providers.find((p) => p.id === 'pollinations');
  assert.ok(cfg, 'pollinations must remain in the default provider list');
  assert.equal(cfg.baseUrl, 'https://text.pollinations.ai');
});
