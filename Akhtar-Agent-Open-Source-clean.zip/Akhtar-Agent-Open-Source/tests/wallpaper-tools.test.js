'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const tools = require('../src/tools/wallpaper');

test('native wallpaper tool exposes get/set/restore commands', () => {
  assert.deepEqual(tools.map(t => t.name), ['wallpaper.get','wallpaper.set','wallpaper.restore']);
});
test('wallpaper set is sensitive and workspace-scoped', () => {
  const t = tools.find(x => x.name === 'wallpaper.set');
  assert.equal(t.requiresWorkspace, true);
  assert.equal(t.category, 'system.control'); // shares the global system.control lifetime grant
  assert.ok(t.inputSchema.required.includes('path'));
});
