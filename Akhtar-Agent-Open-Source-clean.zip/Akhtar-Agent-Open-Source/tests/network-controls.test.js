'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
const tools=require('../src/tools/network-controls'); const {buildRegistry}=require('../src/tools');
test('wifi/bluetooth commands registered',()=>{const r=buildRegistry(); for(const n of ['wifi.status','wifi.list','wifi.on','wifi.off','wifi.connect','wifi.disconnect','bluetooth.status','bluetooth.list','bluetooth.on','bluetooth.off']) assert.ok(r.get(n),n);});
test('mutating network controls use lifetime system permission',()=>{for(const t of tools.filter(x=>!x.name.endsWith('.status')&&!x.name.endsWith('.list'))){assert.equal(t.category,'system.control');assert.equal(t.lifetimePermission,true);}});
test('read commands remain read-only',()=>{for(const n of ['wifi.status','wifi.list','bluetooth.status','bluetooth.list']) assert.equal(tools.find(x=>x.name===n).permission,'READ');});
