'use strict';
/** Regression tests for the stability bug-hunt fixes. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { withTimeout } = require('../src/agent/executor');
const { classifyError } = require('../src/agent/stability');
const { resolveInWorkspace } = require('../src/tools/filesystem/pathguard');
const { repairToolPairs } = require('../src/agent/context');
const { PermissionManager } = require('../src/permissions/manager');
const { LEVEL } = require('../src/permissions/levels');
const { runParallelToolCalls } = require('../src/agent/parallel-engine');

test('withTimeout: a tool that ignores the signal still times out (no hang, no late success)', async () => {
  const t0 = Date.now();
  await assert.rejects(withTimeout(() => new Promise((r) => setTimeout(() => r('late'), 2000)), 100), (e) => classifyError(e) === 'timeout');
  assert.ok(Date.now() - t0 < 1000);
});

test('withTimeout: parent abort cancels a signal-ignoring tool', async () => {
  const parent = new AbortController();
  setTimeout(() => parent.abort(), 50);
  await assert.rejects(withTimeout(() => new Promise(() => {}), 5000, parent.signal), (e) => classifyError(e) === 'cancelled');
});

test('withTimeout: sync throw inside the tool is a normal rejection, success passes through', async () => {
  await assert.rejects(withTimeout(() => { throw new Error('boom'); }, 1000), /boom/);
  assert.equal(await withTimeout(async () => 42, 1000), 42);
});

test('pathguard: dangling symlink pointing outside is blocked', { skip: process.platform === 'win32' }, () => {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-pg-'));
  const root = path.join(base, 'root'); fs.mkdirSync(root);
  fs.symlinkSync(path.join(base, 'outside.txt'), path.join(root, 'link.txt'));
  assert.throws(() => resolveInWorkspace(root, 'link.txt'), /symlink/);
});

test('pathguard: names starting with ".." inside the workspace are allowed', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-pg-'));
  assert.ok(resolveInWorkspace(root, '..notes.txt').endsWith('..notes.txt'));
  assert.throws(() => resolveInWorkspace(root, '../x'));
});

test('repairToolPairs: orphan results dropped, missing results synthesized, starts with user', () => {
  const fixed = repairToolPairs([
    { role: 'tool', toolCallId: 'gone', content: '{}' },
    { role: 'assistant', content: 'hi' },
    { role: 'user', content: 'do it' },
    { role: 'assistant', content: '', toolCalls: [{ id: 'a', name: 'file.read' }, { id: 'b', name: 'file.read' }] },
    { role: 'tool', toolCallId: 'a', content: '"ok"' },
  ]);
  assert.equal(fixed[0].role, 'user');
  assert.equal(fixed.filter((m) => m.role === 'tool').length, 2);
  assert.ok(fixed.find((m) => m.toolCallId === 'b').content.includes('interrupted'));
  assert.ok(!fixed.some((m) => m.toolCallId === 'gone'));
});

function fakeDb(grant) {
  return { get: () => (grant ? { decision: grant } : undefined), run() {}, all: () => [] };
}

test('permissions: a lifetime grant never bypasses BLOCKED or CRITICAL', async () => {
  const pm = new PermissionManager({ db: fakeDb('allow_always'), request: async () => 'deny' });
  assert.equal((await pm.check({ level: LEVEL.BLOCKED, category: 'system.control', lifetime: true })).allowed, false);
  assert.equal((await pm.check({ level: LEVEL.CRITICAL, category: 'system.control', lifetime: true })).allowed, false);
  assert.equal(pm.checkUnattended({ level: LEVEL.CRITICAL, category: 'system.control', lifetime: true }).allowed, false);
  assert.equal((await pm.check({ level: LEVEL.SENSITIVE, category: 'system.control', lifetime: true })).allowed, true);
});

test('parallel engine keeps running other calls when one fails', async () => {
  const { results } = await runParallelToolCalls([{ name: 'a.read' }, { name: 'b.read' }], {
    execute: async (c) => { if (c.name === 'a.read') throw new Error('x'); return 1; },
  });
  assert.equal(results[0].ok, false); assert.equal(results[1].ok, true);
});
