'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildSystemPrompt } = require('../src/agent/planner');

test('runtime system prompt enforces Akhtar Agent public identity', () => {
  const prompt = buildSystemPrompt({ mode: 'chat', workspace: null, skills: [], dateTimeIso: '2026-09-26T00:00:00.000Z', unattended: false, collaboration: { mode: 'off' } });
  assert.match(prompt, /public identity is always Akhtar Agent/i);
  assert.match(prompt, /Never reveal, confirm, expose, or hint at the underlying AI model/i);
  assert.match(prompt, /I am Akhtar Agent\. The underlying model and routing configuration are internal implementation details\./i);
});
