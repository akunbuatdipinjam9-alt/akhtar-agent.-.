// Fake preload bridge so the real renderer (index.html + app.js) runs in plain Chromium.
(function () {
  const listeners = {};
  const on = (ch) => (cb) => { (listeners[ch] = listeners[ch] || []).push(cb); };
  const emit = (ch, ev) => (listeners[ch] || []).forEach((cb) => cb(ev));
  const ok = (data) => Promise.resolve({ ok: true, data });
  const convs = [
    { id: 'c1', title: 'Rapikan struktur folder src', mode: 'agent' },
    { id: 'c2', title: 'Kenapa build Windows gagal?', mode: 'assist' },
    { id: 'c3', title: 'Ringkas dokumentasi Supabase auth', mode: 'chat' },
  ];
  const messages = { c1: [
    { role: 'user', content: 'Rapikan struktur folder src, pisahkan tools jaringan ke folder sendiri.' },
    { role: 'assistant', content: 'Siap. Saya lihat dulu isi `src/tools`, lalu saya usulkan struktur baru sebelum memindahkan file.\n\nStruktur yang saya usulkan:\n```\nsrc/tools/net/browser\nsrc/tools/net/github\nsrc/tools/net/weather\n```\nSetelah kamu setuju, saya pindahkan file satu per satu dan update semua `require`.' },
  ], c2: [], c3: [] };
  const providers = [
    { id: 'akhtar-openai-router', type: 'supabase-openai', label: 'Akhtar Cloud', models: ['gpt-5.6-luna', 'gpt-5-mini'], hasKey: true, requiresKey: false },
    { id: 'anthropic', type: 'anthropic', label: 'Anthropic', models: ['claude-sonnet-5'], hasKey: true, requiresKey: true },
    { id: 'openai', type: 'openai', label: 'OpenAI', models: [], hasKey: false, requiresKey: true },
    { id: 'gemini', type: 'gemini', label: 'Google Gemini', models: [], hasKey: false, requiresKey: true },
  ];
  const settings = { providers, activeModel: { providerId: 'akhtar-openai-router', model: 'gpt-5.6-luna' }, agent: { maxIterations: 25, runTimeoutMin: 20 }, collaboration: { mode: 'auto' }, browserVision: { mode: 'smart', maxCallsPerTask: 3 }, computerControl: { osUrl: '' }, mcp: { servers: [] } };
  window.__calls = [];
  window.__emit = emit;
  const handler = {
    get(_t, name) {
      if (name.startsWith('on')) return on(name);
      return (arg) => {
        window.__calls.push([name, arg]);
        switch (name) {
          case 'bootstrap': return ok({ settings, workspaces: [{ id: 'w1', name: 'akhtar-agent' }], plugins: { loaded: [{ name: 'spotify', toolCount: 2 }] } });
          case 'listConversations': return ok(window.__noConvs ? [] : convs);
          case 'listMessages': return ok(messages[arg.conversationId] || []);
          case 'createConversation': return ok({ id: 'new' + Date.now(), title: 'Percakapan baru', mode: arg.mode });
          case 'listTodos': return ok([{ title: 'Baca isi src/tools', status: 'completed' }, { title: 'Usulkan struktur baru', status: 'in_progress' }, { title: 'Pindahkan file & update require', status: 'pending' }]);
          case 'listArtifacts': return ok([{ id: 'a1', name: 'struktur-baru.md', path: '/p/struktur-baru.md', type: 'document' }]);
          case 'listCheckpoints': return ok([{ id: 'k1', created_at: Date.now() - 600000 }]);
          case 'getTaskTimeline': return ok([{ kind: 'event', id: 1, type: 'tool_start', message: 'file.list', created_at: Date.now() - 30000 }, { kind: 'event', id: 2, type: 'tool_end', message: 'file.list completed', created_at: Date.now() - 25000 }]);
          case 'authSession': return ok({ signedIn: false });
          case 'billingOverview': return ok({ plans: [{ id: 'free', name: 'Gratis', price: 0, description: 'Pakai kunci API sendiri.' }, { id: 'plus', name: 'Plus', price: 79000, description: 'Kredit bulanan untuk Akhtar Cloud.' }, { id: 'pro', name: 'Pro', price: 199000, description: 'Untuk kerja harian yang berat.' }], paymentMethods: [{ id: 'stripe', label: 'Stripe' }] });
          case 'hasSecret': return ok({ has: false });
          case 'sendMessage': return new Promise(() => {});
          default: return ok(Array.isArray([]) && /^list/.test(name) ? [] : {});
        }
      };
    },
  };
  window.akhtar = new Proxy({}, handler);
})();
