"""Renderer behaviour check: runs the real index.html + app.js in headless Chromium with a fake
preload bridge (mock-preload.js) and saves screenshots next to this file.

  pip install playwright && python -m playwright install chromium
  python tests/ui/ui_check.py
"""
import os, shutil, sys, tempfile
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, '..', '..', 'src', 'renderer')
work = tempfile.mkdtemp(prefix='akhtar-ui-')
shutil.copytree(SRC, os.path.join(work, 'renderer'))
shutil.copy(os.path.join(HERE, 'mock-preload.js'), os.path.join(work, 'mock.js'))
page_path = os.path.join(work, 'renderer', 'index.html')
html = open(page_path, encoding='utf8').read().replace('<script src="app.js"></script>', '<script src="../mock.js"></script>\n<script src="app.js"></script>')
open(page_path, 'w', encoding='utf8').write(html)
url = 'file://' + page_path.replace('\\', '/')

checks = {}
with sync_playwright() as pw:
    b = pw.chromium.launch()
    pg = b.new_page(viewport={'width': 1360, 'height': 860})
    errors = []
    pg.on('pageerror', lambda e: errors.append(str(e)))
    pg.goto(url); pg.wait_for_timeout(500)
    pg.screenshot(path=os.path.join(HERE, 'shot-empty.png'))
    pg.click('.conv-item >> nth=0'); pg.wait_for_timeout(300)
    pg.click('.conv-item >> nth=1'); pg.wait_for_timeout(300)
    checks['empty state for an empty conversation'] = pg.is_visible('#emptyState')
    pg.click('.conv-item >> nth=0'); pg.wait_for_timeout(300)
    pg.evaluate("()=>window.__emit('onAgentEvent',{conversationId:'c1',type:'task_start',task:{id:'t1'}})")
    pg.click('.conv-item >> nth=1'); pg.wait_for_timeout(300)
    pg.evaluate("()=>window.__emit('onAgentEvent',{conversationId:'c1',type:'task_end',status:'completed',task:{id:'t1'}})")
    pg.fill('#input', 'halo'); pg.press('#input', 'Enter'); pg.wait_for_timeout(200)
    checks['can send after a run ended in another conversation'] = pg.evaluate("()=>window.__calls.some(c=>c[0]==='sendMessage')")
    pg.reload(); pg.wait_for_timeout(500)
    pg.click('.conv-item >> nth=0'); pg.wait_for_timeout(300); m1 = pg.get_attribute('.mode-btn.active', 'data-mode')
    pg.click('.conv-item >> nth=2'); pg.wait_for_timeout(300); m3 = pg.get_attribute('.mode-btn.active', 'data-mode')
    checks['mode follows the selected conversation'] = (m1, m3) == ('agent', 'chat')
    pg.evaluate("()=>window.__emit('onPermissionRequest',{id:'p9',title:'x'})"); pg.wait_for_timeout(100)
    pg.screenshot(path=os.path.join(HERE, 'shot-permission.png'))
    pg.evaluate("()=>window.__emit('onPermissionCancel',{id:'p9'})"); pg.wait_for_timeout(100)
    checks['stale permission dialog closes'] = not pg.is_visible('#permissionOverlay')
    pg.click('#settingsBtn'); pg.wait_for_timeout(300)
    pg.click('.settings-nav-btn[data-section=account]'); pg.wait_for_timeout(200)
    checks['settings sections switch'] = pg.is_visible('#billingEmail') and not pg.is_visible('#providerRows')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(100)
    checks['Esc closes settings'] = not pg.is_visible('#settingsOverlay')
    checks['no JavaScript errors'] = not errors
    b.close()

failed = [k for k, v in checks.items() if not v]
for k, v in checks.items():
    print(('PASS ' if v else 'FAIL ') + k)
if errors:
    print('page errors:', errors[:3])
sys.exit(1 if failed else 0)
