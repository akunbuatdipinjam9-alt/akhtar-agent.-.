'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
const hadith=require('../src/tools/hadith'); const moon=require('../src/tools/moon'); const qibla=require('../src/tools/qibla'); const { buildRegistry }=require('../src/tools');
test('Ummah tool names are registered',()=>{const r=buildRegistry(); for(const n of ['hadith.collections','hadith.search','hadith.random','hadith.browse','hadith.get','moon.current','moon.phases','moon.months','moon.to_hijri','moon.to_gregorian','qibla.direction']) assert.ok(r.get(n),n);});
test('Ummah tools are visible in chat mode',()=>{const names=buildRegistry().forMode('chat',{hasWorkspace:false}).map(x=>x.name); for(const n of ['hadith.search','moon.current','qibla.direction']) assert.ok(names.includes(n),n);});
test('Qibla validates coordinates before network call',async()=>{const t=qibla.find(x=>x.name==='qibla.direction'); await assert.rejects(()=>t.execute({latitude:100,longitude:0},{signal:null}),/latitude/);});
test('Expected tool counts',()=>{assert.equal(hadith.length,5);assert.equal(moon.length,5);assert.equal(qibla.length,1);});
