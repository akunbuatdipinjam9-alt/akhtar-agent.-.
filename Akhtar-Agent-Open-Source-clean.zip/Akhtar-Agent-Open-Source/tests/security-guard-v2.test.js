'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { POLICY_VERSION, scanCode, scanCommand, evaluateTool } = require('../src/security/guard');
const { tokenize } = require('../src/tools/terminal/classifier');

const blocked = (x) => assert.ok(x.length > 0, 'expected guard to block');

test('guard v2 exposes an immutable policy API', () => {
  assert.match(POLICY_VERSION, /^guard-v2\./);
  assert.equal(Object.isFrozen(require('../src/security/guard')), true);
});

test('guard v2 preserves ordinary development operations', () => {
  assert.deepEqual(scanCommand(tokenize('npm test')), []);
  assert.deepEqual(scanCommand(tokenize('git status')), []);
  assert.deepEqual(scanCode('const x = 1;', { path: 'src/app.js' }), []);
  assert.deepEqual(scanCode('Example: sudo apt install ffmpeg', { path: 'docs/INSTALL.md' }), []);
});

test('guard v2 blocks nested shell attempts to cross hard boundary', () => {
  blocked(scanCommand(['bash', '-c', 'sudo npm install']));
  blocked(scanCommand(['cmd', '/c', 'vssadmin delete shadows /all']));
});

test('guard v2 decodes and scans PowerShell EncodedCommand', () => {
  const cmd = 'Set-MpPreference -DisableRealtimeMonitoring $true';
  const enc = Buffer.from(cmd, 'utf16le').toString('base64');
  blocked(scanCommand(['powershell', '-EncodedCommand', enc]));
});

test('guard v2 blocks high-impact inline runtime code', () => {
  blocked(scanCommand(['node', '-e', "require('child_process').execSync('vssadmin delete shadows /all')"]));
});

test('guard v2 blocks security-service/firewall tampering in generated scripts', () => {
  blocked(scanCode('Set-NetFirewallProfile -Profile Domain -Enabled False', { path: 'setup.ps1' }));
  blocked(scanCode('Stop-Service WinDefend', { path: 'setup.ps1' }));
});

test('guard v2 tool policy is non-overridable for file/terminal calls', () => {
  assert.equal(evaluateTool('file.write', { path: 'x.ps1', content: 'Set-MpPreference -DisableRealtimeMonitoring $true' }).decision, 'BLOCK');
  assert.equal(evaluateTool('terminal.run', { command: 'sudo npm install' }).decision, 'BLOCK');
  assert.equal(evaluateTool('terminal.run', { command: 'npm test' }).decision, 'ALLOW');
});

test('guard v2 inspects execution-shaped MCP payloads', () => {
  const v = evaluateTool('mcp.call', { arguments: { command: 'sudo npm install' } });
  assert.equal(v.decision, 'BLOCK');
});
