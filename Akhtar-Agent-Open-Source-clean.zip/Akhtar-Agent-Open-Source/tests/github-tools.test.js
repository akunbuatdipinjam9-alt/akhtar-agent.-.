'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const githubTools = require('../src/tools/github');
const { parseGithubRemote, detectRepo } = githubTools.helpers;
const byName = Object.fromEntries(githubTools.map((t) => [t.name, t]));

let gitAvailable = true;
try { execFileSync('git', ['--version'], { stdio: 'ignore' }); } catch { gitAvailable = false; }

test('parseGithubRemote: handles https and ssh remote URL forms', () => {
  assert.deepEqual(parseGithubRemote('https://github.com/akunbuatdipinjam9-alt/akhtaros.-.git'), { owner: 'akunbuatdipinjam9-alt', repo: 'akhtaros.-' });
  assert.deepEqual(parseGithubRemote('https://github.com/owner/repo'), { owner: 'owner', repo: 'repo' });
  assert.deepEqual(parseGithubRemote('git@github.com:owner/repo.git'), { owner: 'owner', repo: 'repo' });
  assert.equal(parseGithubRemote('https://gitlab.com/owner/repo.git'), null, 'non-GitHub remotes are rejected, not guessed at');
});

test('detectRepo: reads owner/repo from the real git remote (no network)', { skip: !gitAvailable && 'git not on PATH' }, async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'akhtar-gh-'));
  execFileSync('git', ['init', '-q'], { cwd: dir });
  execFileSync('git', ['remote', 'add', 'origin', 'https://github.com/someone/some-repo.git'], { cwd: dir });
  const ctx = { workspace: { root_path: dir }, signal: undefined };
  const r = await detectRepo(ctx, null, null);
  assert.deepEqual(r, { owner: 'someone', repo: 'some-repo' });
});

test('detectRepo: explicit owner/repo short-circuits without touching git', async () => {
  const r = await detectRepo({ workspace: null }, 'explicit-owner', 'explicit-repo');
  assert.deepEqual(r, { owner: 'explicit-owner', repo: 'explicit-repo' });
});

test('detectRepo: clear error when there is no workspace and nothing was given', async () => {
  await assert.rejects(() => detectRepo({ workspace: null }), /No workspace open/);
});

function fakeSecrets(token) { return { get: () => token }; }

test('github tools: issue_create sends the documented REST shape and requires a token', async (t) => {
  let capturedUrl = null, capturedOpts = null;
  t.mock.method(global, 'fetch', async (url, opts) => {
    capturedUrl = url; capturedOpts = opts;
    return { ok: true, text: async () => JSON.stringify({ number: 42, title: opts._t, state: 'open', html_url: 'https://github.com/o/r/issues/42', user: { login: 'bot' } }) };
  });
  const ctx = { secrets: fakeSecrets('ghp_dummy'), signal: undefined, workspace: null };
  const res = await byName['github.issue_create'].execute({ owner: 'o', repo: 'r', title: 'Bug found', body: 'details' }, ctx);
  assert.equal(capturedUrl, 'https://api.github.com/repos/o/r/issues');
  assert.equal(capturedOpts.method, 'POST');
  assert.equal(capturedOpts.headers.Authorization, 'Bearer ghp_dummy');
  assert.deepEqual(JSON.parse(capturedOpts.body), { title: 'Bug found', body: 'details' });
  assert.equal(res.number, 42);
});

test('github tools: no token set gives a clear setup error, not a network call', async (t) => {
  const fetchMock = t.mock.fn(async () => ({ ok: true, text: async () => '{}' }));
  t.mock.method(global, 'fetch', fetchMock);
  const ctx = { secrets: fakeSecrets(null), signal: undefined, workspace: null };
  await assert.rejects(() => byName['github.issue_list'].execute({ owner: 'o', repo: 'r' }, ctx), /No GitHub token set/);
  assert.equal(fetchMock.mock.callCount(), 0);
});

test('github tools: a non-OK API response surfaces GitHub\'s own error message', async (t) => {
  t.mock.method(global, 'fetch', async () => ({ ok: false, status: 404, text: async () => JSON.stringify({ message: 'Not Found' }) }));
  const ctx = { secrets: fakeSecrets('ghp_dummy'), signal: undefined, workspace: null };
  await assert.rejects(() => byName['github.repo_info'].execute({ owner: 'o', repo: 'missing' }, ctx), /HTTP 404.*Not Found/s);
});

test('github tools: issue_list filters out pull requests by default', async (t) => {
  t.mock.method(global, 'fetch', async () => ({
    ok: true,
    text: async () => JSON.stringify([
      { number: 1, title: 'Real issue', state: 'open', user: { login: 'a' } },
      { number: 2, title: 'A PR', state: 'open', user: { login: 'b' }, pull_request: { url: 'x' } },
    ]),
  }));
  const ctx = { secrets: fakeSecrets('ghp_dummy'), signal: undefined, workspace: null };
  const res = await byName['github.issue_list'].execute({ owner: 'o', repo: 'r' }, ctx);
  assert.equal(res.issues.length, 1);
  assert.equal(res.issues[0].number, 1);
});
