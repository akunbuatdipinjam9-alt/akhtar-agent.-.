'use strict';
/** Regression tests for bug-hunt round 4 (LLM providers, SSE, secrets, guard, knowledge). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const Module = require('node:module');

const { sseEvents, isRetryableModelError } = require('../src/providers/llm/provider');
const { AnthropicProvider } = require('../src/providers/llm/anthropic');
const { OpenAICompatibleProvider } = require('../src/providers/llm/openai');
const { GeminiProvider } = require('../src/providers/llm/gemini');
const { scanCode } = require('../src/security/guard');
const { ProjectKnowledge } = require('../src/knowledge/indexer');

function sseResponse(frames, { hang = false } = {}) {
  const enc = new TextEncoder();
  const body = new ReadableStream({
    start(c) { for (const f of frames) c.enqueue(enc.encode(f)); if (!hang) c.close(); },
  });
  return new Response(body, { status: 200, headers: { 'content-type': 'text/event-stream' } });
}
const data = (o) => `data: ${typeof o === 'string' ? o : JSON.stringify(o)}\n\n`;
async function collect(gen) { const out = []; for await (const e of gen) out.push(e); return out; }
async function withFetch(res, fn) { const real = global.fetch; global.fetch = async () => res; try { return await fn(); } finally { global.fetch = real; } }

test('sse: a stalled stream fails fast with a retryable error', async () => {
  const res = sseResponse([data({ a: 1 })], { hang: true });
  await assert.rejects(collect(sseEvents(res, { idleMs: 100 })), (e) => /stalled/.test(e.message) && isRetryableModelError(e));
});

test('sse: multi-byte character split across chunks survives', async () => {
  const bytes = new TextEncoder().encode('data: {"t":"é"}\n\n');
  const body = new ReadableStream({ start(c) { c.enqueue(bytes.slice(0, 12)); c.enqueue(bytes.slice(12)); c.close(); } });
  const [ev] = await collect(sseEvents(new Response(body)));
  assert.equal(JSON.parse(ev.data).t, 'é');
});

test('anthropic: stream cut before message_stop is an error, not a (truncated) final answer', async () => {
  const p = new AnthropicProvider({ id: 'a', baseUrl: 'http://x' }, 'k');
  const res = sseResponse([data({ type: 'message_start', message: { usage: { input_tokens: 1 } } }), data({ type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: 'Half an ans' } })]);
  await withFetch(res, () => assert.rejects(collect(p.stream({ model: 'm', messages: [{ role: 'user', content: 'hi' }] })), (e) => isRetryableModelError(e)));
});

test('anthropic: overloaded_error mid-stream is retryable', async () => {
  const p = new AnthropicProvider({ id: 'a', baseUrl: 'http://x' }, 'k');
  const res = sseResponse([data({ type: 'error', error: { type: 'overloaded_error', message: 'Overloaded' } })]);
  await withFetch(res, () => assert.rejects(collect(p.stream({ model: 'm', messages: [] })), (e) => isRetryableModelError(e)));
});

test('openai-compatible: several complete tool calls all at index 0 are kept separate', async () => {
  const p = new OpenAICompatibleProvider({ id: 'o', baseUrl: 'http://x' }, 'k');
  const res = sseResponse([
    data({ choices: [{ delta: { tool_calls: [{ index: 0, id: 'a', function: { name: 'file__read', arguments: '{"path":"a"}' } }] } }] }),
    data({ choices: [{ delta: { tool_calls: [{ index: 0, id: 'b', function: { name: 'file__write', arguments: '{"path":"b"}' } }] } }] }),
    data({ choices: [{ delta: {}, finish_reason: 'tool_calls' }] }), data('[DONE]'),
  ]);
  const evs = await withFetch(res, () => collect(p.stream({ model: 'm', messages: [] })));
  const calls = evs.filter((e) => e.type === 'tool_call');
  assert.deepEqual(calls.map((c) => [c.name, c.arguments.path]), [['file.read', 'a'], ['file.write', 'b']]);
});

test('openai-compatible: split arguments for one call still concatenate', async () => {
  const p = new OpenAICompatibleProvider({ id: 'o', baseUrl: 'http://x' }, 'k');
  const res = sseResponse([
    data({ choices: [{ delta: { tool_calls: [{ index: 0, id: 'a', function: { name: 'file__read', arguments: '{"pa' } }] } }] }),
    data({ choices: [{ delta: { tool_calls: [{ index: 0, function: { arguments: 'th":"x"}' } }] } }] }),
    data('[DONE]'),
  ]);
  const evs = await withFetch(res, () => collect(p.stream({ model: 'm', messages: [] })));
  assert.equal(evs.find((e) => e.type === 'tool_call').arguments.path, 'x');
});

test('gemini: usage reported once; safety stop is explained; truncated stream errors', async () => {
  const p = new GeminiProvider({ id: 'g', baseUrl: 'http://x' }, 'k');
  const usage = { promptTokenCount: 5, candidatesTokenCount: 1 };
  let evs = await withFetch(sseResponse([data({ candidates: [{ content: { parts: [{ text: 'a' }] } }], usageMetadata: usage }), data({ candidates: [{ content: { parts: [{ text: 'b' }] }, finishReason: 'STOP' }], usageMetadata: usage })]), () => collect(p.stream({ model: 'm', messages: [] })));
  assert.equal(evs.filter((e) => e.type === 'usage').length, 1);
  evs = await withFetch(sseResponse([data({ candidates: [{ finishReason: 'SAFETY' }] })]), () => collect(p.stream({ model: 'm', messages: [] })));
  assert.match(evs.find((e) => e.type === 'text').delta, /SAFETY/);
  await withFetch(sseResponse([data({ candidates: [{ content: { parts: [{ text: 'a' }] } }] })]), () => assert.rejects(collect(p.stream({ model: 'm', messages: [] }))));
});

test('guard: documentation is not hard-blocked, scripts still are', () => {
  assert.deepEqual(scanCode('sudo apt-get install ffmpeg', { path: 'docs/INSTALL.md' }), []);
  assert.ok(scanCode('sudo rm -rf /', { path: 'setup.sh' }).length > 0);
});

test('knowledge: credential files are never indexed; inline keys are masked', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'kw-'));
  fs.writeFileSync(path.join(root, 'secrets.yaml'), 'stripe:\n  secret_key: sk_live_51Habcdefghijklmnopqrstuvwxyz\n');
  fs.writeFileSync(path.join(root, 'config.js'), 'const cfg = { apiKey: "sk-proj-abcdefghijklmnopqrstuvwxyz0123456789" }; // stripe secret');
  const k = new ProjectKnowledge({ run() {} });
  const hits = k.search({ id: 'w', root_path: root }, 'stripe secret apiKey');
  assert.ok(!hits.some((h) => h.path === 'secrets.yaml'));
  assert.ok(!hits.some((h) => /sk-proj-|sk_live_/.test(h.content)));
});

test('secrets: a corrupt store is backed up, not silently wiped; bad names rejected', () => {
  const realLoad = Module._load;
  Module._load = function (r, ...x) { return r === 'electron' ? { safeStorage: { isEncryptionAvailable: () => false } } : realLoad.call(this, r, ...x); };
  delete require.cache[require.resolve('../src/main/secrets')];
  const { SecretStore } = require('../src/main/secrets');
  Module._load = realLoad;
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sec-'));
  const file = path.join(dir, 'secrets.enc.json');
  fs.writeFileSync(file, '{"llm:a": {"enc": false, "v": "a2V5"'); // truncated write
  const st = new SecretStore(file);
  st.set('llm:b', 'new-key');
  assert.ok(fs.readdirSync(dir).some((f) => f.includes('.corrupt-')), 'original bytes kept for recovery');
  assert.throws(() => st.set('__proto__', 'x'));
  assert.equal(st.has('llm:b'), true);
  assert.equal(st.has('nope'), false);
});
