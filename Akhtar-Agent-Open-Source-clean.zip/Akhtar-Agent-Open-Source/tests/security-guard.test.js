'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { scanCode, scanCommand } = require('../src/security/guard');
const { tokenize } = require('../src/tools/terminal/classifier');

test('guard allows ordinary project commands', () => {
  assert.deepEqual(scanCommand(tokenize('npm test')), []);
  assert.deepEqual(scanCommand(tokenize('git status')), []);
  assert.deepEqual(scanCode('function add(a, b) { return a + b; }'), []);
});

test('guard blocks privilege escalation programs', () => {
  assert.ok(scanCommand(tokenize('sudo npm install')).length > 0);
});

test('guard blocks destructive root deletion', () => {
  assert.ok(scanCommand(tokenize('rm -rf /')).length > 0);
});

test('guard blocks registry writes', () => {
  assert.ok(scanCommand(tokenize('reg add HKCU\\Software\\Example')).length > 0);
});

test('guard catches high-impact code content', () => {
  assert.ok(scanCode('vssadmin delete shadows /all').length > 0);
});
