# Writing Skill
> Menulis atau menyunting teks: draf, ringkasan, email, copy, dokumentasi singkat.

1. Perjelas tujuan tulisan dan audiensnya sebelum menulis panjang lebar bila belum jelas dari permintaan user.
2. Tulis langsung dalam jawaban untuk teks pendek. Untuk tulisan panjang yang perlu disimpan, gunakan `file.write`/`file.create` di dalam workspace bila ada.
3. Jaga nada konsisten dengan permintaan user (formal/santai) dan bahasa yang diminta.
4. Untuk revisi, tunjukkan apa yang berubah, jangan menulis ulang seluruh teks tanpa alasan.
