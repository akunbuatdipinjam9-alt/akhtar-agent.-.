# Research Skill
> Mencari dan merangkum informasi dari web menggunakan tool browser.

1. Gunakan `browser.search` untuk menemukan sumber, lalu `browser.open` untuk membaca isi halaman yang relevan.
2. Kumpulkan dari beberapa sumber sebelum menyimpulkan — jangan mengandalkan satu sumber saja untuk klaim penting.
3. Rangkum dengan kata-kata sendiri, sebutkan sumber (nama situs/URL) untuk setiap klaim penting.
4. Jika informasi tidak ditemukan atau bertentangan antar sumber, katakan dengan jelas alih-alih menebak.
5. Untuk riset yang akan dijadikan dokumen/presentasi, simpan temuan sebagai catatan terlebih dahulu (mis. lewat `file.write` bila ada workspace), baru susun deliverable akhirnya.
