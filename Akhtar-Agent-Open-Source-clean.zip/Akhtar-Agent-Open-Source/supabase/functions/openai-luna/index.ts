import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const OPENAI_URL = "https://api.openai.com/v1/chat/completions";
const ALLOWED_MODEL = "gpt-5.6-luna";

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  if (!openaiKey) {
    return json({ error: "OPENAI_API_KEY is not configured on the Akhtar Agent backend." }, 503);
  }

  // This function spends YOUR OpenAI key. Do not rely on the gateway's verify_jwt alone
  // (it is often turned off when using sb_publishable_ keys, and the publishable key ships
  // inside the desktop app): require a real signed-in user.
  const auth = req.headers.get("authorization") || "";
  const userToken = auth.replace(/^Bearer\s+/i, "");
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("SUPABASE_PUBLISHABLE_KEY") || "";
  if (!userToken || !supabaseUrl) return json({ error: "Sign in required." }, 401);
  const who = await fetch(`${supabaseUrl}/auth/v1/user`, { headers: { authorization: `Bearer ${userToken}`, apikey: anonKey } });
  if (!who.ok) return json({ error: "Sign in required." }, 401);
  // TODO(server-side credits): charge/check the user's credit balance HERE before calling OpenAI.
  // Credits are currently only deducted by the desktop client, which a modified client can skip.

  let raw: Record<string, unknown>;
  try {
    raw = await req.json();
  } catch {
    return json({ error: "Invalid JSON body" }, 400);
  }
  // Forward only the fields the app actually uses. Passing the client body through verbatim let
  // callers set e.g. n=128 (128 completions billed per request) or other costly options.
  const ALLOWED_FIELDS = ["messages", "tools", "tool_choice", "stream", "stream_options", "max_completion_tokens", "temperature", "response_format", "parallel_tool_calls"];
  const body: Record<string, unknown> = {};
  for (const k of ALLOWED_FIELDS) if (k in raw) body[k] = raw[k];
  if (!Array.isArray(body.messages)) return json({ error: "messages must be an array" }, 400);

  body.model = ALLOWED_MODEL;
  const max = Number(body.max_completion_tokens ?? 4096);
  body.max_completion_tokens = Number.isFinite(max) ? Math.max(256, Math.min(max, 16384)) : 4096;
  body.stream = body.stream !== false;

  const upstream = await fetch(OPENAI_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${openaiKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!upstream.ok) {
    const text = await upstream.text();
    return new Response(text, {
      status: upstream.status,
      headers: {
        "content-type": upstream.headers.get("content-type") || "application/json",
        "cache-control": "no-store",
      },
    });
  }

  return new Response(upstream.body, {
    status: upstream.status,
    headers: {
      "content-type": upstream.headers.get("content-type") || "text/event-stream",
      "cache-control": "no-store",
      "connection": "keep-alive",
    },
  });
});
