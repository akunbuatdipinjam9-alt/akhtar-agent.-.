// Deployed Supabase Edge Function source is managed server-side.
// Runtime endpoint: /functions/v1/credits
// Actions: status, login_rewards, spend.
// Auth: valid Supabase user JWT required.
